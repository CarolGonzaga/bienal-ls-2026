# Calibração e Refinamento Geométrico do Mapa da Bienal do Livro

> Reconstrução 07/08/2026: o único guia geométrico ativo é `public/mapa/mapa-guia-2d.png`, fornecido em `1920 × 1080`, RGBA transparente. O SVG usa as mesmas coordenadas nativas, sem escala, offset ou dados geométricos da planta anterior.

## 1. Referência ativa (`mapa-guia-2d.png`)

- **Caminho do arquivo**: `public/mapa/mapa-guia-2d.png`
- **Largura real**: `1920 px`
- **Altura real**: `1080 px`
- **Formato**: PNG RGBA transparente.
- **Geometria vetorial**: `src/data/map/mapaPngSpaces.ts`, transcrita diretamente dos traços visíveis.
- **Redimensionamento no build**: Nenhum (copiado via diretório `public/` do Vite).

## 2. Sistema de Coordenadas e Calibração

- **Sistema Lógico do SVG (`viewBox`)**: `0 0 1920 1080`, idêntico ao novo guia.
- **Proporção Lógica**: `16:9`.
- **Conversão**: identidade 1:1. Um ponto `(x, y)` no PNG é o mesmo ponto `(x, y)` no SVG.
- **Conversores Centralizados**: `referenceToMap` e `mapToReference` sem arredondamentos prematuros (`Math.round`).

## 3. Matriz de Progresso por Zona de Calibração

| Zona | Estruturas | Estandes | Ruas | Textos | Acessos | Validado |
|------|------------|----------|------|--------|---------|----------|
| 1. Área verde & portões superiores (P7, P8, P9, P10) | Concluído | n/a | Sim | Sim | Sim | Sim |
| 2. Faixa superior de banheiros & serviços | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 3. Lateral esquerda & alimentação principal | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 4. Fileiras K e J | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 5. Fileiras H e G | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 6. Fileiras F e E | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 7. Fileiras D e C | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 8. Fileiras B e A | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 9. Acessos inferiores & Portão 5 / P.A | Concluído | n/a | Sim | Sim | Sim | Sim |
| 10. Ligação entre os pavilhões | Concluído | n/a | Sim | Sim | Sim | Sim |
| 11. Parte superior do Pavilhão da Direita | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 12. Blocos internos da Direita | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 13. Praça Claro & Espaço Claro | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 14. Autógrafos 1, 2 & Alimentação Leste/Central | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 15. Acesso Professores & Profissionais | Concluído | Concluído | Sim | Sim | Sim | Sim |
| 16. Áreas externas inferiores | Concluído | n/a | Sim | Sim | Sim | Sim |

## 4. Registro de Elementos com `needsReview`

| Elemento | Problema | Status |
|----------|----------|--------|
| `skeelo` | Localização exata no mapa físico sob confirmação contratual | `needsReview: true` |

## 5. Instruções do Modo de Calibração

- **Como Ativar**: Adicionar `?mapDebug=true` na URL (ex: `http://localhost:5173/?mapDebug=true`).
- **Controles no Painel**:
  - Opacidade da camada de referência (0% a 100%).
  - Modos de comparação: **Normal** (sobreposição), **Contorno** (filtro de alto contraste), **Diferenças** (blend mode difference).
  - **Piscar auto** (intervalo regular de ~650ms entre referência e vetores) e **Só contornos** (oculta preenchimentos).
  - Exibição de Grid e coordenadas simultâneas de **Tela**, **SVG** e **Imagem Original**.
  - Atalhos de Teclado:
    - **Setas**: Mover elemento selecionado em 0.5 unidades SVG.
    - **Shift + Setas**: Mover elemento em 5.0 unidades SVG.
    - **Alt + Setas**: Redimensionar largura/altura em 0.5 unidades.
    - **Ctrl/Cmd + Z**: Desfazer edição.
    - **Ctrl/Cmd + Shift + Z**: Refazer edição.
    - **Escape**: Desmarcar elemento.
- **Exportação**: Botão *"Exportar layout JSON"* baixa as coordenadas ajustadas em formato JSON.
