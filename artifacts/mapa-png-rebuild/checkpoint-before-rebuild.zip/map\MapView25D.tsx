import React, { useMemo } from 'react'
import { Heart, CheckCircle2, Bookmark, Sparkles } from 'lucide-react'
import { useAdminMapStore } from '../../stores/useAdminMapStore'
import { useExhibitorStore } from '../../stores/useExhibitorStore'
import { useMapStore } from '../../stores/useMapStore'
import { useUserStore } from '../../stores/useUserStore'
import { useMapInteraction } from '../../hooks/useMapInteraction'
import { MAP_ORIGINAL_WIDTH, MAP_ORIGINAL_HEIGHT } from '../../utils/coordinates'
import { OFFICIAL_MAP_SPACES, officialSpaceToGeometry } from '../../data/officialMapSpaces'

const AISLES = [
  { name: 'RUA K', y: 1915 / 6436 }, { name: 'RUA J', y: 2217 / 6436 },
  { name: 'RUA H', y: 2490 / 6436 }, { name: 'RUA G', y: 2780 / 6436 },
  { name: 'RUA F', y: 3055 / 6436 }, { name: 'RUA E', y: 3345 / 6436 },
  { name: 'RUA D', y: 3614 / 6436 }, { name: 'RUA C', y: 3956 / 6436 },
  { name: 'RUA B', y: 4253 / 6436 }, { name: 'RUA A', y: 4515 / 6436 }
]

const PUBLIC_MAP_VIEWBOX = {
  x: 35,
  y: 205,
  width: 1975,
  height: 1245
}

const geometryCenter = (geometry: any) => {
  const points = geometry.polygon.map((p: any) => ({ x: p.x * MAP_ORIGINAL_WIDTH, y: p.y * MAP_ORIGINAL_HEIGHT }))
  const x = points.reduce((sum: number, point: any) => sum + point.x, 0) / points.length
  const y = points.reduce((sum: number, point: any) => sum + point.y, 0) / points.length
  return { x, y }
}

const darken = (hex: string, factor: number) => {
  const value = hex.replace('#', '')
  const channels = [0, 2, 4].map(i => Math.round(parseInt(value.slice(i, i + 2), 16) * factor))
  return `rgb(${channels.join(',')})`
}

interface StandItemProps {
  geometry: any
  exhibitor?: any
  selected: boolean
  favorite: boolean
  visited: boolean
  inRoute: boolean
  isometric: boolean
  onSelect: () => void
}

const StandItem: React.FC<StandItemProps> = ({ geometry, exhibitor, selected, favorite, visited, inRoute, isometric, onSelect }) => {
  const rawPoints = useMemo(() => geometry.polygon.map((p: any) => ({ x: p.x * MAP_ORIGINAL_WIDTH, y: p.y * MAP_ORIGINAL_HEIGHT })), [geometry.polygon])
  const rawBounds = rawPoints.reduce((b: any, p: any) => ({ minX: Math.min(b.minX, p.x), maxX: Math.max(b.maxX, p.x), minY: Math.min(b.minY, p.y), maxY: Math.max(b.maxY, p.y) }), { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity })
  const visualGap = Math.min(6, (rawBounds.maxX - rawBounds.minX) * .12, (rawBounds.maxY - rawBounds.minY) * .16)
  const rawCenter = { x: (rawBounds.minX + rawBounds.maxX) / 2, y: (rawBounds.minY + rawBounds.maxY) / 2 }
  const points = rawPoints.map((point: any) => ({
    x: point.x < rawCenter.x ? point.x + visualGap : point.x - visualGap,
    y: point.y < rawCenter.y ? point.y + visualGap : point.y - visualGap
  }))
  if (points.length < 3) return null

  const bounds = points.reduce((b: any, p: any) => ({ minX: Math.min(b.minX, p.x), maxX: Math.max(b.maxX, p.x), minY: Math.min(b.minY, p.y), maxY: Math.max(b.maxY, p.y) }), { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity })
  const center = { x: (bounds.minX + bounds.maxX) / 2, y: (bounds.minY + bounds.maxY) / 2 }
  const pointString = points.map((p: any) => `${p.x},${p.y}`).join(' ')
  const isService = Boolean(geometry.serviceType)
  const featured = exhibitor?.relevanceLevel === 'curadoria_direta'
  const catalog = exhibitor?.relevanceLevel === 'catalogo_confirmado'
  const fill = selected ? '#0ea5e9' : (featured ? '#db2777' : catalog ? '#4f46e5' : exhibitor ? '#7c3aed' : '#263449')
  const stroke = selected ? '#fff' : (featured ? '#f9a8d4' : catalog ? '#a5b4fc' : exhibitor ? '#c4b5fd' : isService ? '#cbd5e1' : '#52647d')
  const depth = isometric ? Math.max(10, (geometry.height || .5) * 17) : 0
  const standWidth = bounds.maxX - bounds.minX
  const standHeight = bounds.maxY - bounds.minY
  const labelSize = Math.max(9, Math.min(isService ? 18 : 16, standWidth / Math.max(geometry.standCode.length * .62, 2), standHeight * .38))

  return <g className={geometry.neutral && !isService ? '' : 'cursor-pointer'} onClick={e => { if (!geometry.neutral || isService) { e.stopPropagation(); onSelect() } }}>
    <title>{geometry.displayName || geometry.standCode}</title>
    {depth > 0 && <>
      <polygon points={`${bounds.minX},${bounds.maxY} ${bounds.maxX},${bounds.maxY} ${bounds.maxX + depth * .45},${bounds.maxY + depth} ${bounds.minX + depth * .45},${bounds.maxY + depth}`} fill={darken(fill, .56)} stroke={darken(stroke, .7)} strokeWidth="2" />
      <polygon points={`${bounds.maxX},${bounds.minY} ${bounds.maxX},${bounds.maxY} ${bounds.maxX + depth * .45},${bounds.maxY + depth} ${bounds.maxX + depth * .45},${bounds.minY + depth}`} fill={darken(fill, .7)} stroke={darken(stroke, .75)} strokeWidth="2" />
    </>}
    <polygon
      points={pointString}
      fill={fill}
      stroke={stroke}
      strokeWidth={selected ? 6 : featured ? 4 : 2.5}
      opacity={geometry.neutral && !isService ? .72 : 1}
      className="transition-all duration-200"
      data-map-face="top"
      data-highlighted={exhibitor ? 'true' : 'false'}
      data-space-code={geometry.standCode}
      style={{ filter: selected ? 'url(#selectedGlow)' : featured ? 'url(#featuredGlow)' : undefined }}
    />
    <text x={center.x} y={center.y} textAnchor="middle" dominantBaseline="middle" fill="white" fontFamily="Plus Jakarta Sans, sans-serif" fontSize={labelSize} fontWeight="900" letterSpacing=".5" className="pointer-events-none">
      {geometry.standCode}
    </text>
    {exhibitor && (featured || favorite || visited || inRoute) && <g transform={`translate(${bounds.maxX - 34},${bounds.minY + 8})`}>
      <rect width="27" height="27" rx="13.5" fill="#0f172a" stroke={featured ? '#f9a8d4' : '#64748b'} strokeWidth="2" />
      {featured ? <Sparkles x="6" y="6" width="15" height="15" color="#f9a8d4" /> : favorite ? <Heart x="6" y="6" width="15" height="15" color="#fb7185" fill="#fb7185" /> : visited ? <CheckCircle2 x="6" y="6" width="15" height="15" color="#34d399" /> : <Bookmark x="6" y="6" width="15" height="15" color="#fbbf24" />}
    </g>}
  </g>
}

export const MapView25D: React.FC = () => {
  const geometries = useAdminMapStore(s => s.geometries)
  const exhibitors = useExhibitorStore(s => s.exhibitors)
  const selectedStandId = useMapStore(s => s.selectedStandId)
  const setSelectedStandId = useMapStore(s => s.setSelectedStandId)
  const setSelectedExhibitorId = useExhibitorStore(s => s.setSelectedExhibitorId)
  const userPosition = useMapStore(s => s.userPosition)
  const cameraMode = useMapStore(s => s.cameraMode)
  const favorites = useUserStore(s => s.favorites)
  const visits = useUserStore(s => s.visits)
  const routeStops = useUserStore(s => s.routeStops)
  const routeOriginGateId = useMapStore(s => s.routeOriginGateId)
  const setRouteOriginGateId = useMapStore(s => s.setRouteOriginGateId)
  const isometric = cameraMode === '2.5D'
  const { transform, containerRef, handlers, animateToStand, resetView, setTilt } = useMapInteraction({ initialTilt: isometric ? 35 : 0 })

  React.useEffect(() => {
    ;(window as any).__mapControls = { resetView, setTilt, animateToStand }
    return () => { delete (window as any).__mapControls }
  }, [resetView, setTilt, animateToStand])

  const visible = useMemo(() => {
    const databaseSpaces = geometries.filter(g => !g.neutral && g.verified && g.polygon.length >= 3)
    const databaseCodes = new Set(databaseSpaces.map(g => g.standCode.toUpperCase()))
    const officialSpaces = OFFICIAL_MAP_SPACES
      .filter(item => !databaseCodes.has(item.code.toUpperCase()))
      .map(officialSpaceToGeometry)
    return [...officialSpaces, ...databaseSpaces]
  }, [geometries])
  const select = (geo: any, exhibitor?: any) => {
    setSelectedStandId(geo.id)
    if (geo.routeOrigin) setRouteOriginGateId(geo.id)
    if (exhibitor) setSelectedExhibitorId(exhibitor.id)
    const x = geo.polygon.reduce((n: number, p: any) => n + p.x, 0) / geo.polygon.length
    const y = geo.polygon.reduce((n: number, p: any) => n + p.y, 0) / geo.polygon.length
    animateToStand(x, y)
  }
  const routePath = useMemo(() => {
    const origin = visible.find(geometry => geometry.id === routeOriginGateId)
    if (!origin || routeStops.length === 0) return ''
    const originCenter = geometryCenter(origin)
    const spineX = originCenter.x < 600 ? 300 : originCenter.x > 1250 ? 1710 : 1000
    const commands = [`M ${originCenter.x} ${originCenter.y}`, `L ${spineX} ${originCenter.y}`]
    routeStops.forEach(stop => {
      const destination = visible.find(geometry => geometry.exhibitorId === stop.exhibitorId)
      if (!destination) return
      const center = geometryCenter(destination)
      const aisle = AISLES.find(item => item.name.endsWith(destination.standCode.charAt(0)))
      const aisleY = (aisle?.y ?? center.y / MAP_ORIGINAL_HEIGHT) * MAP_ORIGINAL_HEIGHT
      commands.push(`L ${spineX} ${aisleY}`, `L ${center.x} ${aisleY}`, `L ${center.x} ${center.y}`, `L ${center.x} ${aisleY}`, `L ${spineX} ${aisleY}`)
    })
    return commands.join(' ')
  }, [routeOriginGateId, routeStops, visible])
  const user = userPosition ? { x: (userPosition.worldX / 40 + .5) * MAP_ORIGINAL_WIDTH, y: (.5 - userPosition.worldZ / 33.25) * MAP_ORIGINAL_HEIGHT } : null

  return <div
    ref={containerRef}
    data-testid="digital-map-25d"
    className="absolute inset-0 w-full h-full min-h-[520px] overflow-hidden select-none bg-[#07101b]"
    style={{ touchAction: 'none' }}
    {...handlers}
  >
    <div className="absolute inset-0 flex items-center justify-center p-3 sm:p-6">
      <div
        className="w-full h-full min-w-0 min-h-0 max-w-[1400px] transition-transform duration-300 ease-out"
        style={{
          transform: `translate3d(${transform.x}px, ${transform.y}px, 0) scale(${transform.zoom})`,
          transformOrigin: 'center center'
        }}
      >
        <svg
          viewBox={`${PUBLIC_MAP_VIEWBOX.x} ${PUBLIC_MAP_VIEWBOX.y} ${PUBLIC_MAP_VIEWBOX.width} ${PUBLIC_MAP_VIEWBOX.height}`}
          preserveAspectRatio="xMidYMid meet"
          width="100%"
          height="100%"
          className="block w-full h-full min-h-[480px] drop-shadow-2xl"
          role="img"
          aria-label="Mapa digital interativo da Bienal"
        >
          <defs>
            <linearGradient id="digitalFloor" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#172235"/><stop offset="1" stopColor="#0b1321"/></linearGradient>
            <pattern id="floorDots" width="30" height="30" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1.5" fill="#334155" opacity=".45"/></pattern>
            <filter id="selectedGlow"><feGaussianBlur stdDeviation="9" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
            <filter id="featuredGlow"><feDropShadow dx="0" dy="0" stdDeviation="6" floodColor="#ec4899" floodOpacity=".75"/></filter>
          </defs>
          <path d="M55 32 H1775 Q1880 32 1945 115 V1460 Q1945 1550 1850 1595 H145 Q55 1560 55 1470 Z" fill="url(#digitalFloor)" stroke="#475569" strokeWidth="8"/>
          <path d="M55 32 H1775 Q1880 32 1945 115 V1460 Q1945 1550 1850 1595 H145 Q55 1560 55 1470 Z" fill="url(#floorDots)"/>
          {AISLES.map(a => <g key={a.name}>
            <rect x="65" y={a.y * MAP_ORIGINAL_HEIGHT - 13} width={MAP_ORIGINAL_WIDTH * .82} height="26" rx="13" fill="#cbd5e1" opacity=".09" />
            <rect x={MAP_ORIGINAL_WIDTH * .69} y={a.y * MAP_ORIGINAL_HEIGHT - 18} width="82" height="36" rx="18" fill="#172033" stroke="#64748b" strokeWidth="2" />
            <text x={MAP_ORIGINAL_WIDTH * .69 + 41} y={a.y * MAP_ORIGINAL_HEIGHT + 1} textAnchor="middle" dominantBaseline="middle" fill="#cbd5e1" fontSize="15" fontWeight="900" letterSpacing="1">{a.name}</text>
          </g>)}
          {routePath && <g data-testid="gps-route" className="pointer-events-none">
            <path d={routePath} fill="none" stroke="#020617" strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" opacity=".75" />
            <path d={routePath} fill="none" stroke="#34d399" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="18 10" />
          </g>}
          {visible.map(geo => {
            const exhibitor = geo.neutral ? undefined : exhibitors.find(e => e.id === geo.exhibitorId)
            if (!geo.neutral && !exhibitor) return null
            return <StandItem key={geo.id} geometry={geo} exhibitor={exhibitor} selected={selectedStandId === geo.id} favorite={!!exhibitor && favorites.includes(exhibitor.id)} visited={!!exhibitor && Boolean(visits[exhibitor.id])} inRoute={!!exhibitor && routeStops.some(s => s.exhibitorId === exhibitor.id)} isometric={isometric} onSelect={() => select(geo, exhibitor)} />
          })}
          {user && <g transform={`translate(${user.x},${user.y})`}><circle r="26" fill="#10b981" opacity=".25" className="animate-ping"/><circle r="12" fill="#10b981" stroke="white" strokeWidth="4"/><text y="-23" textAnchor="middle" fill="#6ee7b7" fontSize="17" fontWeight="900">VOCÊ</text></g>}
          <g transform="translate(780 1610)"><path d="M0 0h466" stroke="#34d399" strokeWidth="8" strokeLinecap="round"/><text x="233" y="-13" textAnchor="middle" fill="#a7f3d0" fontSize="20" fontWeight="900" letterSpacing="3">ENTRADA DO PÚBLICO</text></g>
        </svg>
      </div>
    </div>
    <div className="absolute bottom-4 left-4 glass-panel px-3 py-2 rounded-xl border border-slate-700 text-xs font-bold text-slate-200 flex items-center gap-2 shadow-xl z-20"><Sparkles className="w-4 h-4 text-pink-400"/><span>Mapa digital {isometric ? '2.5D' : '2D'}</span><span className="text-slate-500">•</span><span className="text-indigo-300">{Math.round(transform.zoom * 100)}%</span></div>
    <div className="absolute top-4 left-4 rounded-xl bg-slate-950/85 border border-slate-700 px-3 py-2 text-[10px] sm:text-xs text-slate-300 shadow-xl pointer-events-none"><span className="text-violet-300 font-black">COLORIDO</span> expositor do banco • <span className="text-slate-400 font-black">CINZA</span> demais espaços</div>
  </div>
}
