import test from 'node:test'
import assert from 'node:assert/strict'
import { MAP_HEIGHT, MAP_WIDTH, OFFICIAL_LAYOUT_FEATURES, buildMapLayout } from '../../data/map/map-layout.ts'
import { validateLayout } from '../../services/mapLayoutValidationService.ts'
import {
  mapToReference,
  referenceToMap
} from '../../data/map/map-reference-calibration.ts'

test('layout usa o viewBox do novo guia 2D', () => {
  assert.equal(MAP_WIDTH, 1920)
  assert.equal(MAP_HEIGHT, 1080)
})

test('calibração respeita as âncoras do guia desenhado', () => {
  assert.deepEqual(referenceToMap({ x: 185, y: 1450 }), { x: 80, y: 190 })
  assert.equal(referenceToMap({ x: 5355, y: 1450 }).x, 1290)
  assert.equal(referenceToMap({ x: 6425, y: 1450 }).x, 1572)
  assert.equal(referenceToMap({ x: 7955, y: 1450 }).x, 1880)
  assert.equal(referenceToMap({ x: 185, y: 5480 }).y, 1080)
})

test('conversão referência/mapa é reversível', () => {
  const source = { x: 5370, y: 4435 }
  const restored = mapToReference(referenceToMap(source))
  assert.ok(Math.abs(restored.x - source.x) < 1e-9)
  assert.ok(Math.abs(restored.y - source.y) < 1e-9)
})

test('layout oficial não possui IDs duplicados, dimensões inválidas ou coordenadas externas', () => {
  const errors = validateLayout(buildMapLayout([]))
  assert.deepEqual(errors, [])
})

test('não existem espaços oficiais sem identificação', () => {
  assert.equal(OFFICIAL_LAYOUT_FEATURES.filter(feature => !feature.label && !feature.boothCode).length, 0)
})
