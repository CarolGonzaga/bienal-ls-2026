import test from 'node:test'
import assert from 'node:assert/strict'
import { boothAccessPoint, buildMapLayout } from '../../data/map/map-layout.ts'
import { INITIAL_STAND_GEOMETRIES } from '../../data/initialStands.ts'
import { buildRoutingGraph } from '../../data/map/map-routing-graph.ts'
import { findRoute, parseMapRouteParams } from '../../services/mapRoutingService.ts'
import { validateGraph, validateRouteObstacles } from '../../services/mapLayoutValidationService.ts'

const features = buildMapLayout(INITIAL_STAND_GEOMETRIES)
const graph = buildRoutingGraph(features)
const destination = features.find(feature => feature.boothCode === 'G36' && feature.exhibitorId)!

test('grafo não possui arestas apontando para nós inexistentes', () => {
  assert.deepEqual(validateGraph(graph), [])
})

test('encontra rota do Portão 8 até a borda do estande', () => {
  const route = findRoute(graph, 'P8', `access-${destination.id}`)
  assert.ok(route)
  assert.equal(route!.nodeIds[0], 'P8')
  assert.equal(route!.nodeIds.at(-1), `access-${destination.id}`)
  const access = boothAccessPoint(destination)
  const end = route!.points.at(-1)!
  assert.equal(end.x, access?.x)
  assert.equal(end.y, access?.y)
})

test('encontra rota entre dois estandes', () => {
  const other = features.find(feature => feature.boothCode === 'A58' && feature.exhibitorId)!
  assert.ok(findRoute(graph, `access-${destination.id}`, `access-${other.id}`))
})

test('todos os 29 expositores confirmados possuem acesso e rota pelo grafo', () => {
  const confirmed = features.filter(feature => feature.exhibitorId)
  assert.equal(confirmed.length, 29)
  confirmed.forEach(feature => assert.ok(findRoute(graph, 'P8', `access-${feature.id}`), feature.boothCode))
})

test('interpreta origin e destination da URL sem diferenciar maiúsculas', () => {
  assert.deepEqual(parseMapRouteParams('?origin=p9&destination=h70'), { origin: 'P9', destination: 'H70' })
})

test('origem ou destino inexistente retorna nulo', () => {
  assert.equal(findRoute(graph, 'inexistente', `access-${destination.id}`), null)
  assert.equal(findRoute(graph, 'P8', 'inexistente'), null)
})

test('rota bloqueada retorna nulo', () => {
  const blocked = { ...graph, edges: graph.edges.map(edge => ({ ...edge, blocked: true })) }
  assert.equal(findRoute(blocked, 'P8', `access-${destination.id}`), null)
})

test('arestas caminháveis não atravessam estandes ou áreas fechadas', () => {
  assert.deepEqual(validateRouteObstacles(graph, features), [])
})
