import React from 'react'
import type { CalculatedRoute } from '../../services/mapRoutingService.ts'

export const MapRoute: React.FC<{ route: CalculatedRoute | null }> = ({ route }) => {
  if (!route || route.points.length < 2) return null
  const d = route.points.map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`).join(' ')
  const origin = route.points[0]
  const destination = route.points[route.points.length - 1]
  return <g id="route-layer" data-testid="gps-route" className="pointer-events-none">
    <path d={d} fill="none" stroke="#fff" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    <path d={d} fill="none" stroke="#0d9488" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    <g transform={`translate(${origin.x} ${origin.y})`}><circle r="8" fill="#0d9488" stroke="#fff" strokeWidth="3" vectorEffect="non-scaling-stroke"/><circle r="2.5" fill="#fff"/></g>
    <g transform={`translate(${destination.x} ${destination.y})`}><circle r="9" fill="#e11d78" stroke="#fff" strokeWidth="3" vectorEffect="non-scaling-stroke"/><circle r="3" fill="#fff"/></g>
  </g>
}
