import type { Point2D } from '../../types/index.ts'
import { MAP_STREETS, boothAccessPoint, type MapFeature } from './map-layout.ts'
import { referenceToMap } from './map-reference-calibration.ts'

export interface RouteNode extends Point2D {
  id: string
  type: 'intersection' | 'gate' | 'entrance' | 'booth-access' | 'service-access'
  label?: string
  featureId?: string
}

export interface RouteEdge {
  id: string
  from: string
  to: string
  distance: number
  streetId?: string
  accessible: boolean
  blocked: boolean
  bidirectional: boolean
}

export interface RoutingGraph { nodes: RouteNode[]; edges: RouteEdge[] }

const distance = (a: Point2D, b: Point2D) => Math.hypot(a.x - b.x, a.y - b.y)
const centralSpineX = referenceToMap({ x: 3500, y: 0 }).x

export const buildRoutingGraph = (features: MapFeature[]): RoutingGraph => {
  const nodes: RouteNode[] = []
  const edges: RouteEdge[] = []
  const byStreet = new Map<string, RouteNode[]>()

  MAP_STREETS.forEach(street => {
    const streetNodes = [{ id: `${street.id}-central`, x: centralSpineX, y: street.centerline[0].y, type: 'intersection' as const, label: street.name }]
    byStreet.set(street.id, streetNodes)
    nodes.push(...streetNodes)
  })

  features.filter(feature => feature.type === 'booth' && feature.boothCode && feature.interactive && feature.exhibitorId).forEach(feature => {
    const access = feature.entrances?.[0] || boothAccessPoint(feature)
    if (!access) return
    const street = MAP_STREETS.find(item => item.name.endsWith(feature.boothCode!.charAt(0)))
    if (!street) return
    const streetNode: RouteNode = { id: `street-access-${feature.id}`, x: access.x, y: street.centerline[0].y, type: 'intersection', label: street.name }
    const accessNode: RouteNode = { id: `access-${feature.id}`, x: access.x, y: access.y, type: 'booth-access', label: feature.boothCode, featureId: feature.id }
    byStreet.get(street.id)!.push(streetNode)
    nodes.push(streetNode, accessNode)
    edges.push({ id: `edge-${streetNode.id}-${accessNode.id}`, from: streetNode.id, to: accessNode.id, distance: distance(streetNode, accessNode), streetId: street.id, accessible: true, blocked: false, bidirectional: true })
  })

  MAP_STREETS.forEach(street => {
    const ordered = byStreet.get(street.id)!.sort((a, b) => a.x - b.x)
    for (let index = 1; index < ordered.length; index += 1) {
      edges.push({ id: `edge-${ordered[index - 1].id}-${ordered[index].id}`, from: ordered[index - 1].id, to: ordered[index].id, distance: distance(ordered[index - 1], ordered[index]), streetId: street.id, accessible: true, blocked: false, bidirectional: true })
    }
  })

  const spineNodes = MAP_STREETS.map(street => nodes.find(node => node.id === `${street.id}-central`)!)
  for (let index = 1; index < spineNodes.length; index += 1) {
    edges.push({ id: `edge-${spineNodes[index - 1].id}-${spineNodes[index].id}`, from: spineNodes[index - 1].id, to: spineNodes[index].id, distance: distance(spineNodes[index - 1], spineNodes[index]), accessible: true, blocked: false, bidirectional: true })
  }

  const northY = referenceToMap({ x: 0, y: 1410 }).y
  const southY = referenceToMap({ x: 0, y: 4810 }).y
  const northHub: RouteNode = { id: 'north-hub', x: centralSpineX, y: northY, type: 'intersection', label: 'Acesso norte' }
  const southHub: RouteNode = { id: 'south-hub', x: centralSpineX, y: southY, type: 'intersection', label: 'Entrada pública' }
  nodes.push(northHub, southHub)
  const streetK = nodes.find(node => node.id === 'street-k-central')!
  const streetA = nodes.find(node => node.id === 'street-a-central')!
  edges.push({ id: 'edge-north-hub-k', from: northHub.id, to: streetK.id, distance: distance(northHub, streetK), accessible: true, blocked: false, bidirectional: true })
  edges.push({ id: 'edge-south-hub-a', from: southHub.id, to: streetA.id, distance: distance(southHub, streetA), accessible: true, blocked: false, bidirectional: true })

  features.filter(feature => feature.type === 'gate' && feature.metadata?.routeOrigin).forEach(feature => {
    if (feature.geometry.type !== 'rect') return
    const node: RouteNode = { id: feature.label?.replace('Portão ', 'P') || feature.id, x: feature.geometry.x + feature.geometry.width / 2, y: feature.geometry.y + feature.geometry.height / 2, type: 'gate', label: feature.label, featureId: feature.id }
    nodes.push(node)
    const perimeter: RouteNode = { id: `${node.id}-perimeter`, x: node.x, y: node.id === 'P5' ? southY : northY, type: 'entrance', label: node.label }
    nodes.push(perimeter)
    const hub = node.id === 'P5' ? southHub : northHub
    edges.push({ id: `edge-${node.id}-${perimeter.id}`, from: node.id, to: perimeter.id, distance: distance(node, perimeter), accessible: true, blocked: false, bidirectional: true })
    edges.push({ id: `edge-${perimeter.id}-${hub.id}`, from: perimeter.id, to: hub.id, distance: distance(perimeter, hub), accessible: true, blocked: false, bidirectional: true })
  })

  return { nodes, edges }
}
