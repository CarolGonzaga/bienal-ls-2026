import type { Point2D } from '../types/index.ts'
import type { RouteEdge, RouteNode, RoutingGraph } from '../data/map/map-routing-graph.ts'

export interface CalculatedRoute {
  nodeIds: string[]
  points: Point2D[]
  distance: number
  instructions: string[]
}

export const parseMapRouteParams = (search: string) => {
  const params = new URLSearchParams(search)
  return { origin: params.get('origin')?.trim().toUpperCase() || null, destination: params.get('destination')?.trim().toUpperCase() || null }
}

export const findRoute = (graph: RoutingGraph, originId: string, destinationId: string): CalculatedRoute | null => {
  const nodeMap = new Map(graph.nodes.map(node => [node.id, node]))
  if (!nodeMap.has(originId) || !nodeMap.has(destinationId)) return null
  const adjacency = new Map<string, Array<{ node: string; edge: RouteEdge }>>()
  graph.nodes.forEach(node => adjacency.set(node.id, []))
  graph.edges.filter(edge => !edge.blocked && edge.accessible).forEach(edge => {
    adjacency.get(edge.from)?.push({ node: edge.to, edge })
    if (edge.bidirectional) adjacency.get(edge.to)?.push({ node: edge.from, edge })
  })
  const distances = new Map(graph.nodes.map(node => [node.id, Number.POSITIVE_INFINITY]))
  const previous = new Map<string, string>()
  const unvisited = new Set(graph.nodes.map(node => node.id))
  distances.set(originId, 0)
  while (unvisited.size) {
    let current: string | null = null
    unvisited.forEach(id => { if (current === null || distances.get(id)! < distances.get(current)!) current = id })
    if (current === null || distances.get(current) === Number.POSITIVE_INFINITY) break
    unvisited.delete(current)
    if (current === destinationId) break
    adjacency.get(current)?.forEach(({ node, edge }) => {
      if (!unvisited.has(node)) return
      const candidate = distances.get(current!)! + edge.distance
      if (candidate < distances.get(node)!) { distances.set(node, candidate); previous.set(node, current!) }
    })
  }
  if (!previous.has(destinationId) && originId !== destinationId) return null
  const nodeIds = [destinationId]
  while (nodeIds[0] !== originId) nodeIds.unshift(previous.get(nodeIds[0])!)
  const points = nodeIds.map(id => nodeMap.get(id)!)
  return { nodeIds, points, distance: distances.get(destinationId)!, instructions: buildDirections(points) }
}

const directionBetween = (a: Point2D, b: Point2D) => Math.abs(b.x - a.x) > Math.abs(b.y - a.y) ? (b.x > a.x ? 'leste' : 'oeste') : (b.y > a.y ? 'sul' : 'norte')

export const buildDirections = (points: RouteNode[]): string[] => {
  if (points.length < 2) return []
  const instructions = [`Saia de ${points[0].label || 'sua origem'}.`]
  let lastDirection = directionBetween(points[0], points[1])
  for (let index = 1; index < points.length - 1; index += 1) {
    const nextDirection = directionBetween(points[index], points[index + 1])
    if (nextDirection !== lastDirection) {
      instructions.push(`No próximo cruzamento, siga para ${nextDirection}.`)
      lastDirection = nextDirection
    }
  }
  const destination = points[points.length - 1]
  instructions.push(`Chegue ao acesso ${destination.label || 'do destino'}.`)
  return instructions
}
