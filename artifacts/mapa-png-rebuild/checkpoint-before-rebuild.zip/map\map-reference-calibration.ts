import type { Point2D } from '../../types/index.ts'

/** Native coordinate system used by the transcribed official-space database. */
export const REFERENCE_WIDTH = 7955
export const REFERENCE_HEIGHT = 6436

/** New 2D guide supplied as MAPA.png. */
export const GUIDE_WIDTH = 1920
export const GUIDE_HEIGHT = 1080
export const MAP_VIEWBOX_WIDTH = GUIDE_WIDTH
export const MAP_VIEWBOX_HEIGHT = GUIDE_HEIGHT

const X_MAIN_SOURCE_START = 185
const X_MAIN_SOURCE_END = 5355
const X_CONNECTOR_SOURCE_END = 6425
const X_MAIN_MAP_START = 80
const X_MAIN_MAP_END = 1290
const X_CONNECTOR_MAP_END = 1572
const X_EAST_MAP_END = 1880

const Y_SOURCE_START = 1450
const Y_SOURCE_BREAK = 5180
const Y_SOURCE_END = 5480
const Y_MAP_START = 190
const Y_MAP_BREAK = 1053
const Y_MAP_END = 1080

const mapLinear = (value: number, sourceA: number, sourceB: number, targetA: number, targetB: number) =>
  targetA + (value - sourceA) * (targetB - targetA) / (sourceB - sourceA)

const referenceXToMap = (x: number) => {
  if (x <= X_MAIN_SOURCE_END) return mapLinear(x, X_MAIN_SOURCE_START, X_MAIN_SOURCE_END, X_MAIN_MAP_START, X_MAIN_MAP_END)
  if (x <= X_CONNECTOR_SOURCE_END) return mapLinear(x, X_MAIN_SOURCE_END, X_CONNECTOR_SOURCE_END, X_MAIN_MAP_END, X_CONNECTOR_MAP_END)
  return mapLinear(x, X_CONNECTOR_SOURCE_END, REFERENCE_WIDTH, X_CONNECTOR_MAP_END, X_EAST_MAP_END)
}

const mapXToReference = (x: number) => {
  if (x <= X_MAIN_MAP_END) return mapLinear(x, X_MAIN_MAP_START, X_MAIN_MAP_END, X_MAIN_SOURCE_START, X_MAIN_SOURCE_END)
  if (x <= X_CONNECTOR_MAP_END) return mapLinear(x, X_MAIN_MAP_END, X_CONNECTOR_MAP_END, X_MAIN_SOURCE_END, X_CONNECTOR_SOURCE_END)
  return mapLinear(x, X_CONNECTOR_MAP_END, X_EAST_MAP_END, X_CONNECTOR_SOURCE_END, REFERENCE_WIDTH)
}

const referenceYToMap = (y: number) => y <= Y_SOURCE_BREAK
  ? mapLinear(y, Y_SOURCE_START, Y_SOURCE_BREAK, Y_MAP_START, Y_MAP_BREAK)
  : mapLinear(y, Y_SOURCE_BREAK, Y_SOURCE_END, Y_MAP_BREAK, Y_MAP_END)

const mapYToReference = (y: number) => y <= Y_MAP_BREAK
  ? mapLinear(y, Y_MAP_START, Y_MAP_BREAK, Y_SOURCE_START, Y_SOURCE_BREAK)
  : mapLinear(y, Y_MAP_BREAK, Y_MAP_END, Y_SOURCE_BREAK, Y_SOURCE_END)

export const referenceToMap = (point: Point2D): Point2D => ({
  x: referenceXToMap(point.x),
  y: referenceYToMap(point.y)
})

export const mapToReference = (point: Point2D): Point2D => ({
  x: mapXToReference(point.x),
  y: mapYToReference(point.y)
})

export const referenceLengthToMap = (value: number) => value * (Y_MAP_BREAK - Y_MAP_START) / (Y_SOURCE_BREAK - Y_SOURCE_START)

export const referenceBoundsToMap = ([x1, y1, x2, y2]: [number, number, number, number]) => {
  const topLeft = referenceToMap({ x: x1, y: y1 })
  const bottomRight = referenceToMap({ x: x2, y: y2 })
  return {
    x: topLeft.x,
    y: topLeft.y,
    width: bottomRight.x - topLeft.x,
    height: bottomRight.y - topLeft.y
  }
}

export const referencePolygonToMap = (points: Point2D[]) => points.map(referenceToMap)

export const screenToMap = (clientPoint: Point2D, screenMatrix: DOMMatrix): Point2D => {
  const inverse = screenMatrix.inverse()
  return {
    x: inverse.a * clientPoint.x + inverse.c * clientPoint.y + inverse.e,
    y: inverse.b * clientPoint.x + inverse.d * clientPoint.y + inverse.f
  }
}
