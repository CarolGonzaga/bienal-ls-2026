import React from 'react'
import { useAdminMapStore } from '../../stores/useAdminMapStore'
import { useExhibitorStore } from '../../stores/useExhibitorStore'
import { useMapStore } from '../../stores/useMapStore'
import { MAP_ORIGINAL_WIDTH, MAP_ORIGINAL_HEIGHT } from '../../utils/coordinates'
import { Sparkles } from 'lucide-react'

export const MapView2D: React.FC = () => {
  const geometries = useAdminMapStore(s => s.geometries)
  const exhibitors = useExhibitorStore(s => s.exhibitors)
  const selectedStandId = useMapStore(s => s.selectedStandId)
  const setSelectedStandId = useMapStore(s => s.setSelectedStandId)
  const setSelectedExhibitorId = useExhibitorStore(s => s.setSelectedExhibitorId)

  const currentVersion = useAdminMapStore(s => s.currentVersion)

  const verifiedGeometries = geometries.filter(g => g.verified)

  return (
    <div className="w-full h-full relative bg-[#070b14] flex items-center justify-center p-4 overflow-hidden">
      <div className="relative w-full h-full max-w-5xl flex items-center justify-center">
        <svg
          viewBox={`0 0 ${MAP_ORIGINAL_WIDTH} ${MAP_ORIGINAL_HEIGHT}`}
          preserveAspectRatio="xMidYMid meet"
          className="w-full h-full max-h-full rounded-2xl glass-panel border border-slate-800 p-2 shadow-2xl"
        >
          {/* Background Floor Grid */}
          <rect width={MAP_ORIGINAL_WIDTH} height={MAP_ORIGINAL_HEIGHT} fill="#0b1120" rx="20" />

          {/* Grid lines */}
          <defs>
            <pattern id="grid2d" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#1e293b" strokeWidth="2" />
            </pattern>
          </defs>
          <rect width={MAP_ORIGINAL_WIDTH} height={MAP_ORIGINAL_HEIGHT} fill="url(#grid2d)" />

          {/* Official Base Map Image */}
          {currentVersion.backgroundAsset && (
            <image
              href={currentVersion.backgroundAsset}
              width={MAP_ORIGINAL_WIDTH}
              height={MAP_ORIGINAL_HEIGHT}
              opacity={0.88}
              preserveAspectRatio="xMidYMid meet"
            />
          )}

          {/* Polygons */}
          {verifiedGeometries.map((geo) => {
            if (geo.polygon.length === 0) return null

            const pointsSvgStr = geo.polygon
              .map(p => `${p.x * MAP_ORIGINAL_WIDTH},${p.y * MAP_ORIGINAL_HEIGHT}`)
              .join(' ')

            const isSelected = selectedStandId === geo.id
            const exhibitor = exhibitors.find(e => e.id === geo.exhibitorId)

            if (geo.neutral) {
              return (
                <polygon
                  key={geo.id}
                  points={pointsSvgStr}
                  fill="#1e293b"
                  stroke="#334155"
                  strokeWidth="3"
                  opacity="0.7"
                />
              )
            }

            if (!exhibitor) return null

            const isCuradoria = exhibitor.relevanceLevel === 'curadoria_direta'

            return (
              <g
                key={geo.id}
                onClick={() => {
                  setSelectedStandId(geo.id)
                  setSelectedExhibitorId(exhibitor.id)
                }}
                className="cursor-pointer transition-all duration-200"
              >
                <polygon
                  points={pointsSvgStr}
                  fill={isSelected ? '#38bdf8' : (isCuradoria ? '#ec4899' : '#6366f1')}
                  stroke={isSelected ? '#ffffff' : (isCuradoria ? '#f472b6' : '#818cf8')}
                  strokeWidth={isSelected ? '8' : '4'}
                  opacity={isSelected ? 1 : 0.85}
                  className="hover:opacity-100 transition-opacity"
                />

                {/* Text Label inside Polygon */}
                {geo.polygon.length > 0 && (
                  <text
                    x={geo.polygon[0].x * MAP_ORIGINAL_WIDTH + 20}
                    y={geo.polygon[0].y * MAP_ORIGINAL_HEIGHT + 35}
                    fill="#ffffff"
                    fontSize="28"
                    fontWeight="800"
                    fontFamily="sans-serif"
                    className="pointer-events-none select-none drop-shadow-md"
                  >
                    {geo.standCode}
                  </text>
                )}
              </g>
            )
          })}
        </svg>

        {/* 2D Calibration Notice Overlay */}
        <div className="absolute bottom-4 left-4 right-4 bg-slate-900/90 backdrop-blur-md px-4 py-2.5 rounded-xl border border-indigo-500/30 text-indigo-300 text-xs font-semibold flex items-center justify-between shadow-lg pointer-events-none">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-pink-400 animate-pulse" />
            <span>Modo 2D Vetorial &bull; Planta Oficial Calibrada (2026 &times; 1684)</span>
          </div>
          <span className="hidden sm:inline text-slate-400">Clique em qualquer estande para focar</span>
        </div>
      </div>
    </div>
  )
}
