import React from 'react'
import { 
  MapPin, 
  Activity, 
  Zap, 
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Sun,
  Moon,
  Navigation
} from 'lucide-react'
import { useMapStore, GraphicsQuality } from '../../stores/useMapStore'
import { toWorldCoordinates } from '../../utils/coordinates'

export const MapControls: React.FC<{ panelOpen?: boolean }> = ({ panelOpen = false }) => {
  const graphicsQuality = useMapStore(s => s.graphicsQuality)
  const reducedMotion = useMapStore(s => s.reducedMotion)
  const mapTheme = useMapStore(s => s.mapTheme)
  
  const setGraphicsQuality = useMapStore(s => s.setGraphicsQuality)
  const setReducedMotion = useMapStore(s => s.setReducedMotion)
  const setMapTheme = useMapStore(s => s.setMapTheme)
  const setUserPosition = useMapStore(s => s.setUserPosition)

  const handleSetUserPin = () => {
    setUserPosition(toWorldCoordinates(0.5, 0.5))
  }

  const handleResetView = () => {
    const ctrl = (window as any).__mapControls
    if (ctrl?.resetView) ctrl.resetView()
  }

  const handleZoom = (direction: 'in' | 'out') => {
    const ctrl = (window as any).__mapControls
    if (direction === 'in') ctrl?.zoomIn?.()
    else ctrl?.zoomOut?.()
  }

  const focus = (target: 'focusRoute' | 'focusOrigin' | 'focusDestination') => {
    const ctrl = (window as any).__mapControls
    ctrl?.[target]?.()
  }

  return (
    <div className={`absolute right-2 top-20 z-[60] w-56 max-w-[calc(100%-1rem)] flex-col gap-2 pointer-events-auto sm:top-4 sm:w-64 ${panelOpen ? 'hidden sm:flex sm:right-[466px]' : 'flex sm:right-4'}`}>
      {/* View Controls */}
      <div className="glass-panel p-2 rounded-2xl flex flex-col gap-1.5 border border-slate-700/80 shadow-xl">
        <div className="grid grid-cols-2 gap-1" aria-label="Controles de zoom">
          <button aria-label="Diminuir zoom" onClick={() => handleZoom('out')} className="map-control-button"><ZoomOut className="w-4 h-4" /></button>
          <button aria-label="Aumentar zoom" onClick={() => handleZoom('in')} className="map-control-button"><ZoomIn className="w-4 h-4" /></button>
        </div>
        <button onClick={() => focus('focusRoute')} className="flex min-h-10 items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-semibold text-slate-300 hover:bg-slate-800/80 hover:text-white">
          <Navigation className="w-4 h-4 text-teal-400"/><span>Enquadrar rota</span>
        </button>
        <div className="grid grid-cols-2 gap-1">
          <button onClick={() => focus('focusOrigin')} className="map-control-button text-[10px]">Origem</button>
          <button onClick={() => focus('focusDestination')} className="map-control-button text-[10px]">Destino</button>
        </div>
        <button
          onClick={handleResetView}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all text-left"
          title="Centralizar Mapa"
        >
          <RotateCcw className="w-4 h-4 text-purple-400" />
          <span>Centralizar</span>
        </button>

        <button
          onClick={handleSetUserPin}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all text-left"
          title="Minha localização no mapa (Marcação Manual)"
        >
          <MapPin className="w-4 h-4 text-emerald-400" />
          <span>Minha Posição</span>
        </button>
      </div>

      {/* Accessibility & Graphics Modes */}
      <div className="glass-panel p-2 rounded-2xl flex flex-col gap-2 border border-slate-700/80 shadow-xl">
        <button data-testid="map-theme-toggle" onClick={(event) => { event.stopPropagation(); setMapTheme(mapTheme === 'light' ? 'dark' : 'light') }} className="flex min-h-10 items-center justify-between rounded-xl border border-slate-700 px-2.5 py-1.5 text-xs font-semibold text-slate-200">
          <span>Tema {mapTheme === 'light' ? 'claro' : 'escuro'}</span>{mapTheme === 'light' ? <Sun className="w-4 h-4 text-amber-300"/> : <Moon className="w-4 h-4 text-indigo-300"/>}
        </button>
        <div className="flex items-center justify-between px-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Qualidade</span>
          <Zap className="w-3 h-3 text-amber-400" />
        </div>

        <div className="grid grid-cols-3 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 text-[10px] font-bold">
          {(['auto', 'high', 'eco'] as GraphicsQuality[]).map((q) => (
            <button
              key={q}
              onClick={() => setGraphicsQuality(q)}
              className={`py-1 rounded transition-all capitalize ${
                graphicsQuality === q ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              {q === 'auto' ? 'Auto' : q === 'high' ? 'Qual' : 'Eco'}
            </button>
          ))}
        </div>

        <button
          onClick={() => setReducedMotion(!reducedMotion)}
          className={`flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-all ${
            reducedMotion 
              ? 'bg-amber-950/60 border-amber-600/50 text-amber-300' 
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="text-[11px]">Reduzir Movimentos</span>
          <Activity className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  )
}
