import React, { useEffect, useState } from 'react'
import {
  GUIDE_HEIGHT,
  GUIDE_WIDTH
} from '../../data/map/map-reference-calibration.ts'

export type ReferenceComparisonMode = 'normal' | 'contour' | 'difference'

interface Props {
  enabled: boolean
  opacity: number
  mode: ReferenceComparisonMode
  asset: string
}

export const MapReferenceLayer: React.FC<Props> = ({ enabled, opacity, mode, asset }) => {
  const [loadedAsset, setLoadedAsset] = useState<string | null>(null)

  useEffect(() => {
    if (!enabled || loadedAsset) return
    const image = new Image()
    image.decoding = 'async'
    image.onload = () => setLoadedAsset(asset)
    image.src = asset
    return () => { image.onload = null }
  }, [asset, enabled, loadedAsset])

  if (!enabled || opacity <= 0 || !loadedAsset) return null

  const filter = mode === 'contour' ? 'url(#reference-contour)' : undefined
  const style = mode === 'difference' ? { mixBlendMode: 'difference' as const } : undefined
  return <g id="reference-layer" opacity={opacity} pointerEvents="none" style={style}>
    <image
      href={loadedAsset}
      x={0}
      y={0}
      width={GUIDE_WIDTH}
      height={GUIDE_HEIGHT}
      preserveAspectRatio="xMinYMin meet"
      filter={filter}
    />
  </g>
}
