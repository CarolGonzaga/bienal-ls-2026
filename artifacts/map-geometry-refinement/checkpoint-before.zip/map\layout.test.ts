import test from 'node:test'
import assert from 'node:assert/strict'
import { MAP_HEIGHT, MAP_WIDTH, OFFICIAL_LAYOUT_FEATURES, buildMapLayout } from '../../data/map/map-layout.ts'
import { validateLayout } from '../../services/mapLayoutValidationService.ts'

test('layout usa o viewBox obrigatório', () => {
  assert.equal(MAP_WIDTH, 1376)
  assert.equal(MAP_HEIGHT, 1118)
})

test('layout oficial não possui IDs duplicados, dimensões inválidas ou coordenadas externas', () => {
  const errors = validateLayout(buildMapLayout([]))
  assert.deepEqual(errors, [])
})

test('não existem espaços oficiais sem identificação', () => {
  assert.equal(OFFICIAL_LAYOUT_FEATURES.filter(feature => !feature.label && !feature.boothCode).length, 0)
})
