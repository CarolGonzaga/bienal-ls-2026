import type { Point2D, StandGeometry } from '../../types/index.ts'
import { OFFICIAL_MAP_SPACES, OFFICIAL_SOURCE_HEIGHT, OFFICIAL_SOURCE_WIDTH } from '../officialMapSpaces.ts'

export const MAP_WIDTH = 1376
export const MAP_HEIGHT = 1118
export const MAP_REFERENCE_ASSET = '/mapa/mapa-bienal-referencia.jpeg'
export const MAP_GRID_SIZE = 37

export type MapFeatureType = 'booth' | 'street' | 'gate' | 'entrance' | 'exit' | 'bathroom' | 'food' | 'stage' | 'service' | 'special-area' | 'external-area' | 'wall' | 'obstacle' | 'information'
export type RectGeometry = { type: 'rect'; x: number; y: number; width: number; height: number; rotation?: number }
export type PolygonGeometry = { type: 'polygon'; points: Point2D[] }
export type MapGeometry = RectGeometry | PolygonGeometry

export interface MapFeature {
  id: string
  type: MapFeatureType
  label?: string
  geometry: MapGeometry
  boothCode?: string
  exhibitorId?: string
  category?: string
  interactive?: boolean
  walkable?: boolean
  entrances?: Point2D[]
  zIndex?: number
  needsReview?: boolean
  metadata?: Record<string, unknown>
}

export interface MapStreet {
  id: string
  name: string
  centerline: Point2D[]
  width: number
  labelPosition: Point2D
}

const sx = (value: number) => value / OFFICIAL_SOURCE_WIDTH * MAP_WIDTH
const sy = (value: number) => value / OFFICIAL_SOURCE_HEIGHT * MAP_HEIGHT

const streetSourceY: Record<string, number> = {
  K: 1915, J: 2217, H: 2490, G: 2780, F: 3055,
  E: 3345, D: 3614, C: 3956, B: 4253, A: 4515
}

export const MAP_STREETS: MapStreet[] = Object.entries(streetSourceY).map(([letter, y]) => ({
  id: `street-${letter.toLowerCase()}`,
  name: `Rua ${letter}`,
  centerline: [{ x: sx(900), y: sy(y) }, { x: sx(6720), y: sy(y) }],
  width: letter === 'E' || letter === 'C' ? 25 : 22,
  labelPosition: { x: sx(6030), y: sy(y) }
}))

export const MAP_BUILDINGS: MapFeature[] = [
  {
    id: 'pavilion-main', type: 'wall', label: 'Pavilhão principal', zIndex: 1,
    geometry: { type: 'polygon', points: [{ x: 31, y: 258 }, { x: 930, y: 258 }, { x: 930, y: 862 }, { x: 31, y: 862 }] },
    needsReview: true
  },
  {
    id: 'pavilion-east', type: 'wall', label: 'Pavilhão leste', zIndex: 1,
    geometry: { type: 'polygon', points: [{ x: 1141, y: 595 }, { x: 1374, y: 595 }, { x: 1374, y: 864 }, { x: 1141, y: 864 }] },
    needsReview: true
  },
  {
    id: 'pavilion-connector', type: 'external-area', zIndex: 2, walkable: true,
    geometry: { type: 'polygon', points: [{ x: 929, y: 657 }, { x: 1142, y: 657 }, { x: 1142, y: 694 }, { x: 929, y: 694 }] },
    needsReview: true
  },
  {
    id: 'external-north', type: 'external-area', zIndex: 0,
    geometry: { type: 'polygon', points: [{ x: 35, y: 155 }, { x: 520, y: 172 }, { x: 920, y: 190 }, { x: 920, y: 222 }, { x: 42, y: 207 }] },
    needsReview: true
  },
  {
    id: 'external-south', type: 'external-area', zIndex: 0,
    geometry: { type: 'polygon', points: [{ x: 28, y: 862 }, { x: 1145, y: 862 }, { x: 1145, y: 945 }, { x: 28, y: 945 }] },
    needsReview: true
  }
]

const serviceTypeMap: Record<string, MapFeatureType> = {
  restroom: 'bathroom', gate: 'gate', medical: 'service', food: 'food', info: 'information', accessibility: 'service', stage: 'stage'
}

const NEEDS_REVIEW_CODES = new Set(['+', 'AUTÓGRAFOS 1', 'AUTÓGRAFOS 2', 'FOOD LESTE', 'FOOD CENTRAL', 'PROFESSORES'])

export const OFFICIAL_LAYOUT_FEATURES: MapFeature[] = OFFICIAL_MAP_SPACES.map(item => {
  const [x1, y1, x2, y2] = item.bounds
  const type = item.serviceType ? serviceTypeMap[item.serviceType] : 'booth'
  const feature: MapFeature = {
    id: `official-${type}-${item.code || 'unlabeled'}-${x1}-${y1}`,
    type,
    label: item.displayName || item.code || undefined,
    boothCode: type === 'booth' ? item.code : undefined,
    interactive: type === 'booth' || Boolean(item.serviceType),
    walkable: false,
    geometry: { type: 'rect', x: sx(x1), y: sy(y1), width: sx(x2 - x1), height: sy(y2 - y1) },
    zIndex: type === 'booth' ? 7 : 10,
    needsReview: !item.code || NEEDS_REVIEW_CODES.has(item.code),
    metadata: { serviceType: item.serviceType, routeOrigin: item.routeOrigin, navigable: type !== 'booth', sourceBounds: item.bounds }
  }
  return feature
})

export const boothAccessPoint = (feature: MapFeature): Point2D | null => {
  if (feature.geometry.type !== 'rect' || !feature.boothCode) return null
  const street = MAP_STREETS.find(item => item.name.endsWith(feature.boothCode!.charAt(0)))
  if (!street) return null
  const rect = feature.geometry
  const streetY = street.centerline[0].y
  const centerY = rect.y + rect.height / 2
  return { x: rect.x + rect.width / 2, y: streetY > centerY ? rect.y + rect.height : rect.y }
}

export const databaseGeometriesToFeatures = (geometries: StandGeometry[]): MapFeature[] => geometries
  .filter(item => !item.neutral && item.verified && item.polygon.length >= 3)
  .map(item => {
    const points = item.polygon.map(point => ({ x: point.x * MAP_WIDTH, y: point.y * MAP_HEIGHT }))
    const xs = points.map(point => point.x)
    const ys = points.map(point => point.y)
    const geometry: RectGeometry = { type: 'rect', x: Math.min(...xs), y: Math.min(...ys), width: Math.max(...xs) - Math.min(...xs), height: Math.max(...ys) - Math.min(...ys) }
    const feature: MapFeature = {
      id: item.id,
      type: 'booth',
      label: item.standCode,
      boothCode: item.standCode,
      exhibitorId: item.exhibitorId,
      interactive: true,
      walkable: false,
      geometry,
      zIndex: 8,
      needsReview: false,
      metadata: { navigable: true }
    }
    const access = boothAccessPoint(feature)
    if (access) feature.entrances = [access]
    return feature
  })

export const buildMapLayout = (databaseGeometries: StandGeometry[]): MapFeature[] => {
  const database = databaseGeometriesToFeatures(databaseGeometries)
  const occupiedCodes = new Set(database.map(item => item.boothCode?.toUpperCase()))
  const official = OFFICIAL_LAYOUT_FEATURES.filter(item => !item.boothCode || !occupiedCodes.has(item.boothCode.toUpperCase()))
  return [...MAP_BUILDINGS, ...official, ...database]
}
