import React, { memo } from 'react'
import { Heart, Bookmark, CheckCircle2, Sparkles } from 'lucide-react'
import type { Exhibitor } from '../../types/index.ts'
import type { MapFeature, RectGeometry } from '../../data/map/map-layout.ts'

interface MapBoothProps {
  feature: MapFeature
  exhibitor?: Exhibitor
  selected: boolean
  favorite: boolean
  visited: boolean
  inRoute: boolean
  isometric: boolean
  zoom: number
  dark: boolean
  onSelect: () => void
}

const darker = (color: string) => color === '#e11d78' ? '#9d174d' : color === '#4f46e5' ? '#312e81' : color === '#7c3aed' ? '#4c1d95' : '#9ca3af'

export const MapBooth = memo<MapBoothProps>(({ feature, exhibitor, selected, favorite, visited, inRoute, isometric, zoom, dark, onSelect }) => {
  if (feature.geometry.type !== 'rect') return null
  const rect = feature.geometry as RectGeometry
  const isBooth = feature.type === 'booth'
  const isService = !isBooth
  const featured = exhibitor?.relevanceLevel === 'curadoria_direta'
  const catalog = exhibitor?.relevanceLevel === 'catalogo_confirmado'
  const fill = selected ? '#0284c7' : featured ? '#e11d78' : catalog ? '#4f46e5' : exhibitor ? '#7c3aed' : dark ? '#334155' : isService ? '#e2e8f0' : '#eef1f4'
  const stroke = selected ? '#075985' : exhibitor ? darker(fill) : dark ? '#64748b' : '#94a3b8'
  const gap = Math.min(3.8, rect.width * .09, rect.height * .14)
  const x = rect.x + gap
  const y = rect.y + gap
  const width = Math.max(1, rect.width - gap * 2)
  const height = Math.max(1, rect.height - gap * 2)
  const depth = isometric && isBooth ? Math.min(8, Math.max(2.5, height * .15)) : 0
  const showAllCodes = zoom >= 1.45
  const showLabel = feature.type !== 'booth' || Boolean(exhibitor) || showAllCodes || width > 58
  const label = feature.boothCode || feature.label || ''
  const fontSize = Math.max(6, Math.min(isService ? 11 : 10, width / Math.max(label.length * .62, 2), height * .38))
  const accessibleName = exhibitor ? `Estande ${feature.boothCode} — ${exhibitor.name}${selected ? ' — selecionado' : ''}` : `${feature.label || feature.boothCode || feature.type}${selected ? ' — selecionado' : ''}`

  return <g
    role={feature.interactive ? 'button' : undefined}
    aria-label={accessibleName}
    aria-pressed={feature.interactive ? selected : undefined}
    tabIndex={feature.interactive ? 0 : undefined}
    className={feature.interactive ? 'cursor-pointer outline-none map-feature-focus' : undefined}
    onClick={feature.interactive ? event => { event.stopPropagation(); onSelect() } : undefined}
    onKeyDown={feature.interactive ? event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onSelect() } } : undefined}
    data-feature-id={feature.id}
  >
    <title>{accessibleName}</title>
    {depth > 0 && <g aria-hidden="true" className="pointer-events-none">
      <path d={`M ${x} ${y + height} L ${x + width} ${y + height} L ${x + width + depth * .55} ${y + height + depth} L ${x + depth * .55} ${y + height + depth} Z`} fill={darker(fill)} opacity=".72" />
      <path d={`M ${x + width} ${y} L ${x + width} ${y + height} L ${x + width + depth * .55} ${y + height + depth} L ${x + width + depth * .55} ${y + depth} Z`} fill={darker(fill)} opacity=".55" />
    </g>}
    <rect
      x={x} y={y} width={width} height={height} rx={Math.min(3, height * .12)}
      fill={fill} stroke={stroke} strokeWidth={selected ? 3 : exhibitor ? 1.8 : 1.1}
      data-map-face="top" data-highlighted={exhibitor ? 'true' : 'false'} data-space-code={feature.boothCode || feature.label || ''}
      vectorEffect="non-scaling-stroke"
    />
    {showLabel && label && <text x={x + width / 2} y={y + height / 2} textAnchor="middle" dominantBaseline="middle" fill={exhibitor || selected ? '#fff' : dark ? '#f8fafc' : '#334155'} fontSize={fontSize} fontWeight="800" className="pointer-events-none select-none">{label}</text>}
    {exhibitor && (featured || favorite || visited || inRoute) && zoom >= 1.1 && <g transform={`translate(${x + width - 9},${y + 2})`} aria-hidden="true">
      <circle cx="5" cy="5" r="5" fill="#fff" stroke={stroke} strokeWidth="1" />
      {featured ? <Sparkles x="2" y="2" width="6" height="6" color="#be185d" /> : favorite ? <Heart x="2" y="2" width="6" height="6" color="#e11d48" fill="#e11d48" /> : visited ? <CheckCircle2 x="2" y="2" width="6" height="6" color="#059669" /> : <Bookmark x="2" y="2" width="6" height="6" color="#d97706" />}
    </g>}
  </g>
})

MapBooth.displayName = 'MapBooth'
