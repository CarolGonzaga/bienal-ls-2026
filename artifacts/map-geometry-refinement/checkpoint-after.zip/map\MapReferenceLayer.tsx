import React, { useEffect, useState } from 'react'
import {
  REFERENCE_HEIGHT,
  REFERENCE_OFFSET_X,
  REFERENCE_OFFSET_Y,
  REFERENCE_SCALE,
  REFERENCE_WIDTH
} from '../../data/map/map-reference-calibration.ts'

export type ReferenceComparisonMode = 'normal' | 'contour' | 'difference'

interface Props {
  enabled: boolean
  opacity: number
  mode: ReferenceComparisonMode
  asset: string
}

export const MapReferenceLayer: React.FC<Props> = ({ enabled, opacity, mode, asset }) => {
  const [loadedAsset, setLoadedAsset] = useState<string | null>(null)

  useEffect(() => {
    if (!enabled || loadedAsset) return
    const image = new Image()
    image.decoding = 'async'
    image.onload = () => setLoadedAsset(asset)
    image.src = asset
    return () => { image.onload = null }
  }, [asset, enabled, loadedAsset])

  if (!enabled || opacity <= 0 || !loadedAsset) return null

  const filter = mode === 'contour' ? 'url(#reference-contour)' : undefined
  const style = mode === 'difference' ? { mixBlendMode: 'difference' as const } : undefined
  return <g id="reference-layer" opacity={opacity} pointerEvents="none" style={style}>
    <image
      href={loadedAsset}
      x={REFERENCE_OFFSET_X}
      y={REFERENCE_OFFSET_Y}
      width={REFERENCE_WIDTH * REFERENCE_SCALE}
      height={REFERENCE_HEIGHT * REFERENCE_SCALE}
      preserveAspectRatio="xMinYMin meet"
      filter={filter}
    />
  </g>
}
