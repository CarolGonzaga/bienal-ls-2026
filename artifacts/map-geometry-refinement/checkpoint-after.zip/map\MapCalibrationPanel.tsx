import React from 'react'
import type { MapFeature, RectGeometry } from '../../data/map/map-layout.ts'
import type { Point2D } from '../../types/index.ts'
import type { ReferenceComparisonMode } from './MapReferenceLayer.tsx'

interface Props {
  selected?: MapFeature
  referenceOpacity: number
  referenceMode: ReferenceComparisonMode
  autoBlink: boolean
  cleanComparison: boolean
  showGrid: boolean
  snap: boolean
  cursor: { map: Point2D; reference: Point2D } | null
  onOpacity: (value: number) => void
  onReferenceMode: (value: ReferenceComparisonMode) => void
  onAutoBlink: (value: boolean) => void
  onCleanComparison: (value: boolean) => void
  onGrid: (value: boolean) => void
  onSnap: (value: boolean) => void
  onBlink: () => void
  onUpdate: (patch: Partial<RectGeometry> & { id?: string; label?: string; featureType?: MapFeature['type']; entranceX?: number; entranceY?: number }) => void
  onPoints: (points: Array<{ x: number; y: number }>) => void
  onDuplicate: () => void
  onUndo: () => void
  onRedo: () => void
  onCopy: () => void
  onExport: () => void
}

export const MapCalibrationPanel: React.FC<Props> = props => {
  const rect = props.selected?.geometry.type === 'rect' ? props.selected.geometry : null
  const numeric = (label: string, key: keyof RectGeometry, value: number) => <label className="grid grid-cols-[72px_1fr] items-center gap-2 text-xs"><span>{label}</span><input type="number" value={Math.round(value * 10) / 10} onChange={event => props.onUpdate({ [key]: Number(event.target.value) })} className="rounded border border-slate-300 px-2 py-1 text-slate-900" /></label>
  return <aside className="absolute left-3 top-3 z-40 w-72 max-h-[calc(100%-24px)] overflow-auto rounded-2xl border border-slate-300 bg-white/95 p-4 text-slate-800 shadow-2xl backdrop-blur" aria-label="Painel de calibração do mapa">
    <h2 className="text-sm font-black">Calibração 1376 × 1118</h2>
    <p className="mt-1 text-[11px] text-slate-500">Mapa: {props.cursor ? `${props.cursor.map.x.toFixed(1)}, ${props.cursor.map.y.toFixed(1)}` : '—'}</p>
    <p className="text-[11px] text-slate-500">Referência: {props.cursor ? `${props.cursor.reference.x.toFixed(0)}, ${props.cursor.reference.y.toFixed(0)}` : '—'}</p>
    <div className="mt-3 grid gap-2">
      <label className="text-xs font-bold">Referência: {Math.round(props.referenceOpacity * 100)}%<input aria-label="Opacidade da referência" className="block w-full" type="range" min="0" max="1" step=".1" value={props.referenceOpacity} onChange={event => props.onOpacity(Number(event.target.value))}/></label>
      <label className="grid grid-cols-[80px_1fr] items-center gap-2 text-xs"><span>Comparação</span><select value={props.referenceMode} onChange={event => props.onReferenceMode(event.target.value as ReferenceComparisonMode)} className="rounded border border-slate-300 px-2 py-1"><option value="normal">Normal</option><option value="contour">Contorno</option><option value="difference">Diferenças</option></select></label>
      <div className="flex gap-2"><button onClick={() => props.onAutoBlink(!props.autoBlink)} className="calibration-button">Piscar auto {props.autoBlink ? 'on' : 'off'}</button><button onClick={() => props.onCleanComparison(!props.cleanComparison)} className="calibration-button">Só contornos {props.cleanComparison ? 'on' : 'off'}</button></div>
      <div className="flex gap-2"><button onClick={props.onBlink} className="calibration-button">Piscar referência</button><button onClick={() => props.onGrid(!props.showGrid)} className="calibration-button">Grid {props.showGrid ? 'on' : 'off'}</button><button onClick={() => props.onSnap(!props.snap)} className="calibration-button">Snap {props.snap ? 'on' : 'off'}</button></div>
    </div>
    <hr className="my-3" />
    {!props.selected ? <p className="text-xs text-slate-500">Clique em um elemento para editar.</p> : <div className="grid gap-2">
      <label className="grid gap-1 text-xs"><span>ID</span><input value={props.selected.id} onChange={event => props.onUpdate({ id: event.target.value })} className="rounded border border-slate-300 px-2 py-1"/></label>
      <label className="grid gap-1 text-xs"><span>Rótulo/código</span><input value={props.selected.label || ''} onChange={event => props.onUpdate({ label: event.target.value })} className="rounded border border-slate-300 px-2 py-1"/></label>
      <label className="grid gap-1 text-xs"><span>Tipo</span><select value={props.selected.type} onChange={event => props.onUpdate({ featureType: event.target.value as MapFeature['type'] })} className="rounded border border-slate-300 px-2 py-1">{['booth','street','gate','entrance','exit','bathroom','food','stage','service','special-area','external-area','wall','obstacle','information'].map(type => <option key={type}>{type}</option>)}</select></label>
      {props.selected.needsReview && <p className="text-xs font-bold text-amber-700">Precisa de validação na referência.</p>}
      {rect && <>{numeric('X', 'x', rect.x)}{numeric('Y', 'y', rect.y)}{numeric('Largura', 'width', rect.width)}{numeric('Altura', 'height', rect.height)}</>}
      {props.selected.entrances?.[0] && <>
        <label className="grid grid-cols-[72px_1fr] items-center gap-2 text-xs"><span>Entrada X</span><input type="number" value={Math.round(props.selected.entrances[0].x * 10) / 10} onChange={event => props.onUpdate({ entranceX: Number(event.target.value) })} className="rounded border border-slate-300 px-2 py-1 text-slate-900"/></label>
        <label className="grid grid-cols-[72px_1fr] items-center gap-2 text-xs"><span>Entrada Y</span><input type="number" value={Math.round(props.selected.entrances[0].y * 10) / 10} onChange={event => props.onUpdate({ entranceY: Number(event.target.value) })} className="rounded border border-slate-300 px-2 py-1 text-slate-900"/></label>
      </>}
      {props.selected.geometry.type === 'polygon' && <label className="grid gap-1 text-xs"><span>Pontos do polígono (JSON)</span><textarea defaultValue={JSON.stringify(props.selected.geometry.points)} onBlur={event => { try { props.onPoints(JSON.parse(event.target.value)) } catch { /* mantém os pontos anteriores */ } }} className="min-h-24 rounded border border-slate-300 p-2 font-mono text-[10px]"/></label>}
      <p className="text-[10px] text-slate-500">Setas movem 0,5; Shift + seta move 5; Alt + seta redimensiona.</p>
      <div className="flex flex-wrap gap-2"><button onClick={props.onDuplicate} className="calibration-button">Duplicar</button><button onClick={props.onCopy} className="calibration-button">Copiar</button><button onClick={props.onUndo} className="calibration-button">Desfazer</button><button onClick={props.onRedo} className="calibration-button">Refazer</button></div>
    </div>}
    <button onClick={props.onExport} className="mt-4 w-full rounded-lg bg-indigo-600 px-3 py-2 text-xs font-black text-white">Exportar layout JSON</button>
  </aside>
}
