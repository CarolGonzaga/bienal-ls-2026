import test from 'node:test'
import assert from 'node:assert/strict'
import { MAP_HEIGHT, MAP_WIDTH, OFFICIAL_LAYOUT_FEATURES, buildMapLayout } from '../../data/map/map-layout.ts'
import { validateLayout } from '../../services/mapLayoutValidationService.ts'
import {
  REFERENCE_HEIGHT,
  REFERENCE_OFFSET_Y,
  REFERENCE_SCALE,
  REFERENCE_WIDTH,
  mapToReference,
  referenceToMap
} from '../../data/map/map-reference-calibration.ts'

test('layout usa o viewBox obrigatório', () => {
  assert.equal(MAP_WIDTH, 1376)
  assert.equal(MAP_HEIGHT, 1118)
})

test('referência usa escala uniforme, sem deformação', () => {
  const origin = referenceToMap({ x: 0, y: 0 })
  const opposite = referenceToMap({ x: REFERENCE_WIDTH, y: REFERENCE_HEIGHT })
  assert.equal(origin.x, 0)
  assert.equal(origin.y, REFERENCE_OFFSET_Y)
  assert.equal(opposite.x, MAP_WIDTH)
  assert.ok(opposite.y < MAP_HEIGHT)
  assert.ok(Math.abs((opposite.x - origin.x) / REFERENCE_WIDTH - REFERENCE_SCALE) < 1e-12)
  assert.ok(Math.abs((opposite.y - origin.y) / REFERENCE_HEIGHT - REFERENCE_SCALE) < 1e-12)
})

test('conversão referência/mapa é reversível', () => {
  const source = { x: 5370, y: 4435 }
  const restored = mapToReference(referenceToMap(source))
  assert.ok(Math.abs(restored.x - source.x) < 1e-9)
  assert.ok(Math.abs(restored.y - source.y) < 1e-9)
})

test('layout oficial não possui IDs duplicados, dimensões inválidas ou coordenadas externas', () => {
  const errors = validateLayout(buildMapLayout([]))
  assert.deepEqual(errors, [])
})

test('não existem espaços oficiais sem identificação', () => {
  assert.equal(OFFICIAL_LAYOUT_FEATURES.filter(feature => !feature.label && !feature.boothCode).length, 0)
})
