import type { Point2D, StandGeometry } from '../../types/index.ts'
import { OFFICIAL_MAP_SPACES } from '../officialMapSpaces.ts'
import {
  MAP_VIEWBOX_HEIGHT,
  MAP_VIEWBOX_WIDTH,
  REFERENCE_HEIGHT,
  REFERENCE_WIDTH,
  referenceBoundsToMap,
  referenceLengthToMap,
  referencePolygonToMap,
  referenceToMap
} from './map-reference-calibration.ts'

export const MAP_WIDTH = MAP_VIEWBOX_WIDTH
export const MAP_HEIGHT = MAP_VIEWBOX_HEIGHT
export const MAP_REFERENCE_ASSET = '/mapa/mapa-bienal-v4.webp'
export const MAP_GRID_SIZE = 37

export type MapFeatureType = 'booth' | 'street' | 'gate' | 'entrance' | 'exit' | 'bathroom' | 'food' | 'stage' | 'service' | 'special-area' | 'external-area' | 'wall' | 'obstacle' | 'information'
export type RectGeometry = { type: 'rect'; x: number; y: number; width: number; height: number; rotation?: number }
export type PolygonGeometry = { type: 'polygon'; points: Point2D[] }
export type MapGeometry = RectGeometry | PolygonGeometry

export interface MapFeature {
  id: string
  type: MapFeatureType
  label?: string
  geometry: MapGeometry
  boothCode?: string
  exhibitorId?: string
  category?: string
  interactive?: boolean
  walkable?: boolean
  entrances?: Point2D[]
  zIndex?: number
  needsReview?: boolean
  metadata?: Record<string, unknown>
}

export interface MapStreet {
  id: string
  name: string
  centerline: Point2D[]
  width: number
  labelPosition: Point2D
  segments: Array<[Point2D, Point2D]>
}

const streetSourceY: Record<string, number> = {
  K: 1915, J: 2217, H: 2490, G: 2780, F: 3055,
  E: 3345, D: 3614, C: 3956, B: 4253, A: 4515
}

const streetSourceWidth: Record<string, number> = {
  K: 112, J: 96, H: 122, G: 126, F: 103,
  E: 142, D: 88, C: 136, B: 126, A: 104
}

const streetSegments = (letter: string, y: number): Array<[Point2D, Point2D]> => {
  const sourceSegments: Array<[Point2D, Point2D]> = [[{ x: 900, y }, { x: 5350, y }]]
  if (['D', 'C', 'B', 'A'].includes(letter)) sourceSegments.push([{ x: 6570, y }, { x: 7900, y }])
  return sourceSegments.map(([start, end]) => [referenceToMap(start), referenceToMap(end)])
}

export const MAP_STREETS: MapStreet[] = Object.entries(streetSourceY).map(([letter, y]) => ({
  id: `street-${letter.toLowerCase()}`,
  name: `Rua ${letter}`,
  centerline: [referenceToMap({ x: 900, y }), referenceToMap({ x: 5350, y })],
  width: referenceLengthToMap(streetSourceWidth[letter]),
  labelPosition: referenceToMap({ x: 5070, y }),
  segments: streetSegments(letter, y)
}))

export const MAP_BUILDINGS: MapFeature[] = [
  {
    id: 'pavilion-main', type: 'wall', label: 'Pavilhão principal', zIndex: 1,
    geometry: { type: 'polygon', points: referencePolygonToMap([
      { x: 185, y: 1450 }, { x: 5355, y: 1450 }, { x: 5355, y: 4690 },
      { x: 5150, y: 4690 }, { x: 5000, y: 4860 }, { x: 185, y: 4860 }
    ]) },
    needsReview: false,
    metadata: { calibrationZone: 'principal', source: 'mapa-bienal-v4.webp' }
  },
  {
    id: 'pavilion-east', type: 'wall', label: 'Pavilhão leste', zIndex: 1,
    geometry: { type: 'polygon', points: referencePolygonToMap([
      { x: 6425, y: 3390 }, { x: 7955, y: 3390 }, { x: 7955, y: 5120 },
      { x: 6680, y: 5120 }, { x: 6680, y: 4970 }, { x: 6425, y: 4970 }
    ]) },
    needsReview: true
  },
  {
    id: 'pavilion-connector', type: 'external-area', zIndex: 2, walkable: true,
    geometry: { type: 'polygon', points: referencePolygonToMap([
      { x: 5350, y: 3990 }, { x: 6425, y: 3990 }, { x: 6425, y: 4205 },
      { x: 5350, y: 4205 }
    ]) },
    needsReview: true
  },
  {
    id: 'external-north', type: 'external-area', zIndex: 0,
    geometry: { type: 'polygon', points: referencePolygonToMap([
      { x: 250, y: 1110 }, { x: 420, y: 920 }, { x: 760, y: 820 }, { x: 1720, y: 900 },
      { x: 3220, y: 1000 }, { x: 5290, y: 1010 }, { x: 5250, y: 1195 },
      { x: 4550, y: 1150 }, { x: 4190, y: 1120 }, { x: 4060, y: 1260 },
      { x: 3450, y: 1230 }, { x: 3340, y: 1050 }, { x: 330, y: 1030 }
    ]) },
    needsReview: false,
    metadata: { calibrationZone: 'externa-norte', source: 'mapa-bienal-v4.webp' }
  },
  {
    id: 'external-south', type: 'external-area', zIndex: 0,
    geometry: { type: 'polygon', points: referencePolygonToMap([
      { x: 170, y: 4860 }, { x: 4970, y: 4860 }, { x: 5120, y: 5000 }, { x: 5350, y: 5000 },
      { x: 5350, y: 5480 }, { x: 4550, y: 5480 }, { x: 4300, y: 5350 }, { x: 170, y: 5350 }
    ]) },
    needsReview: true
  }
]

const serviceTypeMap: Record<string, MapFeatureType> = {
  restroom: 'bathroom', gate: 'gate', medical: 'service', food: 'food', info: 'information', accessibility: 'service', stage: 'stage'
}

const NEEDS_REVIEW_CODES = new Set(['+', 'AUTÓGRAFOS 1', 'AUTÓGRAFOS 2', 'FOOD LESTE', 'FOOD CENTRAL', 'PROFESSORES'])

export const OFFICIAL_LAYOUT_FEATURES: MapFeature[] = OFFICIAL_MAP_SPACES.map(item => {
  const [x1, y1, x2, y2] = item.bounds
  const type = item.serviceType ? serviceTypeMap[item.serviceType] : 'booth'
  const mapped = referenceBoundsToMap(item.bounds)
  const feature: MapFeature = {
    id: `official-${type}-${item.code || 'unlabeled'}-${x1}-${y1}`,
    type,
    label: item.displayName || item.code || undefined,
    boothCode: type === 'booth' ? item.code : undefined,
    interactive: type === 'booth' || Boolean(item.serviceType),
    walkable: false,
    geometry: { type: 'rect', ...mapped },
    zIndex: type === 'booth' ? 7 : 10,
    needsReview: !item.code || NEEDS_REVIEW_CODES.has(item.code),
    metadata: { serviceType: item.serviceType, routeOrigin: item.routeOrigin, navigable: type !== 'booth', sourceBounds: item.bounds }
  }
  return feature
})

export const boothAccessPoint = (feature: MapFeature): Point2D | null => {
  if (feature.geometry.type !== 'rect' || !feature.boothCode) return null
  const street = MAP_STREETS.find(item => item.name.endsWith(feature.boothCode!.charAt(0)))
  if (!street) return null
  const rect = feature.geometry
  const streetY = street.centerline[0].y
  const centerY = rect.y + rect.height / 2
  return { x: rect.x + rect.width / 2, y: streetY > centerY ? rect.y + rect.height : rect.y }
}

export const databaseGeometriesToFeatures = (geometries: StandGeometry[]): MapFeature[] => geometries
  .filter(item => !item.neutral && item.verified && item.polygon.length >= 3)
  .map(item => {
    const points = item.polygon.map(point => referenceToMap({ x: point.x * REFERENCE_WIDTH, y: point.y * REFERENCE_HEIGHT }))
    const xs = points.map(point => point.x)
    const ys = points.map(point => point.y)
    const geometry: RectGeometry = { type: 'rect', x: Math.min(...xs), y: Math.min(...ys), width: Math.max(...xs) - Math.min(...xs), height: Math.max(...ys) - Math.min(...ys) }
    const feature: MapFeature = {
      id: item.id,
      type: 'booth',
      label: item.standCode,
      boothCode: item.standCode,
      exhibitorId: item.exhibitorId,
      interactive: true,
      walkable: false,
      geometry,
      zIndex: 8,
      needsReview: false,
      metadata: { navigable: true }
    }
    const access = boothAccessPoint(feature)
    if (access) feature.entrances = [access]
    return feature
  })

export const buildMapLayout = (databaseGeometries: StandGeometry[]): MapFeature[] => {
  const database = databaseGeometriesToFeatures(databaseGeometries)
  const occupiedCodes = new Set(database.map(item => item.boothCode?.toUpperCase()))
  const official = OFFICIAL_LAYOUT_FEATURES.filter(item => !item.boothCode || !occupiedCodes.has(item.boothCode.toUpperCase()))
  return [...MAP_BUILDINGS, ...official, ...database]
}
