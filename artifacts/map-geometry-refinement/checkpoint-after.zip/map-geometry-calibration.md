# Calibração geométrica do mapa da Bienal

## Referência primária

- Arquivo: `public/mapa/mapa-bienal-v4.webp`
- Dimensão nativa verificada: `7955 × 6436`
- Formato/modo: WebP RGB, sem transparência
- Tamanho verificado: `2.116.140 bytes`
- Área vazia superior: aproximadamente `0 ≤ y < 792`; o conteúdo alcança as bordas laterais e inferior.
- O Vite copia o arquivo para `dist` sem alterar tamanho ou conteúdo (SHA-256 verificado: `9581AEC793D6092994B56D1190F581E317F9F38840811421AD59D8E5A55DDEC8`).

## Sistema de coordenadas

O mapa público mantém o viewBox `1376 × 1118`. A referência tem proporção `1.2360161591`; o viewBox tem `1.2307692308`. Para não deformar a planta, a calibração usa uma única escala:

```text
scale = 1376 / 7955 = 0.172972972973
offsetX = 0
offsetY = (1118 - 6436 × scale) / 2 = 2.372972973

mapX = offsetX + referenceX × scale
mapY = offsetY + referenceY × scale
```

Os conversores e constantes vivem em `src/data/map/map-reference-calibration.ts`. Não se deve criar outra regra de escala em componentes, grafo ou dados.

## Auditoria anterior à alteração

- O layout usava escalas X e Y independentes.
- O debug exibia uma JPEG `1600 × 1294` esticada com `preserveAspectRatio="none"`.
- Os pavilhões eram caixas retangulares aproximadas.
- Todos os corredores tinham quase a mesma largura e acabamento arredondado.
- Linha de base: 11/11 testes do mapa e build de produção aprovados.
- Checkpoint: `artifacts/map-geometry-refinement/checkpoint-before.zip`.

## Zonas calibradas

| Zona | Situação | Observação |
| --- | --- | --- |
| Transformação global | concluída | Escala uniforme e reversível; referência e vetor compartilham a mesma câmera. |
| Pavilhão principal | calibrada | Contorno passou a polígono em coordenadas da referência, incluindo recuo sudeste. |
| Área externa norte | calibrada | Topo inclinado, vegetação longitudinal e recortes principais representados. |
| Área externa sul | parcial | Contorno poligonal e transição para a Praça Claro; detalhes de estacionamento continuam `needsReview`. |
| Pavilhão leste | parcial | Contorno e recuos principais alinhados; detalhes técnicos internos continuam `needsReview`. |
| Conector principal/leste | parcial | Corredor de ligação alinhado; divisórias técnicas finas continuam `needsReview`. |
| Ruas A–K | calibrada | Centros preservados, larguras específicas por rua, segmentos leste separados e pontas retas. |
| Estandes e 29 destaques | calibrada globalmente | Todos usam os bounds nativos e a mesma transformação uniforme. |
| Portões 5, 7, 8, 9 e 10 | calibrada globalmente | Coordenadas oficiais preservadas; continuam nós de origem do grafo. |
| P.B–P.F e saídas | calibrada globalmente | Bounds nativos preservados; rótulos e tipos não foram alterados. |
| Banheiros, alimentação e serviços | calibrada globalmente | Bounds nativos preservados. |
| Praça Claro, autógrafos e setor de professores | parcial | Bounds oficiais preservados; detalhes internos e contornos finos seguem marcados para revisão. |

## Ferramenta de comparação

Abra `?mapDebug=true`. A referência de alta resolução só é carregada nesse modo. O painel permite opacidade, piscar, grid, snap e comparação normal, em contorno ou por diferença. O cursor mostra coordenadas do mapa e da imagem oficial. Setas movem `0,5`, `Shift + seta` move `5` e `Alt + seta` redimensiona.

## Evidências

- Antes público: `artifacts/map-geometry-refinement/before-public.png`
- Antes debug: `artifacts/map-geometry-refinement/before-debug-overlay.png`
- Depois público: `artifacts/map-geometry-refinement/after-public.png`
- Depois com overlay: `artifacts/map-geometry-refinement/after-debug-overlay.png`

Elementos marcados com `needsReview` não devem ser tratados como conferidos em escala de pixel até uma validação manual ampliada na referência.
