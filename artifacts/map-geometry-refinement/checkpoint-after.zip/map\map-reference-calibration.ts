import type { Point2D } from '../../types/index.ts'

export const REFERENCE_WIDTH = 7955
export const REFERENCE_HEIGHT = 6436
export const MAP_VIEWBOX_WIDTH = 1376
export const MAP_VIEWBOX_HEIGHT = 1118

/**
 * The official plan is fitted without distortion. The viewBox is slightly
 * taller than the reference aspect ratio, so the remaining 4.746 units are
 * split equally above and below the raster/vector content.
 */
export const REFERENCE_SCALE = Math.min(
  MAP_VIEWBOX_WIDTH / REFERENCE_WIDTH,
  MAP_VIEWBOX_HEIGHT / REFERENCE_HEIGHT
)
export const REFERENCE_OFFSET_X = (MAP_VIEWBOX_WIDTH - REFERENCE_WIDTH * REFERENCE_SCALE) / 2
export const REFERENCE_OFFSET_Y = (MAP_VIEWBOX_HEIGHT - REFERENCE_HEIGHT * REFERENCE_SCALE) / 2

export const referenceToMap = (point: Point2D): Point2D => ({
  x: REFERENCE_OFFSET_X + point.x * REFERENCE_SCALE,
  y: REFERENCE_OFFSET_Y + point.y * REFERENCE_SCALE
})

export const mapToReference = (point: Point2D): Point2D => ({
  x: (point.x - REFERENCE_OFFSET_X) / REFERENCE_SCALE,
  y: (point.y - REFERENCE_OFFSET_Y) / REFERENCE_SCALE
})

export const referenceLengthToMap = (value: number) => value * REFERENCE_SCALE

export const referenceBoundsToMap = ([x1, y1, x2, y2]: [number, number, number, number]) => {
  const topLeft = referenceToMap({ x: x1, y: y1 })
  return {
    x: topLeft.x,
    y: topLeft.y,
    width: referenceLengthToMap(x2 - x1),
    height: referenceLengthToMap(y2 - y1)
  }
}

export const referencePolygonToMap = (points: Point2D[]) => points.map(referenceToMap)

export const screenToMap = (
  clientPoint: Point2D,
  screenMatrix: DOMMatrix
): Point2D => {
  const inverse = screenMatrix.inverse()
  return {
    x: inverse.a * clientPoint.x + inverse.c * clientPoint.y + inverse.e,
    y: inverse.b * clientPoint.x + inverse.d * clientPoint.y + inverse.f
  }
}

