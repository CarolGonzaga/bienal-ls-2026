# Mapa indoor da Bienal

## Arquitetura

- `src/data/map/map-layout.ts`: dimensões `1376 × 1118`, edifícios, ruas e conversão dos espaços oficiais e dos 29 expositores.
- `src/data/map/map-routing-graph.ts`: nós de portões, cruzamentos, ruas e acessos nas bordas dos estandes.
- `src/services/mapRoutingService.ts`: Dijkstra, leitura de URL e instruções de direção.
- `src/services/mapLayoutValidationService.ts`: validações de layout, grafo e colisões.
- `src/components/map/BienalMap.tsx`: câmera e composição das camadas SVG.
- `src/components/map/MapBooth.tsx`: estandes e serviços, incluindo o 2.5D decorativo.
- `src/components/map/MapRoute.tsx`: rota, origem e destino.
- `src/components/map/MapCalibrationPanel.tsx`: edição de calibração.

## Modo de calibração

Abra:

```text
http://localhost:5173/?mapDebug=true
```

O painel permite controlar a opacidade da referência, piscar a sobreposição, mostrar o grid de 37 unidades, selecionar elementos, editar retângulos e polígonos, editar o ponto de entrada, mover com as setas, mover 10 unidades com Shift + seta, duplicar, desfazer/refazer, copiar e exportar JSON.

A imagem oficial só é adicionada ao DOM nesse modo. Ela não é carregada no mapa público.

## Coordenadas

Todas as geometrias públicas usam o mesmo espaço:

```text
0 ≤ x ≤ 1376
0 ≤ y ≤ 1118
```

O arquivo oficial de referência possui `7955 × 6436`. Ele é exibido apenas no modo de calibração e encaixado no viewBox `1376 × 1118` com escala uniforme e pequeno letterbox vertical, sem deformação. A transformação canônica está documentada em `docs/map-geometry-calibration.md`.

## Adicionar um expositor

1. Cadastre o expositor em `src/data/initialExhibitors.ts`.
2. Adicione ou confirme sua geometria em `src/data/initialStands.ts`.
3. Use coordenadas normalizadas apenas nesse adaptador legado; `databaseGeometriesToFeatures` converte para `1376 × 1118`.
4. Informe um código de estande válido, como `H70`, para ligá-lo à rua correspondente.
5. Execute `npm run test:map` e `npm run build`.

## Adicionar um ponto de rota

1. Adicione o nó em `map-routing-graph.ts` usando coordenadas do viewBox.
2. Conecte-o apenas a um corredor caminhável confirmado.
3. Marque acessibilidade e bloqueio nas arestas.
4. Execute o teste de colisão; nenhuma aresta pode atravessar estandes ou áreas fechadas.

## URLs de rota

Exemplo:

```text
/?origin=P8&destination=H70
```

Origens aceitas incluem portões, nós centrais das ruas e acessos de estandes.

## Elementos pendentes

Itens com `needsReview: true` aparecem no inspetor de calibração. Permanecem pendentes de validação fina:

- contornos externos e ligação entre pavilhões;
- posição exata do posto médico;
- limites de Autógrafos 1 e 2;
- limites das áreas de alimentação lateral;
- acesso de profissionais/professores;
- pequenos espaços ilegíveis do pavilhão direito, que não foram inventados nem exibidos.

O bloco anteriormente identificado como `IF01` foi removido: sua geometria sobrepunha estandes confirmados e fazia rotas atravessarem área fechada. Ele deve voltar somente após identificação segura na referência.
