import React, { useEffect, useMemo, useRef, useState } from 'react'
import { MapPin, Sparkles } from 'lucide-react'
import { useAdminMapStore } from '../../stores/useAdminMapStore'
import { useExhibitorStore } from '../../stores/useExhibitorStore'
import { useMapStore } from '../../stores/useMapStore'
import { useUserStore } from '../../stores/useUserStore'
import { useMapInteraction } from '../../hooks/useMapInteraction'
import { MAP_HEIGHT, MAP_REFERENCE_ASSET, MAP_STREETS, MAP_WIDTH, buildMapLayout, type MapFeature, type RectGeometry } from '../../data/map/map-layout.ts'
import { buildRoutingGraph } from '../../data/map/map-routing-graph.ts'
import { findRoute, parseMapRouteParams, type CalculatedRoute } from '../../services/mapRoutingService.ts'
import { MapBooth } from './MapBooth.tsx'
import { MapRoute } from './MapRoute.tsx'
import { MapCalibrationPanel } from './MapCalibrationPanel.tsx'
import { MapReferenceLayer, type ReferenceComparisonMode } from './MapReferenceLayer.tsx'
import { mapToReference } from '../../data/map/map-reference-calibration.ts'

const pointsString = (points: Array<{ x: number; y: number }>) => points.map(point => `${point.x},${point.y}`).join(' ')

export const BienalMap: React.FC = () => {
  const databaseGeometries = useAdminMapStore(state => state.geometries)
  const exhibitors = useExhibitorStore(state => state.exhibitors)
  const searchQuery = useExhibitorStore(state => state.searchQuery)
  const setSelectedExhibitorId = useExhibitorStore(state => state.setSelectedExhibitorId)
  const selectedExhibitorId = useExhibitorStore(state => state.selectedExhibitorId)
  const selectedStandId = useMapStore(state => state.selectedStandId)
  const setSelectedStandId = useMapStore(state => state.setSelectedStandId)
  const cameraMode = useMapStore(state => state.cameraMode)
  const mapTheme = useMapStore(state => state.mapTheme)
  const userPosition = useMapStore(state => state.userPosition)
  const routeOriginGateId = useMapStore(state => state.routeOriginGateId)
  const setRouteOriginGateId = useMapStore(state => state.setRouteOriginGateId)
  const isChoosingRouteOrigin = useMapStore(state => state.isChoosingRouteOrigin)
  const setIsChoosingRouteOrigin = useMapStore(state => state.setIsChoosingRouteOrigin)
  const favorites = useUserStore(state => state.favorites)
  const visits = useUserStore(state => state.visits)
  const routeStops = useUserStore(state => state.routeStops)
  const addToRoute = useUserStore(state => state.addToRoute)
  const isometric = cameraMode === '2.5D'
  const debug = useMemo(() => new URLSearchParams(window.location.search).get('mapDebug') === 'true', [])
  const baseFeatures = useMemo(() => buildMapLayout(databaseGeometries), [databaseGeometries])
  const [features, setFeatures] = useState<MapFeature[]>(baseFeatures)
  const [debugSelectedId, setDebugSelectedId] = useState<string | null>(null)
  const [referenceOpacity, setReferenceOpacity] = useState(debug ? .4 : 0)
  const [referenceMode, setReferenceMode] = useState<ReferenceComparisonMode>('normal')
  const [autoBlink, setAutoBlink] = useState(false)
  const [cleanComparison, setCleanComparison] = useState(false)
  const [showGrid, setShowGrid] = useState(debug)
  const [snap, setSnap] = useState(true)
  const [cursor, setCursor] = useState<{ x: number; y: number } | null>(null)
  const history = useRef<MapFeature[][]>([])
  const future = useRef<MapFeature[][]>([])
  const svgRef = useRef<SVGSVGElement>(null)
  const { transform, containerRef, handlers, animateToStand, resetView, setTilt, zoomIn, zoomOut } = useMapInteraction({ initialTilt: 0, minZoom: .65, maxZoom: 5 })

  useEffect(() => { if (!debug) setFeatures(baseFeatures) }, [baseFeatures, debug])

  useEffect(() => {
    ;(window as any).__mapControls = { resetView, setTilt, animateToStand, zoomIn, zoomOut }
    return () => { delete (window as any).__mapControls }
  }, [resetView, setTilt, animateToStand, zoomIn, zoomOut])

  const graph = useMemo(() => buildRoutingGraph(features), [features])
  const route = useMemo<CalculatedRoute | null>(() => {
    let current = routeOriginGateId
    const combined: CalculatedRoute = { nodeIds: [], points: [], distance: 0, instructions: [] }
    for (const stop of [...routeStops].sort((a, b) => a.order - b.order)) {
      const destination = features.find(feature => feature.exhibitorId === stop.exhibitorId)
      if (!destination) continue
      const next = findRoute(graph, current, `access-${destination.id}`)
      if (!next) continue
      combined.nodeIds.push(...next.nodeIds.slice(combined.nodeIds.length ? 1 : 0))
      combined.points.push(...next.points.slice(combined.points.length ? 1 : 0))
      combined.distance += next.distance
      combined.instructions.push(...next.instructions)
      current = `access-${destination.id}`
    }
    return combined.points.length > 1 ? combined : null
  }, [features, graph, routeOriginGateId, routeStops])

  useEffect(() => {
    const controls = (window as any).__mapControls
    if (!controls) return
    controls.focusRoute = () => {
      if (!route?.points.length) return
      const center = route.points.reduce((sum, point) => ({ x: sum.x + point.x / route.points.length, y: sum.y + point.y / route.points.length }), { x: 0, y: 0 })
      animateToStand(center.x / MAP_WIDTH, center.y / MAP_HEIGHT)
    }
    controls.focusOrigin = () => {
      const point = route?.points[0]; if (point) animateToStand(point.x / MAP_WIDTH, point.y / MAP_HEIGHT)
    }
    controls.focusDestination = () => {
      const point = route?.points.at(-1); if (point) animateToStand(point.x / MAP_WIDTH, point.y / MAP_HEIGHT)
    }
  }, [animateToStand, route])

  useEffect(() => {
    const { origin, destination: destinationCode } = parseMapRouteParams(window.location.search)
    if (origin && graph.nodes.some(node => node.id === origin)) setRouteOriginGateId(origin)
    if (!destinationCode) return
    const feature = features.find(item => item.boothCode?.toUpperCase() === destinationCode && item.exhibitorId)
    if (!feature?.exhibitorId || !feature.boothCode) return
    setSelectedStandId(feature.id)
    setSelectedExhibitorId(feature.exhibitorId)
    addToRoute(feature.exhibitorId, feature.boothCode)
  }, [addToRoute, features, graph.nodes, setRouteOriginGateId, setSelectedExhibitorId, setSelectedStandId])

  useEffect(() => {
    const query = searchQuery.trim().toUpperCase()
    if (!query) return
    const feature = features.find(item => item.boothCode?.toUpperCase() === query && item.exhibitorId)
    if (!feature?.exhibitorId || feature.geometry.type !== 'rect') return
    setSelectedStandId(feature.id)
    setSelectedExhibitorId(feature.exhibitorId)
    animateToStand((feature.geometry.x + feature.geometry.width / 2) / MAP_WIDTH, (feature.geometry.y + feature.geometry.height / 2) / MAP_HEIGHT)
  }, [animateToStand, features, searchQuery, setSelectedExhibitorId, setSelectedStandId])

  const selectFeature = (feature: MapFeature) => {
    if (debug) { setDebugSelectedId(feature.id); return }
    setSelectedStandId(feature.id)
    if (feature.exhibitorId) setSelectedExhibitorId(feature.exhibitorId)
    if (feature.type === 'gate' && feature.metadata?.routeOrigin) setRouteOriginGateId(feature.label?.replace('Portão ', 'P') || routeOriginGateId)
    if (feature.geometry.type === 'rect') animateToStand((feature.geometry.x + feature.geometry.width / 2) / MAP_WIDTH, (feature.geometry.y + feature.geometry.height / 2) / MAP_HEIGHT)
  }

  const pushHistory = () => { history.current.push(features); future.current = [] }
  const updateSelected = (patch: Partial<RectGeometry> & { id?: string; label?: string; featureType?: MapFeature['type']; entranceX?: number; entranceY?: number }) => {
    if (!debugSelectedId) return
    pushHistory()
    setFeatures(current => current.map(feature => {
      if (feature.id !== debugSelectedId) return feature
      const { id, label, featureType, entranceX, entranceY, ...geometryPatch } = patch
      const nextId = id || feature.id
      const nextGeometry = feature.geometry.type === 'rect' ? { ...feature.geometry, ...geometryPatch, type: 'rect' as const } : feature.geometry
      const entrances = feature.entrances?.length ? [{ x: entranceX ?? feature.entrances[0].x, y: entranceY ?? feature.entrances[0].y }, ...feature.entrances.slice(1)] : feature.entrances
      if (id) setDebugSelectedId(nextId)
      return { ...feature, id: nextId, type: featureType ?? feature.type, label: label ?? feature.label, boothCode: feature.type === 'booth' ? label ?? feature.boothCode : feature.boothCode, geometry: nextGeometry, entrances }
    }))
  }
  const replacePoints = (points: Array<{ x: number; y: number }>) => {
    if (!debugSelectedId || points.length < 3) return
    pushHistory()
    setFeatures(current => current.map(feature => feature.id === debugSelectedId && feature.geometry.type === 'polygon' ? { ...feature, geometry: { type: 'polygon', points } } : feature))
  }
  const undo = () => { const previous = history.current.pop(); if (!previous) return; future.current.push(features); setFeatures(previous) }
  const redo = () => { const next = future.current.pop(); if (!next) return; history.current.push(features); setFeatures(next) }
  const duplicate = () => {
    const selected = features.find(feature => feature.id === debugSelectedId)
    if (!selected || selected.geometry.type !== 'rect') return
    pushHistory()
    const copy = { ...selected, id: `${selected.id}-copy`, label: `${selected.label || selected.id} cópia`, needsReview: true, geometry: { ...selected.geometry, x: selected.geometry.x + 10, y: selected.geometry.y + 10 } }
    setFeatures(current => [...current, copy]); setDebugSelectedId(copy.id)
  }
  const copyCoordinates = async () => {
    const selected = features.find(feature => feature.id === debugSelectedId)
    if (selected) await navigator.clipboard.writeText(JSON.stringify(selected, null, 2))
  }
  const exportLayout = () => {
    const blob = new Blob([JSON.stringify({ width: MAP_WIDTH, height: MAP_HEIGHT, features }, null, 2)], { type: 'application/json' })
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = 'map-layout-1376x1118.json'; link.click(); URL.revokeObjectURL(link.href)
  }
  const blinkReference = () => { const previous = referenceOpacity; setReferenceOpacity(previous ? 0 : .7); window.setTimeout(() => setReferenceOpacity(previous), 220) }

  useEffect(() => {
    if (!debug || !autoBlink) return
    const visibleOpacity = referenceOpacity || .5
    const interval = window.setInterval(() => setReferenceOpacity(value => value > 0 ? 0 : visibleOpacity), 650)
    return () => window.clearInterval(interval)
  }, [autoBlink, debug])

  useEffect(() => {
    if (!debug || !debugSelectedId) return
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') {
        event.preventDefault(); event.shiftKey ? redo() : undo(); return
      }
      if (event.key === 'Escape') { setDebugSelectedId(null); return }
      const movement: Record<string, [number, number]> = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }
      if (!movement[event.key] || ['INPUT', 'TEXTAREA', 'SELECT'].includes((event.target as HTMLElement).tagName)) return
      event.preventDefault()
      const feature = features.find(item => item.id === debugSelectedId)
      if (!feature || feature.geometry.type !== 'rect') return
      const step = event.shiftKey ? 5 : .5
      if (event.altKey) {
        updateSelected({ width: Math.max(.5, feature.geometry.width + movement[event.key][0] * step), height: Math.max(.5, feature.geometry.height + movement[event.key][1] * step) })
      } else {
        updateSelected({ x: feature.geometry.x + movement[event.key][0] * step, y: feature.geometry.y + movement[event.key][1] * step })
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [debug, debugSelectedId, features])

  const handleSvgMove = (event: React.MouseEvent<SVGSVGElement>) => {
    if (!debug || !svgRef.current) return
    const point = svgRef.current.createSVGPoint(); point.x = event.clientX; point.y = event.clientY
    const matrix = svgRef.current.getScreenCTM(); if (!matrix) return
    const transformed = point.matrixTransform(matrix.inverse())
    const unit = snap ? 1 : .1
    setCursor({ x: Math.round(transformed.x / unit) * unit, y: Math.round(transformed.y / unit) * unit })
  }

  const svgPointFromEvent = (event: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return null
    const point = svgRef.current.createSVGPoint(); point.x = event.clientX; point.y = event.clientY
    const matrix = svgRef.current.getScreenCTM(); return matrix ? point.matrixTransform(matrix.inverse()) : null
  }

  const chooseOriginOnMap = (event: React.MouseEvent<SVGSVGElement>) => {
    if (!isChoosingRouteOrigin) return
    const point = svgPointFromEvent(event)
    if (!point) return
    const candidates = graph.nodes.filter(node => node.type === 'intersection' || node.type === 'gate' || node.type === 'booth-access')
    const nearest = candidates.reduce((best, node) => Math.hypot(node.x - point.x, node.y - point.y) < Math.hypot(best.x - point.x, best.y - point.y) ? node : best, candidates[0])
    if (nearest) setRouteOriginGateId(nearest.id)
    setIsChoosingRouteOrigin(false)
  }

  const dark = mapTheme === 'dark'
  const user = userPosition ? { x: (userPosition.worldX / 40 + .5) * MAP_WIDTH, y: (.5 - userPosition.worldZ / 33.25) * MAP_HEIGHT } : null
  const selectedDebugFeature = features.find(feature => feature.id === debugSelectedId)
  const mapItems = features.filter(feature => !['wall', 'external-area', 'street'].includes(feature.type))
  const buildingItems = features.filter(feature => feature.type === 'wall' || feature.type === 'external-area')

  return <div ref={containerRef} data-testid="bienal-map" className={`absolute inset-0 min-h-[520px] overflow-hidden select-none ${dark ? 'bg-slate-950' : 'bg-slate-100'}`} style={{ touchAction: 'none' }} {...handlers}>
    <div className="absolute inset-0 flex items-center justify-center p-2 sm:p-4">
      <div className="h-full w-full transition-transform duration-200 ease-out" style={{ transform: `translate3d(${transform.x}px, ${transform.y}px, 0) scale(${transform.zoom})`, transformOrigin: 'center center' }}>
        <svg ref={svgRef} viewBox="0 0 1376 1118" preserveAspectRatio="xMidYMid meet" width="100%" height="100%" className={`block h-full w-full ${isChoosingRouteOrigin ? 'cursor-crosshair' : ''}`} role="img" aria-labelledby="bienal-map-title bienal-map-description" onMouseMove={handleSvgMove} onClick={chooseOriginOnMap}>
          <title id="bienal-map-title">Mapa indoor da Bienal do Livro</title>
          <desc id="bienal-map-description">Mapa vetorial com pavilhões, ruas, estandes, portões, serviços e rota acessível pelos corredores.</desc>
          <defs>
            <pattern id="debug-grid" width="37" height="37" patternUnits="userSpaceOnUse"><path d="M37 0H0V37" fill="none" stroke="#0f172a" strokeWidth=".7" opacity=".48"/></pattern>
            <filter id="reference-contour"><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncR type="linear" slope="2.4" intercept="-.7"/><feFuncG type="linear" slope="2.4" intercept="-.7"/><feFuncB type="linear" slope="2.4" intercept="-.7"/></feComponentTransfer></filter>
          </defs>
          <g id="background-layer"><rect width={MAP_WIDTH} height={MAP_HEIGHT} fill={dark ? '#0f172a' : '#f1f5f9'} /></g>
          <MapReferenceLayer enabled={debug} opacity={referenceOpacity} mode={referenceMode} asset={MAP_REFERENCE_ASSET}/>
          <g id="external-layer">{buildingItems.map(feature => feature.geometry.type === 'polygon' ? <polygon key={feature.id} points={pointsString(feature.geometry.points)} fill={debug && cleanComparison ? 'none' : feature.type === 'wall' ? dark ? '#172033' : '#fff' : feature.id === 'external-north' ? '#dcfce7' : dark ? '#111827' : '#e5e7eb'} stroke={debugSelectedId === feature.id ? '#e11d48' : dark ? '#64748b' : '#94a3b8'} strokeWidth={debugSelectedId === feature.id ? 4 : 2} vectorEffect="non-scaling-stroke" onClick={debug ? event => { event.stopPropagation(); setDebugSelectedId(feature.id) } : undefined} className={debug ? 'cursor-pointer' : undefined}/> : null)}</g>
          <g id="street-layer">{MAP_STREETS.map(street => <g key={street.id}>{street.segments.map(([start, end], index) => <path key={index} d={`M ${start.x} ${start.y} L ${end.x} ${end.y}`} stroke={dark ? '#334155' : '#dbe1e8'} strokeWidth={street.width} strokeLinecap="butt"/>)}{!(debug && cleanComparison) && <text x={street.labelPosition.x} y={street.labelPosition.y} textAnchor="middle" dominantBaseline="middle" fontSize="9" fontWeight="900" fill={dark ? '#e2e8f0' : '#475569'}>{street.name.toUpperCase()}</text>}</g>)}</g>
          <g id="booth-and-service-layer">{mapItems.map(feature => {
            const exhibitor = feature.exhibitorId ? exhibitors.find(item => item.id === feature.exhibitorId) : undefined
            return <MapBooth key={feature.id} feature={feature} exhibitor={exhibitor} selected={(debug ? debugSelectedId : selectedStandId) === feature.id} favorite={Boolean(exhibitor && favorites.includes(exhibitor.id))} visited={Boolean(exhibitor && visits[exhibitor.id])} inRoute={Boolean(exhibitor && routeStops.some(stop => stop.exhibitorId === exhibitor.id))} isometric={isometric} zoom={transform.zoom} dark={dark} calibrationOutline={debug && cleanComparison} onSelect={() => selectFeature(feature)}/>
          })}</g>
          {!(debug && cleanComparison) && <MapRoute route={route}/>} 
          {!(debug && cleanComparison) && <g id="marker-layer">{user && <g transform={`translate(${user.x} ${user.y})`}><circle r="10" fill="#2563eb" stroke="#fff" strokeWidth="3" vectorEffect="non-scaling-stroke"/><circle r="3" fill="#fff"/><text y="-14" textAnchor="middle" fontSize="8" fontWeight="900" fill="#1d4ed8">VOCÊ ESTÁ AQUI</text></g>}</g>}
          {debug && showGrid && <rect width={MAP_WIDTH} height={MAP_HEIGHT} fill="url(#debug-grid)" pointerEvents="none"/>}
        </svg>
      </div>
    </div>
    {!debug && <><div className={`absolute bottom-3 left-3 rounded-xl border px-3 py-2 text-xs font-bold shadow-lg ${dark ? 'border-slate-700 bg-slate-900/90 text-slate-100' : 'border-slate-300 bg-white/95 text-slate-700'}`}><span className="flex items-center gap-2"><Sparkles className="h-4 w-4 text-pink-500"/>Mapa {isometric ? '2.5D' : '2D'} • {Math.round(transform.zoom * 100)}%</span></div><div className={`absolute left-3 top-3 rounded-xl border px-3 py-2 text-[11px] shadow-lg ${dark ? 'border-slate-700 bg-slate-900/90 text-slate-200' : 'border-slate-300 bg-white/95 text-slate-700'}`}><b className="text-violet-600">COLORIDO</b> expositor do banco • <b>CINZA</b> demais espaços</div></>}
    {debug && <MapCalibrationPanel selected={selectedDebugFeature} referenceOpacity={referenceOpacity} referenceMode={referenceMode} autoBlink={autoBlink} cleanComparison={cleanComparison} showGrid={showGrid} snap={snap} cursor={cursor ? { map: cursor, reference: mapToReference(cursor) } : null} onOpacity={setReferenceOpacity} onReferenceMode={setReferenceMode} onAutoBlink={setAutoBlink} onCleanComparison={setCleanComparison} onGrid={setShowGrid} onSnap={setSnap} onBlink={blinkReference} onUpdate={updateSelected} onPoints={replacePoints} onDuplicate={duplicate} onUndo={undo} onRedo={redo} onCopy={copyCoordinates} onExport={exportLayout}/>} 
    {route && !debug && <div className={`absolute bottom-3 hidden max-w-xs rounded-xl border p-3 text-xs shadow-xl sm:block ${selectedExhibitorId ? 'right-[466px]' : 'right-3'} ${dark ? 'border-slate-700 bg-slate-900/95 text-slate-200' : 'border-slate-300 bg-white/95 text-slate-700'}`}><div className="mb-1 flex items-center gap-1 font-black"><MapPin className="h-4 w-4 text-teal-600"/>Instruções</div><ol className="list-decimal space-y-1 pl-4">{route.instructions.slice(0, 5).map((instruction, index) => <li key={`${instruction}-${index}`}>{instruction}</li>)}</ol></div>}
    {isChoosingRouteOrigin && <div className="absolute left-1/2 top-3 z-30 -translate-x-1/2 rounded-xl bg-teal-700 px-4 py-2 text-sm font-black text-white shadow-xl">Clique em uma rua ou ponto próximo para definir a origem</div>}
  </div>
}
