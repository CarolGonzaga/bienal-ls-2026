import type { StandGeometry } from '../types/index.ts'

/**
 * Initial Stand Geometries (2026x1684 reference grid normalized coordinates 0..1).
 * Maps ALL 29 Exhibitors saved in the database plus full floor plan neutral stands/arenas.
 */
const BASE_STAND_GEOMETRIES: StandGeometry[] = [
  // ==========================================
  // 1. RUA A
  // ==========================================
  {
    id: "stand-a58",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "amazon",
    standCode: "A58",
    type: "polygon",
    polygon: [
      { x: 0.08, y: 0.52 },
      { x: 0.16, y: 0.52 },
      { x: 0.16, y: 0.60 },
      { x: 0.08, y: 0.60 }
    ],
    height: 1.5,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-a60",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "novo-seculo",
    standCode: "A60",
    type: "polygon",
    polygon: [
      { x: 0.08, y: 0.63 },
      { x: 0.16, y: 0.63 },
      { x: 0.16, y: 0.71 },
      { x: 0.08, y: 0.71 }
    ],
    height: 1.5,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-a80",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "flyve",
    standCode: "A80",
    type: "polygon",
    polygon: [
      { x: 0.08, y: 0.74 },
      { x: 0.16, y: 0.74 },
      { x: 0.16, y: 0.82 },
      { x: 0.08, y: 0.82 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // 2. RUA B
  // ==========================================
  {
    id: "stand-b79",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "uiclap",
    standCode: "B79",
    type: "polygon",
    polygon: [
      { x: 0.18, y: 0.74 },
      { x: 0.25, y: 0.74 },
      { x: 0.25, y: 0.82 },
      { x: 0.18, y: 0.82 }
    ],
    height: 1.5,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // 3. RUA C
  // ==========================================
  {
    id: "stand-c20",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "faro-editorial",
    standCode: "C20",
    type: "polygon",
    polygon: [
      { x: 0.27, y: 0.22 },
      { x: 0.34, y: 0.22 },
      { x: 0.34, y: 0.30 },
      { x: 0.27, y: 0.30 }
    ],
    height: 1.5,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-c28",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "drummond-livraria",
    standCode: "C28",
    type: "polygon",
    polygon: [
      { x: 0.27, y: 0.33 },
      { x: 0.34, y: 0.33 },
      { x: 0.34, y: 0.41 },
      { x: 0.27, y: 0.41 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // 4. RUA D
  // ==========================================
  {
    id: "stand-d30",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "sextante-e-arqueiro",
    standCode: "D30",
    type: "polygon",
    polygon: [
      { x: 0.36, y: 0.33 },
      { x: 0.43, y: 0.33 },
      { x: 0.43, y: 0.42 },
      { x: 0.36, y: 0.42 }
    ],
    height: 1.7,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-d58",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "harper-collins",
    standCode: "D58",
    type: "polygon",
    polygon: [
      { x: 0.36, y: 0.52 },
      { x: 0.43, y: 0.52 },
      { x: 0.43, y: 0.60 },
      { x: 0.36, y: 0.60 }
    ],
    height: 1.7,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // 5. RUA E
  // ==========================================
  {
    id: "stand-e18",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "qualis",
    standCode: "E18",
    type: "polygon",
    polygon: [
      { x: 0.45, y: 0.22 },
      { x: 0.52, y: 0.22 },
      { x: 0.52, y: 0.30 },
      { x: 0.45, y: 0.30 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-e30",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "intrinseca",
    standCode: "E30",
    type: "polygon",
    polygon: [
      { x: 0.45, y: 0.33 },
      { x: 0.52, y: 0.33 },
      { x: 0.52, y: 0.42 },
      { x: 0.45, y: 0.42 }
    ],
    height: 1.7,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-e60",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "companhia-das-letras",
    standCode: "E60",
    type: "polygon",
    polygon: [
      { x: 0.45, y: 0.45 },
      { x: 0.52, y: 0.45 },
      { x: 0.52, y: 0.53 },
      { x: 0.45, y: 0.53 }
    ],
    height: 1.8,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-e70",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "editora-globo",
    standCode: "E70",
    type: "polygon",
    polygon: [
      { x: 0.45, y: 0.56 },
      { x: 0.52, y: 0.56 },
      { x: 0.52, y: 0.64 },
      { x: 0.45, y: 0.64 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // 6. RUA F
  // ==========================================
  {
    id: "stand-f14",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "editora-caliope",
    standCode: "F14",
    type: "polygon",
    polygon: [
      { x: 0.54, y: 0.22 },
      { x: 0.61, y: 0.22 },
      { x: 0.61, y: 0.30 },
      { x: 0.54, y: 0.30 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-f40",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "autentica",
    standCode: "F40",
    type: "polygon",
    polygon: [
      { x: 0.54, y: 0.33 },
      { x: 0.61, y: 0.33 },
      { x: 0.61, y: 0.42 },
      { x: 0.54, y: 0.42 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-f60",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "grupo-editorial-record",
    standCode: "F60",
    type: "polygon",
    polygon: [
      { x: 0.54, y: 0.45 },
      { x: 0.61, y: 0.45 },
      { x: 0.61, y: 0.53 },
      { x: 0.54, y: 0.53 }
    ],
    height: 1.8,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-f70",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "editora-rocco",
    standCode: "F70",
    type: "polygon",
    polygon: [
      { x: 0.54, y: 0.56 },
      { x: 0.61, y: 0.56 },
      { x: 0.61, y: 0.64 },
      { x: 0.54, y: 0.64 }
    ],
    height: 1.8,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // 7. RUA G
  // ==========================================
  {
    id: "stand-g03",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "avec-editora",
    standCode: "G03",
    type: "polygon",
    polygon: [
      { x: 0.63, y: 0.12 },
      { x: 0.70, y: 0.12 },
      { x: 0.70, y: 0.19 },
      { x: 0.63, y: 0.19 }
    ],
    height: 1.4,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-g36",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "aditora-aleph",
    standCode: "G36",
    type: "polygon",
    polygon: [
      { x: 0.63, y: 0.22 },
      { x: 0.70, y: 0.22 },
      { x: 0.70, y: 0.30 },
      { x: 0.63, y: 0.30 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-g40",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "editora-planeta",
    standCode: "G40",
    type: "polygon",
    polygon: [
      { x: 0.63, y: 0.33 },
      { x: 0.70, y: 0.33 },
      { x: 0.70, y: 0.42 },
      { x: 0.63, y: 0.42 }
    ],
    height: 1.7,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-g50",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "vr-editora-plataforma-21-amore-latitude",
    standCode: "G50",
    type: "polygon",
    polygon: [
      { x: 0.63, y: 0.45 },
      { x: 0.70, y: 0.45 },
      { x: 0.70, y: 0.53 },
      { x: 0.63, y: 0.53 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-g70",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "citadel-e-altabooks",
    standCode: "G70",
    type: "polygon",
    polygon: [
      { x: 0.63, y: 0.56 },
      { x: 0.70, y: 0.56 },
      { x: 0.70, y: 0.64 },
      { x: 0.63, y: 0.64 }
    ],
    height: 1.5,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // 8. RUA H
  // ==========================================
  {
    id: "stand-h60",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "universo-dos-livros",
    standCode: "H60",
    type: "polygon",
    polygon: [
      { x: 0.72, y: 0.45 },
      { x: 0.79, y: 0.45 },
      { x: 0.79, y: 0.53 },
      { x: 0.72, y: 0.53 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-h70",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "editora-buzz",
    standCode: "H70",
    type: "polygon",
    polygon: [
      { x: 0.72, y: 0.56 },
      { x: 0.79, y: 0.56 },
      { x: 0.79, y: 0.64 },
      { x: 0.72, y: 0.64 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // 9. RUA J & K (Curadoria Sáfica Destacada)
  // ==========================================
  {
    id: "stand-j76",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "autores-independentes-do-brasil",
    standCode: "J76",
    type: "polygon",
    polygon: [
      { x: 0.81, y: 0.56 },
      { x: 0.88, y: 0.56 },
      { x: 0.88, y: 0.64 },
      { x: 0.81, y: 0.64 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-k28",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "cabana-vermelha",
    standCode: "K28",
    type: "polygon",
    polygon: [
      { x: 0.81, y: 0.22 },
      { x: 0.88, y: 0.22 },
      { x: 0.88, y: 0.30 },
      { x: 0.81, y: 0.30 }
    ],
    height: 1.6,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-k33",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "editora-sunbee",
    standCode: "K33",
    type: "polygon",
    polygon: [
      { x: 0.81, y: 0.33 },
      { x: 0.88, y: 0.33 },
      { x: 0.88, y: 0.42 },
      { x: 0.81, y: 0.42 }
    ],
    height: 2.0,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-k66",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "euphoria",
    standCode: "K66",
    type: "polygon",
    polygon: [
      { x: 0.81, y: 0.45 },
      { x: 0.88, y: 0.45 },
      { x: 0.88, y: 0.53 },
      { x: 0.81, y: 0.53 }
    ],
    height: 1.5,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },
  {
    id: "stand-k70",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "new-pop",
    standCode: "K70",
    type: "polygon",
    polygon: [
      { x: 0.81, y: 0.67 },
      { x: 0.88, y: 0.67 },
      { x: 0.88, y: 0.76 },
      { x: 0.81, y: 0.76 }
    ],
    height: 2.0,
    neutral: false,
    verified: true,
    verifiedBy: "admin-bienal"
  },

  // ==========================================
  // UNVERIFIED STAND (MANDATORY REQUIREMENT)
  // ==========================================
  {
    id: "stand-skeelo",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "skeelo",
    standCode: "AREA",
    type: "polygon",
    polygon: [],
    height: 0,
    neutral: false,
    verified: false,
    notes: "Localização exata aguardando confirmação."
  },

  // ==========================================
  // NEUTRAL CONTEXT STANDS & ARENAS (FULL BIENAL FLOOR MAP GRID)
  // ==========================================
  // Entrance Hall / Ticket Control
  {
    id: "neutral-entrance-hall",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "ENTRADA PRINCIPAL",
    type: "polygon",
    polygon: [
      { x: 0.08, y: 0.04 },
      { x: 0.30, y: 0.04 },
      { x: 0.30, y: 0.10 },
      { x: 0.08, y: 0.10 }
    ],
    height: 0.3,
    neutral: true,
    verified: true
  },
  // Arena Cultural Hauptbühne
  {
    id: "neutral-arena-cultural",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "ARENA CULTURAL BIENAL",
    type: "polygon",
    polygon: [
      { x: 0.33, y: 0.04 },
      { x: 0.60, y: 0.04 },
      { x: 0.60, y: 0.11 },
      { x: 0.33, y: 0.11 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },
  // Espaço Sessão de Autógrafos A
  {
    id: "neutral-autografos-a",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "ESPAÇO AUTÓGRAFOS 1",
    type: "polygon",
    polygon: [
      { x: 0.72, y: 0.04 },
      { x: 0.88, y: 0.04 },
      { x: 0.88, y: 0.11 },
      { x: 0.72, y: 0.11 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },

  // Neutral Blocks Corridor A/B
  {
    id: "neutral-a10",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "A10",
    type: "polygon",
    polygon: [
      { x: 0.08, y: 0.22 },
      { x: 0.16, y: 0.22 },
      { x: 0.16, y: 0.30 },
      { x: 0.08, y: 0.30 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "neutral-a30",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "A30",
    type: "polygon",
    polygon: [
      { x: 0.08, y: 0.33 },
      { x: 0.16, y: 0.33 },
      { x: 0.16, y: 0.41 },
      { x: 0.08, y: 0.41 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },

  // Neutral Blocks Corridor B/C
  {
    id: "neutral-b12",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "B12",
    type: "polygon",
    polygon: [
      { x: 0.18, y: 0.22 },
      { x: 0.25, y: 0.22 },
      { x: 0.25, y: 0.30 },
      { x: 0.18, y: 0.30 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "neutral-b40",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "B40",
    type: "polygon",
    polygon: [
      { x: 0.18, y: 0.33 },
      { x: 0.25, y: 0.33 },
      { x: 0.25, y: 0.42 },
      { x: 0.18, y: 0.42 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "neutral-b60",
    mapVersionId: "v1-bienal-sp-2026",
    exhibitorId: "",
    standCode: "B60",
    type: "polygon",
    polygon: [
      { x: 0.18, y: 0.52 },
      { x: 0.25, y: 0.52 },
      { x: 0.25, y: 0.64 },
      { x: 0.18, y: 0.64 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },

  // Neutral Blocks Corridor C/D
  {
    id: "neutral-c50",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "C50",
    type: "polygon",
    polygon: [
      { x: 0.27, y: 0.52 },
      { x: 0.34, y: 0.52 },
      { x: 0.34, y: 0.64 },
      { x: 0.27, y: 0.64 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "neutral-c75",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "C75",
    type: "polygon",
    polygon: [
      { x: 0.27, y: 0.74 },
      { x: 0.34, y: 0.74 },
      { x: 0.34, y: 0.82 },
      { x: 0.27, y: 0.82 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },

  // Neutral Blocks Corridor D/E
  {
    id: "neutral-d20",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "D20",
    type: "polygon",
    polygon: [
      { x: 0.36, y: 0.22 },
      { x: 0.43, y: 0.22 },
      { x: 0.43, y: 0.30 },
      { x: 0.36, y: 0.30 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "neutral-d70",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "D70",
    type: "polygon",
    polygon: [
      { x: 0.36, y: 0.67 },
      { x: 0.43, y: 0.67 },
      { x: 0.43, y: 0.82 },
      { x: 0.36, y: 0.82 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },

  // Neutral Blocks Corridor H/J
  {
    id: "neutral-h20",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "H20",
    type: "polygon",
    polygon: [
      { x: 0.72, y: 0.22 },
      { x: 0.79, y: 0.22 },
      { x: 0.79, y: 0.30 },
      { x: 0.72, y: 0.30 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "neutral-h35",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "H35",
    type: "polygon",
    polygon: [
      { x: 0.72, y: 0.33 },
      { x: 0.79, y: 0.33 },
      { x: 0.79, y: 0.42 },
      { x: 0.72, y: 0.42 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },

  // ==========================================
  // SERVICE & VENUE LANDMARKS (PORTÕES, BANHEIROS, POSTO MÉDICO, ALIMENTAÇÃO)
  // ==========================================

  // GATES & ACCESS (PORTÕES)
  {
    id: "service-gate-1",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "PORTÃO 1 (ENTRADA PRINCIPAL)",
    type: "polygon",
    serviceType: "gate",
    polygon: [
      { x: 0.08, y: 0.02 },
      { x: 0.22, y: 0.02 },
      { x: 0.22, y: 0.08 },
      { x: 0.08, y: 0.08 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },
  {
    id: "service-gate-2",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "PORTÃO 2 (AUDITÓRIOS)",
    type: "polygon",
    serviceType: "gate",
    polygon: [
      { x: 0.90, y: 0.20 },
      { x: 0.98, y: 0.20 },
      { x: 0.98, y: 0.27 },
      { x: 0.90, y: 0.27 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },
  {
    id: "service-gate-3",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "PORTÃO 3 (ENTRADA VIP / IMPRENSA)",
    type: "polygon",
    serviceType: "gate",
    polygon: [
      { x: 0.02, y: 0.20 },
      { x: 0.07, y: 0.20 },
      { x: 0.07, y: 0.27 },
      { x: 0.02, y: 0.27 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },
  {
    id: "service-gate-4",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "PORTÃO 4 (SAÍDA / EMERGENCIAL)",
    type: "polygon",
    serviceType: "gate",
    polygon: [
      { x: 0.08, y: 0.92 },
      { x: 0.22, y: 0.92 },
      { x: 0.22, y: 0.98 },
      { x: 0.08, y: 0.98 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },

  // MEDICAL STATIONS (ALA MÉDICA / PRIMEIROS SOCORROS)
  {
    id: "service-medical-north",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "POSTO MÉDICO NORTE (ALA MÉDICA)",
    type: "polygon",
    serviceType: "medical",
    polygon: [
      { x: 0.02, y: 0.35 },
      { x: 0.07, y: 0.35 },
      { x: 0.07, y: 0.45 },
      { x: 0.02, y: 0.45 }
    ],
    height: 0.6,
    neutral: true,
    verified: true
  },
  {
    id: "service-medical-south",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "POSTO MÉDICO SUL (ALA MÉDICA)",
    type: "polygon",
    serviceType: "medical",
    polygon: [
      { x: 0.90, y: 0.75 },
      { x: 0.98, y: 0.75 },
      { x: 0.98, y: 0.85 },
      { x: 0.90, y: 0.85 }
    ],
    height: 0.6,
    neutral: true,
    verified: true
  },

  // RESTROOMS (BANHEIROS MASC/FEM/PCD)
  {
    id: "service-restroom-north",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "BANHEIROS NORTE (PCD/M/F)",
    type: "polygon",
    serviceType: "restroom",
    polygon: [
      { x: 0.24, y: 0.02 },
      { x: 0.32, y: 0.02 },
      { x: 0.32, y: 0.08 },
      { x: 0.24, y: 0.08 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "service-restroom-south",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "BANHEIROS SUL (PCD/M/F)",
    type: "polygon",
    serviceType: "restroom",
    polygon: [
      { x: 0.72, y: 0.92 },
      { x: 0.88, y: 0.92 },
      { x: 0.88, y: 0.98 },
      { x: 0.72, y: 0.98 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "service-restroom-east",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "BANHEIROS LESTE (PCD/M/F)",
    type: "polygon",
    serviceType: "restroom",
    polygon: [
      { x: 0.90, y: 0.45 },
      { x: 0.98, y: 0.45 },
      { x: 0.98, y: 0.55 },
      { x: 0.90, y: 0.55 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "service-restroom-west",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "BANHEIROS OESTE (PCD/M/F)",
    type: "polygon",
    serviceType: "restroom",
    polygon: [
      { x: 0.02, y: 0.65 },
      { x: 0.07, y: 0.65 },
      { x: 0.07, y: 0.75 },
      { x: 0.02, y: 0.75 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },

  // FOOD COURTS & CAFES (PRAÇA DE ALIMENTAÇÃO)
  {
    id: "service-food-court-south",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "PRAÇA DE ALIMENTAÇÃO PRINCIPAL",
    type: "polygon",
    serviceType: "food",
    polygon: [
      { x: 0.35, y: 0.90 },
      { x: 0.68, y: 0.90 },
      { x: 0.68, y: 0.98 },
      { x: 0.35, y: 0.98 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "service-food-court-east",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "VILA GASTRONÔMICA LESTE",
    type: "polygon",
    serviceType: "food",
    polygon: [
      { x: 0.90, y: 0.58 },
      { x: 0.98, y: 0.58 },
      { x: 0.98, y: 0.70 },
      { x: 0.90, y: 0.70 }
    ],
    height: 0.5,
    neutral: true,
    verified: true
  },
  {
    id: "service-cafe-north",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "ESPAÇO CAFÉ & DESCANSO",
    type: "polygon",
    serviceType: "food",
    polygon: [
      { x: 0.62, y: 0.02 },
      { x: 0.70, y: 0.02 },
      { x: 0.70, y: 0.08 },
      { x: 0.62, y: 0.08 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },

  // INFORMATION, LOST & FOUND, ACCESSIBILITY
  {
    id: "service-info-desk",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "INFORMAÇÕES / ACHADOS E PERDIDOS",
    type: "polygon",
    serviceType: "info",
    polygon: [
      { x: 0.24, y: 0.12 },
      { x: 0.32, y: 0.12 },
      { x: 0.32, y: 0.18 },
      { x: 0.24, y: 0.18 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },
  {
    id: "service-pcd-center",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "ESPAÇO ACESSIBILIDADE PCD",
    type: "polygon",
    serviceType: "accessibility",
    polygon: [
      { x: 0.02, y: 0.10 },
      { x: 0.07, y: 0.10 },
      { x: 0.07, y: 0.18 },
      { x: 0.02, y: 0.18 }
    ],
    height: 0.4,
    neutral: true,
    verified: true
  },

  // STAGES & AUDITORIUMS
  {
    id: "service-arena-cultural",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "ARENA CULTURAL BIENAL",
    type: "polygon",
    serviceType: "stage",
    polygon: [
      { x: 0.34, y: 0.02 },
      { x: 0.60, y: 0.02 },
      { x: 0.60, y: 0.09 },
      { x: 0.34, y: 0.09 }
    ],
    height: 0.6,
    neutral: true,
    verified: true
  },
  {
    id: "service-autografos",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "SALÃO DE AUTÓGRAFOS",
    type: "polygon",
    serviceType: "stage",
    polygon: [
      { x: 0.72, y: 0.02 },
      { x: 0.88, y: 0.02 },
      { x: 0.88, y: 0.09 },
      { x: 0.72, y: 0.09 }
    ],
    height: 0.6,
    neutral: true,
    verified: true
  },
  {
    id: "service-auditorio-ziraldo",
    mapVersionId: "v1-bienal-sp-2026",
    standCode: "AUDITÓRIO ZIRALDO",
    type: "polygon",
    serviceType: "stage",
    polygon: [
      { x: 0.90, y: 0.30 },
      { x: 0.98, y: 0.30 },
      { x: 0.98, y: 0.42 },
      { x: 0.90, y: 0.42 }
    ],
    height: 0.6,
    neutral: true,
    verified: true
  }
]

/**
 * Bounds transcribed from mapa-bienal-v4.webp at its native 7955x6436
 * resolution. The source image is calibration-only and is never rendered in
 * the public digital map.
 */
const OFFICIAL_EXHIBITOR_BOUNDS: Record<string, [number, number, number, number]> = {
  amazon: [2660, 4324, 3010, 4481],
  'novo-seculo': [2317, 4324, 2551, 4481],
  flyve: [1313, 4402, 1438, 4481],
  uiclap: [1460, 4026, 1610, 4183],
  'faro-editorial': [5700, 3728, 5999, 3887],
  'drummond-livraria': [5544, 3728, 5700, 3887],
  'sextante-e-arqueiro': [4885, 3432, 5435, 3588],
  'harper-collins': [3700, 3432, 4666, 3588],
  qualis: [6123, 3101, 6516, 3259],
  intrinseca: [4885, 3101, 5435, 3259],
  'companhia-das-letras': [2034, 3101, 2551, 3259],
  'editora-globo': [1500, 3101, 1924, 3259],
  'editora-caliope': [6280, 2930, 6358, 3009],
  autentica: [4587, 2851, 4775, 3009],
  'grupo-editorial-record': [2034, 2851, 2551, 3009],
  'editora-rocco': [1500, 2851, 1924, 3009],
  'avec-editora': [6610, 2788, 6658, 2910],
  'aditora-aleph': [5073, 2552, 5198, 2710],
  'editora-planeta': [4384, 2552, 4775, 2710],
  'vr-editora-plataforma-21-amore-latitude': [4189, 2552, 4384, 2710],
  'citadel-e-altabooks': [1500, 2552, 1924, 2710],
  'universo-dos-livros': [2034, 2271, 2551, 2429],
  'editora-buzz': [1673, 2271, 1924, 2429],
  'autores-independentes-do-brasil': [1300, 2005, 1635, 2163],
  'cabana-vermelha': [4212, 1589, 4306, 1824],
  'editora-sunbee': [5255, 2005, 5325, 2163],
  euphoria: [2164, 1606, 2211, 1825],
  'new-pop': [1779, 1606, 2063, 1825],
  skeelo: [4306, 1589, 4400, 1707]
}

const SOURCE_WIDTH = 7955
const SOURCE_HEIGHT = 6436

const polygonFromBounds = ([x1, y1, x2, y2]: [number, number, number, number]) => [
  { x: x1 / SOURCE_WIDTH, y: y1 / SOURCE_HEIGHT },
  { x: x2 / SOURCE_WIDTH, y: y1 / SOURCE_HEIGHT },
  { x: x2 / SOURCE_WIDTH, y: y2 / SOURCE_HEIGHT },
  { x: x1 / SOURCE_WIDTH, y: y2 / SOURCE_HEIGHT }
]

export const INITIAL_STAND_GEOMETRIES: StandGeometry[] = BASE_STAND_GEOMETRIES.map(geometry => {
  if (!geometry.exhibitorId) return geometry
  const officialBounds = OFFICIAL_EXHIBITOR_BOUNDS[geometry.exhibitorId]
  if (!officialBounds) return geometry

  return {
    ...geometry,
    standCode: geometry.exhibitorId === 'skeelo' ? 'K24' : geometry.standCode,
    polygon: polygonFromBounds(officialBounds),
    verified: true,
    verifiedBy: 'calibracao-planta-oficial',
    notes: 'Posição vetorizada da planta oficial mapa-bienal-v4.webp.'
  }
})
