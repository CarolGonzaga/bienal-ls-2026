export interface MapFocusInput {
  centerXNorm: number
  centerYNorm: number
  viewportWidth: number
  viewportHeight: number
  zoom: number
  contentAspectRatio?: number
}

export const calculateMapFocusOffset = ({
  centerXNorm,
  centerYNorm,
  viewportWidth,
  viewportHeight,
  zoom,
  contentAspectRatio = 16 / 9
}: MapFocusInput) => {
  const viewportAspectRatio = viewportWidth / viewportHeight
  const fittedWidth = viewportAspectRatio > contentAspectRatio
    ? viewportHeight * contentAspectRatio
    : viewportWidth
  const fittedHeight = viewportAspectRatio > contentAspectRatio
    ? viewportHeight
    : viewportWidth / contentAspectRatio

  const deltaX = centerXNorm - .5
  const deltaY = centerYNorm - .5
  return {
    x: deltaX === 0 ? 0 : -deltaX * fittedWidth * zoom,
    y: deltaY === 0 ? 0 : -deltaY * fittedHeight * zoom
  }
}
