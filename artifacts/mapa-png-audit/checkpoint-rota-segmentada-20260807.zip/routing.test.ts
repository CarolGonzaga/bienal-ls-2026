import test from 'node:test'
import assert from 'node:assert/strict'
import { boothAccessPoint, buildMapLayout } from '../../data/map/map-layout.ts'
import { INITIAL_STAND_GEOMETRIES } from '../../data/initialStands.ts'
import { buildRoutingGraph } from '../../data/map/map-routing-graph.ts'
import { buildRouteSegments, findRoute, parseMapRouteParams } from '../../services/mapRoutingService.ts'
import { validateGraph, validateRouteObstacles } from '../../services/mapLayoutValidationService.ts'

const features = buildMapLayout(INITIAL_STAND_GEOMETRIES)
const graph = buildRoutingGraph(features)
const destination = features.find(feature => feature.boothCode === 'G36' && feature.exhibitorId)!

test('grafo não possui arestas apontando para nós inexistentes', () => {
  assert.deepEqual(validateGraph(graph), [])
})

test('encontra rota do Portão 8 até a borda do estande', () => {
  const route = findRoute(graph, 'P8', `access-${destination.id}`)
  assert.ok(route)
  assert.equal(route!.nodeIds[0], 'P8')
  assert.equal(route!.nodeIds.at(-1), `access-${destination.id}`)
  const access = boothAccessPoint(destination)
  const end = route!.points.at(-1)!
  assert.equal(end.x, access?.x)
  assert.equal(end.y, access?.y)
})

test('todos os portões de A a F e acessos Hall 1 a 5 são origens navegáveis', () => {
  const origins = ['PA', 'PB', 'PC', 'PD', 'PE', 'PF', 'HALL1', 'HALL2', 'HALL3', 'HALL4', 'HALL5']
  origins.forEach(origin => {
    const route = findRoute(graph, origin, `access-${destination.id}`)
    assert.ok(route, origin)
    assert.equal(route!.nodeIds[0], origin)
  })
})

test('encontra rota entre dois estandes', () => {
  const other = features.find(feature => feature.boothCode === 'A58' && feature.exhibitorId)!
  assert.ok(findRoute(graph, `access-${destination.id}`, `access-${other.id}`))
})

test('permite iniciar em C28 e navegar até K33', () => {
  const origin = features.find(feature => feature.boothCode === 'C28' && feature.exhibitorId)!
  const target = features.find(feature => feature.boothCode === 'K33' && feature.exhibitorId)!
  const route = findRoute(graph, `access-${origin.id}`, `access-${target.id}`)
  assert.ok(route)
  assert.equal(route!.nodeIds[0], `access-${origin.id}`)
  assert.equal(route!.nodeIds.at(-1), `access-${target.id}`)
})

test('separa Hall 1 → K70 e K70 → G36 em trechos de cores diferentes', () => {
  const k70 = features.find(feature => feature.boothCode === 'K70' && feature.exhibitorId)!
  const g36 = features.find(feature => feature.boothCode === 'G36' && feature.exhibitorId)!
  const segments = buildRouteSegments(graph, features, 'HALL1', [
    { exhibitorId: k70.exhibitorId!, standCode: 'K70', visited: false, order: 1 },
    { exhibitorId: g36.exhibitorId!, standCode: 'G36', visited: false, order: 2 }
  ])
  assert.equal(segments.length, 2)
  assert.deepEqual(segments.map(segment => [segment.fromLabel, segment.toLabel]), [['Entrada Hall 1', 'K70'], ['K70', 'G36']])
  assert.notEqual(segments[0].color, segments[1].color)
  assert.equal(segments[0].nodeIds.at(-1), segments[1].nodeIds[0])
})

test('todos os 29 expositores confirmados possuem acesso e rota pelo grafo', () => {
  const confirmed = features.filter(feature => feature.exhibitorId)
  assert.equal(confirmed.length, 29)
  confirmed.forEach(feature => assert.ok(findRoute(graph, 'P8', `access-${feature.id}`), feature.boothCode))
})

test('interpreta origin e destination da URL sem diferenciar maiúsculas', () => {
  assert.deepEqual(parseMapRouteParams('?origin=p9&destination=h70'), { origin: 'P9', destination: 'H70' })
})

test('origem ou destino inexistente retorna nulo', () => {
  assert.equal(findRoute(graph, 'inexistente', `access-${destination.id}`), null)
  assert.equal(findRoute(graph, 'P8', 'inexistente'), null)
})

test('rota bloqueada retorna nulo', () => {
  const blocked = { ...graph, edges: graph.edges.map(edge => ({ ...edge, blocked: true })) }
  assert.equal(findRoute(blocked, 'P8', `access-${destination.id}`), null)
})

test('arestas caminháveis não atravessam estandes ou áreas fechadas', () => {
  assert.deepEqual(validateRouteObstacles(graph, features), [])
})
