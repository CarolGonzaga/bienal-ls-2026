import React from 'react'
import type { CalculatedRouteSegment } from '../../services/mapRoutingService.ts'

export const MapRoute: React.FC<{ segments: CalculatedRouteSegment[] }> = ({ segments }) => {
  if (!segments.length) return null
  const origin = segments[0].points[0]
  return <g id="route-layer" data-testid="gps-route" className="pointer-events-none">
    {segments.map(segment => {
      const d = segment.points.map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`).join(' ')
      const destination = segment.points[segment.points.length - 1]
      return <g key={`${segment.fromId}-${segment.toId}`} data-route-segment={segment.index + 1} data-route-from={segment.fromLabel} data-route-to={segment.toLabel} data-route-color={segment.color}>
        <path d={d} fill="none" stroke="#fff" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <path d={d} fill="none" stroke={segment.color} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <g transform={`translate(${destination.x} ${destination.y})`}>
          <circle r="10" fill={segment.color} stroke="#fff" strokeWidth="3" vectorEffect="non-scaling-stroke"/>
          <text textAnchor="middle" dominantBaseline="middle" fontSize="8" fontWeight="900" fill="#fff">{segment.index + 1}</text>
        </g>
      </g>
    })}
    <g transform={`translate(${origin.x} ${origin.y})`}><circle r="8" fill="#059669" stroke="#fff" strokeWidth="3" vectorEffect="non-scaling-stroke"/><circle r="2.5" fill="#fff"/></g>
  </g>
}
