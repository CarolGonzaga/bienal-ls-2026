import React from 'react'
import { Search, X, Sparkles } from 'lucide-react'
import { useExhibitorStore } from '../../stores/useExhibitorStore'

export const SearchBar: React.FC = () => {
  const searchQuery = useExhibitorStore(s => s.searchQuery)
  const setSearchQuery = useExhibitorStore(s => s.setSearchQuery)

  return (
    <div className="relative w-full max-w-xl">
      <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#b94185]" />
      <input
        type="text"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        placeholder="Busque por editora, código (ex: K33), autora ou trope (ex: enemies to lovers)..."
        className="w-full rounded-2xl border border-[#efc4d9] bg-white py-2.5 pl-11 pr-10 text-xs text-[#4b1738] shadow-sm transition-all placeholder:text-[#b77c9b] focus:border-transparent focus:outline-none focus:ring-2 focus:ring-[#d43276] sm:text-sm"
      />

      {searchQuery && (
        <button
          onClick={() => setSearchQuery('')}
          className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-[#a86689] transition-colors hover:bg-[#fff0f6] hover:text-[#cf005e]"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  )
}
