import React, { useState } from 'react'
import {
  Calendar,
  User, 
  Compass, 
  Award, 
  Bookmark, 
  ShieldCheck,
  Eye,
  LogOut,
  List,
  Route,
  SlidersHorizontal
} from 'lucide-react'
import { useExhibitorStore } from './stores/useExhibitorStore'
import { useMapStore } from './stores/useMapStore'
import { useAdminMapStore } from './stores/useAdminMapStore'
import { useUserStore } from './stores/useUserStore'

import { BienalMap } from './components/map/BienalMap'
import { MapControls } from './components/map/MapControls'
import { ExhibitorList } from './components/exhibitors/ExhibitorList'
import { ExhibitorBottomSheet } from './components/exhibitors/ExhibitorBottomSheet'
import { SearchBar } from './components/search/SearchBar'
import { SapphicPassport } from './components/passport/SapphicPassport'
import { RoutePlanner } from './components/route/RoutePlanner'
import { ScheduleView } from './components/schedule/ScheduleView'
import { AdminSuite } from './components/admin/AdminSuite'
import { AccessibilityPanel } from './components/accessibility/AccessibilityPanel'
import AuthModal from './components/AuthModal'

export default function App() {
  const activeTabMode = useExhibitorStore(s => s.activeTabMode)
  const setActiveTabMode = useExhibitorStore(s => s.setActiveTabMode)
  const selectedExhibitorId = useExhibitorStore(s => s.selectedExhibitorId)
  const setSelectedExhibitorId = useExhibitorStore(s => s.setSelectedExhibitorId)
  const exhibitors = useExhibitorStore(s => s.exhibitors)

  const selectedStandId = useMapStore(s => s.selectedStandId)
  const setSelectedStandId = useMapStore(s => s.setSelectedStandId)
  const reducedMotion = useMapStore(s => s.reducedMotion)

  const geometries = useAdminMapStore(s => s.geometries)

  const user = useUserStore(s => s.user)
  const setUser = useUserStore(s => s.setUser)

  const [isAuthOpen, setIsAuthOpen] = useState(false)
  const [isAccessibilityOpen, setIsAccessibilityOpen] = useState(false)
  const [isMobileMapSettingsOpen, setIsMobileMapSettingsOpen] = useState(false)

  const selectedExhibitor = exhibitors.find(e => e.id === selectedExhibitorId)
  const selectedGeometry = geometries.find(g => g.id === selectedStandId)

  const handleCloseDrawer = () => {
    setSelectedExhibitorId(null)
    setSelectedStandId(null)
  }

  return (
    <div className={`brand-shell relative flex min-h-[100dvh] flex-col overflow-x-hidden bg-[#25091c] font-sans text-slate-100 lg:overflow-hidden ${reducedMotion ? 'reduce-motion' : ''}`}>
      
      {/* Header Navigation */}
      <header className="sticky top-0 z-40 border-b border-[#f3c6dc] bg-[#fffafd]/95 text-[#4b1738] shadow-sm backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          
          {/* Logo & Title */}
          <div className="flex min-w-0 items-center gap-3">
            <div className="relative h-12 w-12 shrink-0 overflow-hidden sm:h-14 sm:w-44">
              <picture>
                <source media="(min-width: 640px)" srcSet="/logo-completo.png"/>
                <img src="/logo-icon.png" alt="Mapa Sáfico" className="absolute left-1/2 top-1/2 h-16 w-16 max-w-none -translate-x-1/2 -translate-y-1/2 object-contain sm:h-44 sm:w-44"/>
              </picture>
            </div>
            <div className="sr-only">
              <span className="text-lg sm:text-xl font-extrabold bg-gradient-to-r from-white via-slate-200 to-pink-300 bg-clip-text text-transparent leading-tight block">
                Mapa Sáfico
              </span>
              <span className="text-[10px] font-bold text-slate-400">
                Bienal SP 2026
              </span>
            </div>
          </div>

          {/* Search Bar in Header for larger screens */}
          <div className="hidden lg:block flex-1 max-w-md">
            <SearchBar />
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden items-center gap-1 rounded-full border border-[#f3c6dc] bg-[#fff0f6] p-1.5 md:flex">
            {[
              { id: 'map', label: 'Mapa', icon: Compass },
              { id: 'list', label: 'Editoras', icon: List },
              { id: 'passport', label: 'Passaporte', icon: Award },
              { id: 'route', label: 'Minha Rota', icon: Bookmark },
              { id: 'schedule', label: 'Programação', icon: Calendar },
              { id: 'admin', label: 'Admin', icon: ShieldCheck }
            ].map(tab => {
              const Icon = tab.icon
              const isActive = activeTabMode === tab.id
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTabMode(tab.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    isActive 
                      ? 'bg-[#d43276] text-white shadow-md shadow-[#d43276]/25'
                      : 'text-[#7b3a60] hover:bg-white hover:text-[#cf005e]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAccessibilityOpen(true)}
              className="rounded-xl border border-[#f3c6dc] bg-white p-2.5 text-[#8d4c70] transition-colors hover:bg-[#fff0f6] hover:text-[#cf005e]"
              title="Acessibilidade"
            >
              <Eye className="w-4 h-4" />
            </button>

            {user ? (
              <div className="flex items-center gap-2 rounded-2xl border border-[#e7a5c5] bg-white px-3 py-1.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-tr from-[#b94185] to-[#d43276] text-xs font-bold text-white">
                  {(user.user_metadata?.name || user.email)[0].toUpperCase()}
                </div>
                <span className="hidden sm:inline text-xs font-semibold text-slate-200 max-w-[100px] truncate">
                  {user.user_metadata?.name || user.email}
                </span>
                <button
                  onClick={() => setUser(null)}
                  title="Sair"
                  className="p-1 rounded-lg text-slate-400 hover:text-rose-400 transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setIsAuthOpen(true)}
                className="flex items-center gap-1.5 rounded-xl bg-[#d43276] px-3.5 py-2 text-xs font-semibold text-white shadow-md shadow-[#d43276]/25 transition-all hover:bg-[#cf005e]"
              >
                <User className="w-3.5 h-3.5 text-white" />
                <span>Entrar</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex items-center justify-around border-t border-[#f5d9e6] bg-white px-2 py-2 text-xs font-semibold md:hidden">
          {[
            { id: 'map', label: 'Mapa', icon: Compass },
            { id: 'list', label: 'Editoras', icon: List },
            { id: 'passport', label: 'Passaporte', icon: Award },
            { id: 'route', label: 'Rota', icon: Bookmark },
            { id: 'schedule', label: 'Agenda', icon: Calendar },
            { id: 'admin', label: 'Admin', icon: ShieldCheck }
          ].map(tab => {
            const Icon = tab.icon
            const isActive = activeTabMode === tab.id
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTabMode(tab.id)}
                className={`flex flex-col items-center gap-1 py-1 px-2 rounded-xl transition-all ${
                  isActive ? 'bg-[#fff0f6] text-[#cf005e] font-bold' : 'text-[#98617f]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-[10px]">{tab.label}</span>
              </button>
            )
          })}
        </div>
      </header>

      {/* Main Content Render */}
      <main className="relative flex min-h-0 w-full flex-1 flex-col overflow-y-auto lg:h-[calc(100dvh-80px)] lg:overflow-hidden">
        {activeTabMode === 'map' && (
          <div className="relative flex min-h-0 flex-1 flex-col gap-3 bg-[#fff7fb] px-3 py-3 lg:absolute lg:inset-0 lg:block lg:bg-transparent lg:p-0">
            <div data-testid="mobile-map-toolbar" className="flex shrink-0 flex-col gap-3 lg:hidden">
              <SearchBar />
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setActiveTabMode('route')} className="flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#d43276] to-[#e11d74] px-3 text-sm font-black text-white shadow-lg shadow-[#cf005e]/20">
                  <Route className="h-4 w-4"/><span>Montar minha rota</span>
                </button>
                <button aria-expanded={isMobileMapSettingsOpen} aria-controls="mobile-map-settings-panel" onClick={() => setIsMobileMapSettingsOpen(open => !open)} className="flex min-h-12 items-center justify-center gap-2 rounded-2xl border border-[#e7a5c5] bg-white px-3 text-sm font-black text-[#b94185] shadow-sm">
                  <SlidersHorizontal className="h-4 w-4"/><span>Ajustar mapa</span>
                </button>
              </div>
              {isMobileMapSettingsOpen && <div id="mobile-map-settings-panel"><MapControls variant="mobile-settings"/></div>}
            </div>

            <div data-testid="mobile-map-frame" className="relative h-[58dvh] min-h-[420px] max-h-[620px] shrink-0 overflow-hidden rounded-3xl border border-[#efbfd6] bg-white shadow-2xl shadow-[#b94185]/10 lg:absolute lg:inset-0 lg:h-auto lg:max-h-none lg:rounded-none lg:border-0">
              <BienalMap />
              <MapControls variant="mobile-map" />
              <MapControls variant="desktop" panelOpen={Boolean(selectedExhibitor)} />
            </div>
          </div>
        )}

        {activeTabMode === 'list' && <ExhibitorList />}
        {activeTabMode === 'passport' && <SapphicPassport />}
        {activeTabMode === 'route' && <RoutePlanner />}
        {activeTabMode === 'schedule' && <ScheduleView />}
        {activeTabMode === 'admin' && <AdminSuite />}
      </main>

      {/* Floating Selected Exhibitor Bottom Sheet / Side Panel */}
      {selectedExhibitor && (
        <ExhibitorBottomSheet
          exhibitor={selectedExhibitor}
          geometry={selectedGeometry}
          onClose={handleCloseDrawer}
        />
      )}

      {/* Accessibility Panel Modal */}
      <AccessibilityPanel
        isOpen={isAccessibilityOpen}
        onClose={() => setIsAccessibilityOpen(false)}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={(userData) => setUser(userData)}
      />
    </div>
  )
}
