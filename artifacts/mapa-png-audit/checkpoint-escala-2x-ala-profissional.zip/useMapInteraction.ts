import { useState, useCallback, useRef, useEffect } from 'react'
import { calculateMapFocusOffset } from '../utils/mapCamera.ts'

interface MapTransform {
  x: number
  y: number
  zoom: number
  tiltDeg: number
}

interface UseMapInteractionOptions {
  minZoom?: number
  maxZoom?: number
  initialZoom?: number
  minTilt?: number
  maxTilt?: number
  initialTilt?: number
  zoomStep?: number
  focusZoom?: number
}

interface UseMapInteractionReturn {
  transform: MapTransform
  containerRef: React.RefObject<HTMLDivElement>
  handlers: {
    onMouseDown: (e: React.MouseEvent) => void
    onMouseMove: (e: React.MouseEvent) => void
    onMouseUp: () => void
    onMouseLeave: () => void
    onWheel: (e: React.WheelEvent) => void
    onTouchStart: (e: React.TouchEvent) => void
    onTouchMove: (e: React.TouchEvent) => void
    onTouchEnd: () => void
    onDoubleClick: (e: React.MouseEvent) => void
  }
  animateToStand: (centerXNorm: number, centerYNorm: number) => void
  resetView: () => void
  setTilt: (deg: number) => void
  zoomIn: () => void
  zoomOut: () => void
}

export function useMapInteraction(options: UseMapInteractionOptions = {}): UseMapInteractionReturn {
  const {
    minZoom = 0.4,
    maxZoom = 4,
    initialZoom = 1,
    minTilt = 0,
    maxTilt = 55,
    initialTilt = 45,
    zoomStep = 0.15,
    focusZoom = 2.2
  } = options

  const containerRef = useRef<HTMLDivElement>(null)

  const [transform, setTransform] = useState<MapTransform>({
    x: 0,
    y: 0,
    zoom: Math.min(Math.max(initialZoom, minZoom), maxZoom),
    tiltDeg: initialTilt
  })

  // Dragging state
  const isDragging = useRef(false)
  const dragStart = useRef({ x: 0, y: 0 })
  const transformStart = useRef({ x: 0, y: 0 })

  // Pinch zoom state
  const lastPinchDistance = useRef(0)

  // Animation frame ref
  const animFrameRef = useRef<number>()

  const clamp = (val: number, min: number, max: number) => Math.min(Math.max(val, min), max)

  // Mouse handlers
  const onMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return // Left click only
    isDragging.current = true
    dragStart.current = { x: e.clientX, y: e.clientY }
    transformStart.current = { x: transform.x, y: transform.y }
    e.preventDefault()
  }, [transform.x, transform.y])

  const onMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging.current) return
    const dx = e.clientX - dragStart.current.x
    const dy = e.clientY - dragStart.current.y
    const rect = containerRef.current?.getBoundingClientRect()
    setTransform(prev => ({ ...prev,
      x: clamp(transformStart.current.x + dx / prev.zoom, -(rect?.width || 1000) * .7, (rect?.width || 1000) * .7),
      y: clamp(transformStart.current.y + dy / prev.zoom, -(rect?.height || 700) * .7, (rect?.height || 700) * .7)
    }))
  }, [])

  const onMouseUp = useCallback(() => {
    isDragging.current = false
  }, [])

  const onMouseLeave = useCallback(() => {
    isDragging.current = false
  }, [])

  const onWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault()
    const delta = -e.deltaY * 0.001
    const rect = containerRef.current?.getBoundingClientRect()
    setTransform(prev => {
      const zoom = clamp(prev.zoom + delta * prev.zoom, minZoom, maxZoom)
      if (!rect || zoom === prev.zoom) return { ...prev, zoom }
      const ratio = zoom / prev.zoom
      const focalX = e.clientX - rect.left - rect.width / 2
      const focalY = e.clientY - rect.top - rect.height / 2
      return {
        ...prev,
        x: prev.x + (1 - ratio) * (focalX - prev.x),
        y: prev.y + (1 - ratio) * (focalY - prev.y),
        zoom
      }
    })
  }, [minZoom, maxZoom])

  // Touch handlers
  const getTouchDistance = (touches: React.TouchList) => {
    if (touches.length < 2) return 0
    const dx = touches[0].clientX - touches[1].clientX
    const dy = touches[0].clientY - touches[1].clientY
    return Math.sqrt(dx * dx + dy * dy)
  }

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      isDragging.current = true
      dragStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }
      transformStart.current = { x: transform.x, y: transform.y }
    } else if (e.touches.length === 2) {
      lastPinchDistance.current = getTouchDistance(e.touches)
    }
  }, [transform.x, transform.y])

  const onTouchMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault()
    if (e.touches.length === 1 && isDragging.current) {
      const dx = e.touches[0].clientX - dragStart.current.x
      const dy = e.touches[0].clientY - dragStart.current.y
      setTransform(prev => ({
        ...prev,
        x: transformStart.current.x + dx / prev.zoom,
        y: transformStart.current.y + dy / prev.zoom
      }))
    } else if (e.touches.length === 2) {
      const dist = getTouchDistance(e.touches)
      if (lastPinchDistance.current > 0) {
        const scale = dist / lastPinchDistance.current
        setTransform(prev => ({
          ...prev,
          zoom: clamp(prev.zoom * scale, minZoom, maxZoom)
        }))
      }
      lastPinchDistance.current = dist
    }
  }, [minZoom, maxZoom])

  const onTouchEnd = useCallback(() => {
    isDragging.current = false
    lastPinchDistance.current = 0
  }, [])

  const onDoubleClick = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    setTransform(prev => ({ ...prev, zoom: clamp(prev.zoom * 1.35, minZoom, maxZoom) }))
  }, [minZoom, maxZoom])

  // Smooth animation to center on a stand
  const animateToStand = useCallback((centerXNorm: number, centerYNorm: number) => {
    const container = containerRef.current
    if (!container) return

    const rect = container.getBoundingClientRect()
    const targetZoom = clamp(focusZoom, minZoom, maxZoom)
    const { x: targetX, y: targetY } = calculateMapFocusOffset({
      centerXNorm,
      centerYNorm,
      viewportWidth: rect.width,
      viewportHeight: rect.height,
      zoom: targetZoom
    })

    const startTransform = { ...transform }
    const startTime = performance.now()
    const duration = 600 // ms

    const animate = (now: number) => {
      const elapsed = now - startTime
      const t = Math.min(elapsed / duration, 1)
      // Ease out cubic
      const ease = 1 - Math.pow(1 - t, 3)

      setTransform({
        x: startTransform.x + (targetX - startTransform.x) * ease,
        y: startTransform.y + (targetY - startTransform.y) * ease,
        zoom: startTransform.zoom + (targetZoom - startTransform.zoom) * ease,
        tiltDeg: startTransform.tiltDeg
      })

      if (t < 1) {
        animFrameRef.current = requestAnimationFrame(animate)
      }
    }

    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current)
    animFrameRef.current = requestAnimationFrame(animate)
  }, [focusZoom, maxZoom, minZoom, transform])

  const resetView = useCallback(() => {
    const startTransform = { ...transform }
    const startTime = performance.now()
    const duration = 500

    const animate = (now: number) => {
      const elapsed = now - startTime
      const t = Math.min(elapsed / duration, 1)
      const ease = 1 - Math.pow(1 - t, 3)

      setTransform({
        x: startTransform.x * (1 - ease),
        y: startTransform.y * (1 - ease),
        zoom: startTransform.zoom + (initialZoom - startTransform.zoom) * ease,
        tiltDeg: startTransform.tiltDeg + (initialTilt - startTransform.tiltDeg) * ease
      })

      if (t < 1) {
        animFrameRef.current = requestAnimationFrame(animate)
      }
    }

    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current)
    animFrameRef.current = requestAnimationFrame(animate)
  }, [transform, initialTilt, initialZoom])

  const setTilt = useCallback((deg: number) => {
    const clamped = clamp(deg, minTilt, maxTilt)
    const startTilt = transform.tiltDeg
    const startTime = performance.now()
    const duration = 400

    const animate = (now: number) => {
      const elapsed = now - startTime
      const t = Math.min(elapsed / duration, 1)
      const ease = 1 - Math.pow(1 - t, 3)

      setTransform(prev => ({
        ...prev,
        tiltDeg: startTilt + (clamped - startTilt) * ease
      }))

      if (t < 1) {
        animFrameRef.current = requestAnimationFrame(animate)
      }
    }

    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current)
    animFrameRef.current = requestAnimationFrame(animate)
  }, [transform.tiltDeg, minTilt, maxTilt])

  const zoomIn = useCallback(() => {
    setTransform(prev => ({
      ...prev,
      zoom: clamp(prev.zoom + zoomStep, minZoom, maxZoom)
    }))
  }, [minZoom, maxZoom, zoomStep])

  const zoomOut = useCallback(() => {
    setTransform(prev => ({
      ...prev,
      zoom: clamp(prev.zoom - zoomStep, minZoom, maxZoom)
    }))
  }, [minZoom, maxZoom, zoomStep])

  // Cleanup animation frame on unmount
  useEffect(() => {
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current)
    }
  }, [])

  return {
    transform,
    containerRef,
    handlers: {
      onMouseDown,
      onMouseMove,
      onMouseUp,
      onMouseLeave,
      onWheel,
      onTouchStart,
      onTouchMove,
      onTouchEnd
      ,onDoubleClick
    },
    animateToStand,
    resetView,
    setTilt,
    zoomIn,
    zoomOut
  }
}
