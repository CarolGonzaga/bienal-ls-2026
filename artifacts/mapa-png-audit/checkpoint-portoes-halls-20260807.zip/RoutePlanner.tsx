import React, { useMemo } from 'react'
import { Bookmark, MapPin, Trash2, ArrowRight, Navigation } from 'lucide-react'
import { useUserStore } from '../../stores/useUserStore'
import { useExhibitorStore } from '../../stores/useExhibitorStore'
import { useMapStore } from '../../stores/useMapStore'
import { useAdminMapStore } from '../../stores/useAdminMapStore'
import { MAP_HEIGHT, MAP_STREETS, MAP_WIDTH, buildMapLayout } from '../../data/map/map-layout.ts'
import { buildRoutingGraph } from '../../data/map/map-routing-graph.ts'

const ROUTE_ORIGINS = [
  { id: 'P5', label: 'Portão 5', group: 'Portões externos' },
  { id: 'P7', label: 'Portão 7', group: 'Portões externos' },
  { id: 'P8', label: 'Portão 8', group: 'Portões externos' },
  { id: 'P9', label: 'Portão 9', group: 'Portões externos' },
  { id: 'P10', label: 'Portão 10', group: 'Portões externos' },
  ...['A', 'B', 'C', 'D', 'E', 'F'].map(letter => ({ id: `P${letter}`, label: `Portão ${letter}`, group: 'Portões A–F' })),
  ...[1, 2, 3, 4, 5].map(number => ({ id: `HALL${number}`, label: `Acesso Hall ${number}`, group: 'Acessos Hall' }))
]

export const RoutePlanner: React.FC = () => {
  const routeStops = useUserStore(s => s.routeStops)
  const removeFromRoute = useUserStore(s => s.removeFromRoute)
  const clearRoute = useUserStore(s => s.clearRoute)
  const exhibitors = useExhibitorStore(s => s.exhibitors)
  const setSelectedStandId = useMapStore(s => s.setSelectedStandId)
  const routeOriginGateId = useMapStore(s => s.routeOriginGateId)
  const setRouteOriginGateId = useMapStore(s => s.setRouteOriginGateId)
  const setIsChoosingRouteOrigin = useMapStore(s => s.setIsChoosingRouteOrigin)
  const userPosition = useMapStore(s => s.userPosition)
  const setSelectedExhibitorId = useExhibitorStore(s => s.setSelectedExhibitorId)
  const setActiveTabMode = useExhibitorStore(s => s.setActiveTabMode)
  const geometries = useAdminMapStore(s => s.geometries)
  const layout = useMemo(() => buildMapLayout(geometries), [geometries])
  const graph = useMemo(() => buildRoutingGraph(layout), [layout])
  const boothOrigins = layout.filter(feature => feature.exhibitorId && feature.boothCode)

  const showRouteOnMap = () => {
    setActiveTabMode('map')
  }

  const choosePointOnMap = () => {
    setIsChoosingRouteOrigin(true)
    setActiveTabMode('map')
  }

  const useRegisteredPosition = () => {
    if (!userPosition) return
    const point = { x: (userPosition.worldX / 40 + .5) * MAP_WIDTH, y: (.5 - userPosition.worldZ / 33.25) * MAP_HEIGHT }
    const candidates = graph.nodes.filter(node => node.type === 'intersection' || node.type === 'booth-access')
    const nearest = candidates.reduce((best, node) => Math.hypot(node.x - point.x, node.y - point.y) < Math.hypot(best.x - point.x, best.y - point.y) ? node : best, candidates[0])
    if (nearest) setRouteOriginGateId(nearest.id)
  }

  const handleFocusStand = (exhibitorId: string) => {
    setSelectedExhibitorId(exhibitorId)
    const geo = geometries.find(g => g.exhibitorId === exhibitorId && g.verified)
    if (geo) setSelectedStandId(geo.id)
    setActiveTabMode('map')
  }

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Navigation className="w-5 h-5 text-amber-400" />
            <h2 className="text-2xl font-bold text-white">Minha Rota Personalizada</h2>
          </div>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">Escolha seu portão e organize as paradas pela Bienal.</p>
        </div>
        {routeStops.length > 0 && (
          <button onClick={clearRoute} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-950/80 border border-rose-700/60 text-rose-300 text-xs font-bold hover:bg-rose-900 transition-colors">
            <Trash2 className="w-3.5 h-3.5" />
            <span>Limpar rota</span>
          </button>
        )}
      </div>

      <div className="glass-card p-4 rounded-2xl border border-emerald-700/50 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
        <label className="flex flex-col gap-2 text-xs font-bold text-emerald-200">
          <span className="flex items-center gap-2"><MapPin className="w-4 h-4" /> De onde você está saindo?</span>
          <select
            aria-label="Origem da rota"
            value={routeOriginGateId}
            onChange={event => setRouteOriginGateId(event.target.value)}
            className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm font-semibold text-white outline-none focus:border-emerald-400"
          >
            {['Portões externos', 'Portões A–F', 'Acessos Hall'].map(group => <optgroup key={group} label={group}>
              {ROUTE_ORIGINS.filter(origin => origin.group === group).map(origin => <option key={origin.id} value={origin.id}>{origin.label}</option>)}
            </optgroup>)}
            <optgroup label="Ruas">{MAP_STREETS.map(street => <option key={street.id} value={`${street.id}-central`}>{street.name}</option>)}</optgroup>
            <optgroup label="Estandes próximos">{boothOrigins.map(feature => {
              const exhibitor = exhibitors.find(item => item.id === feature.exhibitorId)
              return <option key={feature.id} value={`access-${feature.id}`}>{feature.boothCode} — {exhibitor?.name}</option>
            })}</optgroup>
          </select>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={choosePointOnMap} className="rounded-lg border border-emerald-700 px-3 py-2 text-[11px] text-emerald-200">Selecionar ponto no mapa</button>
            <button type="button" onClick={useRegisteredPosition} disabled={!userPosition} className="rounded-lg border border-emerald-700 px-3 py-2 text-[11px] text-emerald-200 disabled:opacity-40">Usar “você está aqui”</button>
          </div>
        </label>
        <button onClick={showRouteOnMap} disabled={routeStops.length === 0} className="rounded-xl bg-emerald-500 px-4 py-2.5 text-sm font-black text-slate-950 transition hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-40">
          Traçar no mapa
        </button>
      </div>

      {routeStops.length === 0 ? (
        <div className="glass-card p-12 rounded-3xl text-center flex flex-col items-center gap-3 border border-slate-800">
          <Bookmark className="w-10 h-10 text-slate-600" />
          <h3 className="text-base font-bold text-slate-300">Sua lista de rota está vazia</h3>
          <p className="text-slate-500 text-xs max-w-sm">Escolha uma editora no mapa ou na busca e adicione-a à rota.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {routeStops.map((stop, idx) => {
            const exhibitor = exhibitors.find(e => e.id === stop.exhibitorId)
            if (!exhibitor) return null
            return (
              <div key={stop.exhibitorId} className="glass-card p-4 rounded-2xl border border-slate-800 flex items-center justify-between gap-4 hover:border-amber-500/40 transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 rounded-full bg-amber-500 text-slate-950 font-black text-sm flex items-center justify-center shadow-md">{idx + 1}</div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-indigo-950 border border-indigo-700/60 text-indigo-300 text-xs font-bold">{exhibitor.standCode}</span>
                      <h4 className="text-sm font-bold text-white">{exhibitor.name}</h4>
                    </div>
                    <span className="text-xs text-slate-400">{exhibitor.categories.join(', ')}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => handleFocusStand(exhibitor.id)} className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-all">
                    <span>Ver no mapa</span><ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button aria-label={`Remover ${exhibitor.name} da rota`} onClick={() => removeFromRoute(exhibitor.id)} className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
