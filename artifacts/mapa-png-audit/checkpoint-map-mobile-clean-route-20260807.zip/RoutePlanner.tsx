import React, { useMemo } from 'react'
import { Bookmark, MapPin, Trash2, ArrowRight, ArrowUp, ArrowDown, Navigation } from 'lucide-react'
import { useUserStore } from '../../stores/useUserStore'
import { useExhibitorStore } from '../../stores/useExhibitorStore'
import { useMapStore } from '../../stores/useMapStore'
import { useAdminMapStore } from '../../stores/useAdminMapStore'
import { MAP_HEIGHT, MAP_WIDTH, buildMapLayout } from '../../data/map/map-layout.ts'
import { buildRoutingGraph } from '../../data/map/map-routing-graph.ts'
import { ROUTE_SEGMENT_COLORS } from '../../services/mapRoutingService.ts'

export const RoutePlanner: React.FC = () => {
  const routeStops = useUserStore(s => s.routeStops)
  const removeFromRoute = useUserStore(s => s.removeFromRoute)
  const moveRouteStop = useUserStore(s => s.moveRouteStop)
  const clearRoute = useUserStore(s => s.clearRoute)
  const exhibitors = useExhibitorStore(s => s.exhibitors)
  const setSelectedStandId = useMapStore(s => s.setSelectedStandId)
  const routeOriginGateId = useMapStore(s => s.routeOriginGateId)
  const setRouteOriginGateId = useMapStore(s => s.setRouteOriginGateId)
  const setIsChoosingRouteOrigin = useMapStore(s => s.setIsChoosingRouteOrigin)
  const userPosition = useMapStore(s => s.userPosition)
  const setSelectedExhibitorId = useExhibitorStore(s => s.setSelectedExhibitorId)
  const setActiveTabMode = useExhibitorStore(s => s.setActiveTabMode)
  const geometries = useAdminMapStore(s => s.geometries)
  const layout = useMemo(() => buildMapLayout(geometries), [geometries])
  const graph = useMemo(() => buildRoutingGraph(layout), [layout])
  const boothOrigins = layout.filter(feature => feature.exhibitorId && feature.boothCode)
  const orderedStops = useMemo(() => [...routeStops].sort((a, b) => a.order - b.order), [routeStops])
  const selectedOrigin = boothOrigins.find(feature => `access-${feature.id}` === routeOriginGateId)
  const originLabel = routeOriginGateId === 'HALL1' ? 'Entrada Hall 1' : selectedOrigin?.boothCode || 'Ponto selecionado'

  const showRouteOnMap = () => {
    setActiveTabMode('map')
  }

  const choosePointOnMap = () => {
    setIsChoosingRouteOrigin(true)
    setActiveTabMode('map')
  }

  const useRegisteredPosition = () => {
    if (!userPosition) return
    const point = { x: (userPosition.worldX / 40 + .5) * MAP_WIDTH, y: (.5 - userPosition.worldZ / 33.25) * MAP_HEIGHT }
    const candidates = graph.nodes.filter(node => node.type === 'intersection' || node.type === 'booth-access')
    const nearest = candidates.reduce((best, node) => Math.hypot(node.x - point.x, node.y - point.y) < Math.hypot(best.x - point.x, best.y - point.y) ? node : best, candidates[0])
    if (nearest) setRouteOriginGateId(nearest.id)
  }

  const handleFocusStand = (exhibitorId: string) => {
    setSelectedExhibitorId(exhibitorId)
    const geo = geometries.find(g => g.exhibitorId === exhibitorId && g.verified)
    if (geo) setSelectedStandId(geo.id)
    setActiveTabMode('map')
  }

  return (
    <div className="mx-auto flex w-full min-w-0 max-w-4xl flex-col gap-6 overflow-x-hidden px-4 py-6 sm:py-8">
      <div className="flex min-w-0 items-start justify-between gap-3 sm:items-center">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Navigation className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold leading-tight text-white sm:text-2xl">Minha Rota Personalizada</h2>
          </div>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">A entrada principal do Hall 1 é a origem padrão. Você também pode partir de um estande.</p>
        </div>
        {routeStops.length > 0 && (
          <button onClick={clearRoute} className="flex shrink-0 items-center gap-1.5 rounded-xl border border-rose-700/60 bg-rose-950/80 px-3 py-1.5 text-xs font-bold text-rose-300 transition-colors hover:bg-rose-900">
            <Trash2 className="w-3.5 h-3.5" />
            <span>Limpar rota</span>
          </button>
        )}
      </div>

      <div className="glass-card grid min-w-0 gap-3 rounded-2xl border border-emerald-700/50 p-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
        <label className="flex min-w-0 flex-col gap-2 text-xs font-bold text-emerald-200">
          <span className="flex items-center gap-2"><MapPin className="w-4 h-4" /> Ponto de partida único</span>
          <select
            aria-label="Origem da rota"
            value={routeOriginGateId}
            onChange={event => setRouteOriginGateId(event.target.value)}
            className="w-full min-w-0 max-w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm font-semibold text-white outline-none focus:border-emerald-400"
          >
            <optgroup label="Entrada principal"><option value="HALL1">Hall 1 · Entrada principal</option></optgroup>
            <optgroup label="Partir de um estande">{boothOrigins.map(feature => {
              const exhibitor = exhibitors.find(item => item.id === feature.exhibitorId)
              return <option key={feature.id} value={`access-${feature.id}`}>{feature.boothCode} — {exhibitor?.name}</option>
            })}</optgroup>
          </select>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={choosePointOnMap} className="rounded-lg border border-emerald-700 px-3 py-2 text-[11px] text-emerald-200">Selecionar ponto no mapa</button>
            <button type="button" onClick={useRegisteredPosition} disabled={!userPosition} className="rounded-lg border border-emerald-700 px-3 py-2 text-[11px] text-emerald-200 disabled:opacity-40">Usar “você está aqui”</button>
          </div>
        </label>
        <button onClick={showRouteOnMap} disabled={routeStops.length === 0} className="w-full min-w-0 rounded-xl bg-emerald-500 px-4 py-2.5 text-sm font-black text-slate-950 transition hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-40 sm:w-auto">
          Traçar no mapa
        </button>
      </div>

      {routeStops.length === 0 ? (
        <div className="glass-card p-12 rounded-3xl text-center flex flex-col items-center gap-3 border border-slate-800">
          <Bookmark className="w-10 h-10 text-slate-600" />
          <h3 className="text-base font-bold text-slate-300">Sua lista de rota está vazia</h3>
          <p className="text-slate-500 text-xs max-w-sm">Escolha uma editora no mapa ou na busca e adicione-a à rota.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between px-1"><h3 className="text-sm font-black text-slate-200">Destinos em ordem</h3><span className="text-[11px] text-slate-500">Use as setas para reorganizar</span></div>
          {orderedStops.map((stop, idx) => {
            const exhibitor = exhibitors.find(e => e.id === stop.exhibitorId)
            if (!exhibitor) return null
            const fromLabel = idx === 0 ? originLabel : orderedStops[idx - 1].standCode
            const color = ROUTE_SEGMENT_COLORS[idx % ROUTE_SEGMENT_COLORS.length]
            return (
              <div key={stop.exhibitorId} data-route-order={idx + 1} className="glass-card flex min-w-0 flex-col items-stretch justify-between gap-4 rounded-2xl border border-slate-800 p-4 transition-all hover:border-amber-500/40 sm:flex-row sm:items-center">
                <div className="flex min-w-0 items-center gap-3 sm:gap-4">
                  <div className="w-8 h-8 rounded-full text-white font-black text-sm flex items-center justify-center shadow-md" style={{ backgroundColor: color }}>{idx + 1}</div>
                  <div className="min-w-0 flex-1">
                    <div className="mb-1 text-[11px] font-bold" style={{ color }}>{fromLabel} → {stop.standCode}</div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-indigo-950 border border-indigo-700/60 text-indigo-300 text-xs font-bold">{exhibitor.standCode}</span>
                      <h4 className="text-sm font-bold text-white">{exhibitor.name}</h4>
                    </div>
                    <span className="block break-words text-xs text-slate-400">{exhibitor.categories.join(', ')}</span>
                  </div>
                </div>
                <div className="flex shrink-0 items-center justify-end gap-2 sm:justify-start">
                  <div className="flex flex-col gap-1">
                    <button disabled={idx === 0} aria-label={`Mover ${stop.standCode} para cima`} onClick={() => moveRouteStop(stop.exhibitorId, 'up')} className="rounded-lg bg-slate-800 p-1 text-slate-300 disabled:opacity-25"><ArrowUp className="h-3.5 w-3.5"/></button>
                    <button disabled={idx === orderedStops.length - 1} aria-label={`Mover ${stop.standCode} para baixo`} onClick={() => moveRouteStop(stop.exhibitorId, 'down')} className="rounded-lg bg-slate-800 p-1 text-slate-300 disabled:opacity-25"><ArrowDown className="h-3.5 w-3.5"/></button>
                  </div>
                  <button onClick={() => handleFocusStand(exhibitor.id)} className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-all">
                    <span>Ver no mapa</span><ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button aria-label={`Remover ${exhibitor.name} da rota`} onClick={() => removeFromRoute(exhibitor.id)} className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
