import React from 'react'
import type { CalculatedRouteSegment } from '../../services/mapRoutingService.ts'

export const MapRoute: React.FC<{ segments: CalculatedRouteSegment[]; compact?: boolean }> = ({ segments, compact = false }) => {
  if (!segments.length) return null
  const origin = segments[0].points[0]
  const outerWidth = compact ? 4 : 7
  const innerWidth = compact ? 2 : 3.5
  const destinationRadius = compact ? 7 : 9
  const originRadius = compact ? 6 : 8
  return <g id="route-layer" data-testid="gps-route" className="pointer-events-none">
    {segments.map(segment => {
      const d = segment.points.map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`).join(' ')
      const destination = segment.points[segment.points.length - 1]
      return <g key={`${segment.fromId}-${segment.toId}`} data-route-segment={segment.index + 1} data-route-from={segment.fromLabel} data-route-to={segment.toLabel} data-route-color={segment.color}>
        <path d={d} fill="none" stroke="#fff" strokeWidth={outerWidth} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <path d={d} fill="none" stroke={segment.color} strokeWidth={innerWidth} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <g transform={`translate(${destination.x} ${destination.y})`}>
          <circle r={destinationRadius} fill={segment.color} stroke="#fff" strokeWidth={compact ? 1.5 : 2.5} vectorEffect="non-scaling-stroke"/>
          <text textAnchor="middle" dominantBaseline="middle" fontSize={compact ? 6 : 8} fontWeight="900" fill="#fff">{segment.index + 1}</text>
        </g>
      </g>
    })}
    <g transform={`translate(${origin.x} ${origin.y})`}><circle r={originRadius} fill="#059669" stroke="#fff" strokeWidth={compact ? 1.5 : 2.5} vectorEffect="non-scaling-stroke"/><circle r={compact ? 2 : 2.5} fill="#fff"/></g>
  </g>
}
