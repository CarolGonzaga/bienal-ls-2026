import React, { useEffect, useMemo, useRef, useState } from 'react'
import { MapPin, Sparkles } from 'lucide-react'
import { useAdminMapStore } from '../../stores/useAdminMapStore'
import { useExhibitorStore } from '../../stores/useExhibitorStore'
import { useMapStore } from '../../stores/useMapStore'
import { useUserStore } from '../../stores/useUserStore'
import { useMapInteraction } from '../../hooks/useMapInteraction'
import { MAP_ANNOTATIONS, MAP_HEIGHT, MAP_STREETS, MAP_WIDTH, buildMapLayout, type MapFeature } from '../../data/map/map-layout.ts'
import { buildRoutingGraph } from '../../data/map/map-routing-graph.ts'
import { buildRouteSegments, parseMapRouteParams } from '../../services/mapRoutingService.ts'
import { MapBooth } from './MapBooth.tsx'
import { MapRoute } from './MapRoute.tsx'

const pointsString = (points: Array<{ x: number; y: number }>) => points.map(point => `${point.x},${point.y}`).join(' ')

export const BienalMap: React.FC = () => {
  const databaseGeometries = useAdminMapStore(state => state.geometries)
  const exhibitors = useExhibitorStore(state => state.exhibitors)
  const searchQuery = useExhibitorStore(state => state.searchQuery)
  const setSelectedExhibitorId = useExhibitorStore(state => state.setSelectedExhibitorId)
  const selectedExhibitorId = useExhibitorStore(state => state.selectedExhibitorId)
  const selectedStandId = useMapStore(state => state.selectedStandId)
  const setSelectedStandId = useMapStore(state => state.setSelectedStandId)
  const mapTheme = useMapStore(state => state.mapTheme)
  const graphicsQuality = useMapStore(state => state.graphicsQuality)
  const reducedMotion = useMapStore(state => state.reducedMotion)
  const userPosition = useMapStore(state => state.userPosition)
  const routeOriginGateId = useMapStore(state => state.routeOriginGateId)
  const setRouteOriginGateId = useMapStore(state => state.setRouteOriginGateId)
  const isChoosingRouteOrigin = useMapStore(state => state.isChoosingRouteOrigin)
  const setIsChoosingRouteOrigin = useMapStore(state => state.setIsChoosingRouteOrigin)
  const favorites = useUserStore(state => state.favorites)
  const visits = useUserStore(state => state.visits)
  const routeStops = useUserStore(state => state.routeStops)
  const addToRoute = useUserStore(state => state.addToRoute)
  const features = useMemo(() => buildMapLayout(databaseGeometries), [databaseGeometries])
  const svgRef = useRef<SVGSVGElement>(null)
  const lastHandledSearchRef = useRef('')
  const [compactViewport, setCompactViewport] = useState(() => window.matchMedia('(max-width: 1023px)').matches)

  useEffect(() => {
    const media = window.matchMedia('(max-width: 1023px)')
    const updateViewport = () => setCompactViewport(media.matches)
    media.addEventListener('change', updateViewport)
    return () => media.removeEventListener('change', updateViewport)
  }, [])

  const { transform, containerRef, handlers, animateToStand, resetView, zoomIn, zoomOut } = useMapInteraction({ initialTilt: 0, initialZoom: compactViewport ? 2.2 : 1.3, minZoom: .55, maxZoom: 10, zoomStep: .7, focusZoom: 4.4, reducedMotion })

  useEffect(() => {
    ;(window as any).__mapControls = { resetView, animateToStand, zoomIn, zoomOut }
    return () => { delete (window as any).__mapControls }
  }, [resetView, animateToStand, zoomIn, zoomOut])

  const graph = useMemo(() => buildRoutingGraph(features), [features])
  const routeSegments = useMemo(() => buildRouteSegments(graph, features, routeOriginGateId, routeStops), [features, graph, routeOriginGateId, routeStops])
  const routePoints = useMemo(() => routeSegments.flatMap(segment => segment.points), [routeSegments])

  useEffect(() => {
    const controls = (window as any).__mapControls
    if (!controls) return
    controls.focusRoute = () => {
      if (!routePoints.length) return
      const center = routePoints.reduce((sum, point) => ({ x: sum.x + point.x / routePoints.length, y: sum.y + point.y / routePoints.length }), { x: 0, y: 0 })
      animateToStand(center.x / MAP_WIDTH, center.y / MAP_HEIGHT)
    }
    controls.focusOrigin = () => {
      const point = routeSegments[0]?.points[0]; if (point) animateToStand(point.x / MAP_WIDTH, point.y / MAP_HEIGHT)
    }
    controls.focusDestination = () => {
      const point = routeSegments.at(-1)?.points.at(-1); if (point) animateToStand(point.x / MAP_WIDTH, point.y / MAP_HEIGHT)
    }
  }, [animateToStand, routePoints, routeSegments])

  useEffect(() => {
    const { origin, destination: destinationCode } = parseMapRouteParams(window.location.search)
    if (origin && graph.nodes.some(node => node.id === origin)) setRouteOriginGateId(origin)
    if (!destinationCode) return
    const feature = features.find(item => item.boothCode?.toUpperCase() === destinationCode && item.exhibitorId)
    if (!feature?.exhibitorId || !feature.boothCode) return
    setSelectedStandId(feature.id)
    setSelectedExhibitorId(feature.exhibitorId)
    addToRoute(feature.exhibitorId, feature.boothCode)
  }, [addToRoute, features, graph.nodes, setRouteOriginGateId, setSelectedExhibitorId, setSelectedStandId])

  useEffect(() => {
    const query = searchQuery.trim().toUpperCase()
    if (!query) {
      lastHandledSearchRef.current = ''
      return
    }
    if (lastHandledSearchRef.current === query) return
    lastHandledSearchRef.current = query
    const feature = features.find(item => item.boothCode?.toUpperCase() === query && item.exhibitorId)
    if (!feature?.exhibitorId || feature.geometry.type !== 'rect') return
    setSelectedStandId(feature.id)
    setSelectedExhibitorId(feature.exhibitorId)
    animateToStand((feature.geometry.x + feature.geometry.width / 2) / MAP_WIDTH, (feature.geometry.y + feature.geometry.height / 2) / MAP_HEIGHT)
  }, [animateToStand, features, searchQuery, setSelectedExhibitorId, setSelectedStandId])

  const selectFeature = (feature: MapFeature) => {
    setSelectedStandId(feature.id)
    if (feature.exhibitorId) setSelectedExhibitorId(feature.exhibitorId)
    if (feature.type === 'gate' && feature.metadata?.routeOrigin) {
      const routeCode = typeof feature.metadata.routeCode === 'string' ? feature.metadata.routeCode : routeOriginGateId
      if (routeCode === 'HALL1') setRouteOriginGateId(routeCode)
    }
    if (feature.geometry.type === 'rect') animateToStand((feature.geometry.x + feature.geometry.width / 2) / MAP_WIDTH, (feature.geometry.y + feature.geometry.height / 2) / MAP_HEIGHT)
  }

  const svgPointFromEvent = (event: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return null
    const point = svgRef.current.createSVGPoint(); point.x = event.clientX; point.y = event.clientY
    const matrix = svgRef.current.getScreenCTM(); return matrix ? point.matrixTransform(matrix.inverse()) : null
  }

  const chooseOriginOnMap = (event: React.MouseEvent<SVGSVGElement>) => {
    if (!isChoosingRouteOrigin) return
    const point = svgPointFromEvent(event)
    if (!point) return
    const candidates = graph.nodes.filter(node => node.id === 'HALL1' || node.type === 'booth-access')
    const nearest = candidates.reduce((best, node) => Math.hypot(node.x - point.x, node.y - point.y) < Math.hypot(best.x - point.x, best.y - point.y) ? node : best, candidates[0])
    if (nearest) setRouteOriginGateId(nearest.id)
    setIsChoosingRouteOrigin(false)
  }

  const dark = mapTheme === 'dark'
  const user = userPosition ? { x: (userPosition.worldX / 40 + .5) * MAP_WIDTH, y: (.5 - userPosition.worldZ / 33.25) * MAP_HEIGHT } : null
  const mapItems = features.filter(feature => !['wall', 'external-area', 'street'].includes(feature.type))
  const buildingItems = features.filter(feature => feature.type === 'wall' || feature.type === 'external-area')

  const showMapDetails = graphicsQuality !== 'eco' || transform.zoom >= 2

  return <div ref={containerRef} data-testid="bienal-map" data-map-quality={graphicsQuality} data-reduced-motion={reducedMotion} className={`map-quality-${graphicsQuality} absolute inset-0 min-h-[520px] overflow-hidden select-none ${dark ? 'bg-slate-950' : 'bg-slate-100'}`}>
    <div data-testid="map-zoom-surface" className="absolute inset-0 flex items-center justify-center p-2 sm:p-4" style={{ touchAction: 'none' }} {...handlers}>
      <div className="h-full w-full" style={{ transform: `translate3d(${transform.x}px, ${transform.y}px, 0) scale(${transform.zoom})`, transformOrigin: 'center center' }}>
        <svg ref={svgRef} viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`} preserveAspectRatio="xMidYMid meet" width="100%" height="100%" className={`block h-full w-full ${isChoosingRouteOrigin ? 'cursor-crosshair' : ''}`} role="img" aria-labelledby="bienal-map-title bienal-map-description" onClick={chooseOriginOnMap}>
          <title id="bienal-map-title">Mapa indoor da Bienal do Livro</title>
          <desc id="bienal-map-description">Mapa vetorial com pavilhões, ruas, estandes, portões, serviços e rota acessível pelos corredores.</desc>
          <g id="background-layer"><rect width={MAP_WIDTH} height={MAP_HEIGHT} fill={dark ? '#0f172a' : '#f1f5f9'} /></g>
          <g id="external-layer">{buildingItems.map(feature => feature.geometry.type === 'polygon' ? <polygon key={feature.id} points={pointsString(feature.geometry.points)} fill={feature.type === 'wall' ? dark ? '#172033' : '#fff' : feature.id === 'external-north' ? '#dcfce7' : dark ? '#111827' : '#e5e7eb'} stroke={dark ? '#64748b' : '#94a3b8'} strokeWidth={2} vectorEffect="non-scaling-stroke"/> : null)}</g>
          <g id="street-layer">{MAP_STREETS.map(street => <g key={street.id}>{street.segments.map(([start, end], index) => {
            const labelX = (start.x + end.x) / 2
            const labelY = (start.y + end.y) / 2
            return <g key={index}>
              <path d={`M ${start.x} ${start.y} L ${end.x} ${end.y}`} stroke={dark ? '#334155' : '#dbe1e8'} strokeWidth={street.width} strokeLinecap="butt"/>
              {showMapDetails && <g data-street-label={street.name} className="pointer-events-none">
                <rect x={labelX - 25} y={labelY - 6} width="50" height="12" rx="6" fill={dark ? '#0f172a' : '#fff'} stroke={dark ? '#64748b' : '#94a3b8'} strokeWidth=".7" vectorEffect="non-scaling-stroke"/>
                <text x={labelX} y={labelY} textAnchor="middle" dominantBaseline="middle" fontSize="7" fontWeight="900" letterSpacing=".45" fill={dark ? '#f8fafc' : '#334155'}>{street.name.toUpperCase()}</text>
              </g>}
            </g>
          })}</g>)}</g>
          {showMapDetails && <g id="annotation-layer" className="pointer-events-none">{MAP_ANNOTATIONS.map(annotation => <text key={annotation.id} x={annotation.position.x} y={annotation.position.y} textAnchor="middle" dominantBaseline="middle" fontSize={annotation.fontSize || 7} fontWeight="900" letterSpacing=".25" fill={dark ? '#cbd5e1' : '#475569'}>{annotation.label}</text>)}</g>}
          <g id="booth-and-service-layer">{mapItems.map(feature => {
            const exhibitor = feature.exhibitorId ? exhibitors.find(item => item.id === feature.exhibitorId) : undefined
            return <MapBooth key={feature.id} feature={feature} exhibitor={exhibitor} selected={selectedStandId === feature.id} favorite={Boolean(exhibitor && favorites.includes(exhibitor.id))} visited={Boolean(exhibitor && visits[exhibitor.id])} inRoute={Boolean(exhibitor && routeStops.some(stop => stop.exhibitorId === exhibitor.id))} isometric={false} zoom={transform.zoom} dark={dark} quality={graphicsQuality} onSelect={() => selectFeature(feature)}/>
          })}</g>
          <MapRoute segments={routeSegments}/>
          <g id="marker-layer">{user && <g data-testid="user-position-marker" transform={`translate(${user.x} ${user.y})`}>{!reducedMotion && <circle className="user-ping" r="14" fill="#2563eb"/>}<circle r="10" fill="#2563eb" stroke="#fff" strokeWidth="3" vectorEffect="non-scaling-stroke"/><circle r="3" fill="#fff"/><text y="-14" textAnchor="middle" fontSize="8" fontWeight="900" fill="#1d4ed8">VOCÊ ESTÁ AQUI</text></g>}</g>
        </svg>
      </div>
    </div>
    <div className={`absolute bottom-3 left-3 hidden rounded-xl border px-3 py-2 text-xs font-bold shadow-lg lg:block ${dark ? 'border-slate-700 bg-slate-900/90 text-slate-100' : 'border-slate-300 bg-white/95 text-slate-700'}`}><span className="flex items-center gap-2"><Sparkles className="h-4 w-4 text-pink-500"/>Mapa 2D • {Math.round(transform.zoom * 100)}%</span></div>
    {routeSegments.length > 0 && <div className={`absolute bottom-3 left-3 right-3 max-h-36 overflow-y-auto rounded-xl border p-3 text-xs shadow-xl lg:left-auto lg:max-h-56 lg:w-72 ${selectedExhibitorId ? 'lg:right-[466px]' : 'lg:right-3'} ${dark ? 'border-slate-700 bg-slate-900/95 text-slate-200' : 'border-slate-300 bg-white/95 text-slate-700'}`}>
      <div className="mb-2 flex items-center gap-1 font-black"><MapPin className="h-4 w-4 text-teal-600"/>Rota por trechos</div>
      <div className="space-y-2">{routeSegments.map(segment => <div key={`${segment.fromId}-${segment.toId}`} data-route-summary={segment.index + 1} className="flex items-start gap-2 rounded-lg border border-slate-400/20 px-2 py-1.5">
        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-black text-white" style={{ backgroundColor: segment.color }}>{segment.index + 1}</span>
        <div><div className="font-black">{segment.fromLabel} → {segment.toLabel}</div><div className="mt-0.5 text-[10px] opacity-70">{segment.instructions.slice(1, 2).join(' ') || 'Siga pelo corredor indicado.'}</div></div>
      </div>)}</div>
    </div>}
    {isChoosingRouteOrigin && <div className="absolute left-1/2 top-3 z-30 -translate-x-1/2 rounded-xl bg-teal-700 px-4 py-2 text-sm font-black text-white shadow-xl">Clique em uma rua ou ponto próximo para definir a origem</div>}
  </div>
}
