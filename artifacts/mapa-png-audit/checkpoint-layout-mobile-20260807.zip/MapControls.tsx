import React from 'react'
import { 
  MapPin, 
  Activity, 
  Zap, 
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Sun,
  Moon,
  Navigation
} from 'lucide-react'
import { useMapStore, type GraphicsQuality } from '../../stores/useMapStore'
import { toWorldCoordinates } from '../../utils/coordinates'

type MapControlsVariant = 'desktop' | 'mobile-map' | 'mobile-settings'

export const MapControls: React.FC<{ panelOpen?: boolean; variant?: MapControlsVariant }> = ({ panelOpen = false, variant = 'desktop' }) => {
  const graphicsQuality = useMapStore(s => s.graphicsQuality)
  const reducedMotion = useMapStore(s => s.reducedMotion)
  const mapTheme = useMapStore(s => s.mapTheme)
  
  const setGraphicsQuality = useMapStore(s => s.setGraphicsQuality)
  const setReducedMotion = useMapStore(s => s.setReducedMotion)
  const setMapTheme = useMapStore(s => s.setMapTheme)
  const userPosition = useMapStore(s => s.userPosition)
  const setUserPosition = useMapStore(s => s.setUserPosition)

  const handleSetUserPin = () => {
    setUserPosition(userPosition ? null : toWorldCoordinates(0.5, 0.5))
  }

  const handleResetView = () => {
    const ctrl = (window as any).__mapControls
    if (ctrl?.resetView) ctrl.resetView()
  }

  const handleZoom = (direction: 'in' | 'out') => {
    const ctrl = (window as any).__mapControls
    if (direction === 'in') ctrl?.zoomIn?.()
    else ctrl?.zoomOut?.()
  }

  const focus = (target: 'focusRoute' | 'focusOrigin' | 'focusDestination') => {
    const ctrl = (window as any).__mapControls
    ctrl?.[target]?.()
  }

  if (variant === 'mobile-map') {
    return <div data-testid="mobile-map-controls" className="absolute right-3 top-3 z-[35] flex flex-col gap-2 lg:hidden">
      <button aria-label="Aumentar zoom" onClick={() => handleZoom('in')} className="flex h-11 w-11 items-center justify-center rounded-xl border border-indigo-400/40 bg-indigo-700/95 text-white shadow-lg"><ZoomIn className="h-5 w-5"/></button>
      <button aria-label="Diminuir zoom" onClick={() => handleZoom('out')} className="flex h-11 w-11 items-center justify-center rounded-xl border border-indigo-400/40 bg-indigo-700/95 text-white shadow-lg"><ZoomOut className="h-5 w-5"/></button>
      <button aria-label="Centralizar mapa" onClick={handleResetView} className="flex h-11 w-11 items-center justify-center rounded-xl border border-indigo-400/40 bg-indigo-700/95 text-white shadow-lg"><RotateCcw className="h-5 w-5"/></button>
    </div>
  }

  if (variant === 'mobile-settings') {
    return <div data-testid="mobile-map-settings" className="grid gap-3 rounded-2xl border border-slate-700/80 bg-slate-900/95 p-3 lg:hidden">
      <div className="grid grid-cols-2 gap-2">
        <button data-testid="map-theme-toggle" onClick={() => setMapTheme(mapTheme === 'light' ? 'dark' : 'light')} className="flex min-h-11 items-center justify-between rounded-xl border border-slate-700 px-3 text-xs font-semibold text-slate-200">
          <span>Tema {mapTheme === 'light' ? 'claro' : 'escuro'}</span>{mapTheme === 'light' ? <Sun className="h-4 w-4 text-amber-300"/> : <Moon className="h-4 w-4 text-indigo-300"/>}
        </button>
        <button onClick={handleSetUserPin} data-testid="user-position-toggle" aria-pressed={Boolean(userPosition)} className={`flex min-h-11 items-center justify-center gap-2 rounded-xl border px-3 text-xs font-semibold ${userPosition ? 'border-emerald-500/60 bg-emerald-950/70 text-emerald-200' : 'border-slate-700 text-slate-300'}`}>
          <MapPin className="h-4 w-4 text-emerald-400"/><span>{userPosition ? 'Remover posição' : 'Minha posição'}</span>
        </button>
      </div>
      <div className="grid grid-cols-[auto_1fr] items-center gap-3">
        <span className="flex items-center gap-1 text-[10px] font-black uppercase tracking-wider text-slate-400"><Zap className="h-3 w-3 text-amber-400"/>Qualidade</span>
        <div className="grid grid-cols-3 rounded-lg border border-slate-800 bg-slate-950/80 p-0.5 text-[10px] font-bold">{(['auto', 'high', 'eco'] as GraphicsQuality[]).map(q => <button key={q} data-testid={`quality-${q}`} aria-pressed={graphicsQuality === q} onClick={() => setGraphicsQuality(q)} className={`rounded py-1.5 ${graphicsQuality === q ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}>{q === 'auto' ? 'Auto' : q === 'high' ? 'Alta' : 'Eco'}</button>)}</div>
      </div>
      <button data-testid="reduced-motion-toggle" aria-pressed={reducedMotion} onClick={() => setReducedMotion(!reducedMotion)} className={`flex min-h-10 items-center justify-between rounded-xl border px-3 text-xs ${reducedMotion ? 'border-amber-600/50 bg-amber-950/60 text-amber-300' : 'border-slate-700 text-slate-300'}`}>
        <span>{reducedMotion ? 'Movimentos reduzidos' : 'Reduzir movimentos'}</span><Activity className="h-4 w-4"/>
      </button>
    </div>
  }

  return (
    <div className={`absolute right-4 top-4 z-[60] hidden w-64 max-w-[calc(100%-1rem)] flex-col gap-2 pointer-events-auto lg:flex ${panelOpen ? 'lg:right-[466px]' : 'lg:right-4'}`}>
      {/* View Controls */}
      <div className="glass-panel p-2 rounded-2xl flex flex-col gap-1.5 border border-slate-700/80 shadow-xl">
        <div className="grid grid-cols-2 gap-1" aria-label="Controles de zoom">
          <button aria-label="Diminuir zoom" onClick={() => handleZoom('out')} className="map-control-button"><ZoomOut className="w-4 h-4" /></button>
          <button aria-label="Aumentar zoom" onClick={() => handleZoom('in')} className="map-control-button"><ZoomIn className="w-4 h-4" /></button>
        </div>
        <button onClick={() => focus('focusRoute')} className="flex min-h-10 items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-semibold text-slate-300 hover:bg-slate-800/80 hover:text-white">
          <Navigation className="w-4 h-4 text-teal-400"/><span>Enquadrar rota</span>
        </button>
        <div className="grid grid-cols-2 gap-1">
          <button onClick={() => focus('focusOrigin')} className="map-control-button text-[10px]">Origem</button>
          <button onClick={() => focus('focusDestination')} className="map-control-button text-[10px]">Destino</button>
        </div>
        <button
          onClick={handleResetView}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all text-left"
          title="Centralizar Mapa"
        >
          <RotateCcw className="w-4 h-4 text-purple-400" />
          <span>Centralizar</span>
        </button>

        <button
          onClick={handleSetUserPin}
          data-testid="user-position-toggle"
          aria-pressed={Boolean(userPosition)}
          className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-semibold transition-all text-left ${userPosition ? 'border-emerald-500/60 bg-emerald-950/70 text-emerald-200' : 'border-transparent text-slate-300 hover:text-white hover:bg-slate-800/80'}`}
          title={userPosition ? 'Remover minha posição do mapa' : 'Adicionar minha posição ao mapa'}
        >
          <MapPin className="w-4 h-4 text-emerald-400" />
          <span>{userPosition ? 'Remover Posição' : 'Minha Posição'}</span>
        </button>
      </div>

      {/* Accessibility & Graphics Modes */}
      <div className="glass-panel p-2 rounded-2xl flex flex-col gap-2 border border-slate-700/80 shadow-xl">
        <button data-testid="map-theme-toggle" onClick={(event) => { event.stopPropagation(); setMapTheme(mapTheme === 'light' ? 'dark' : 'light') }} className="flex min-h-10 items-center justify-between rounded-xl border border-slate-700 px-2.5 py-1.5 text-xs font-semibold text-slate-200">
          <span>Tema {mapTheme === 'light' ? 'claro' : 'escuro'}</span>{mapTheme === 'light' ? <Sun className="w-4 h-4 text-amber-300"/> : <Moon className="w-4 h-4 text-indigo-300"/>}
        </button>
        <div className="flex items-center justify-between px-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Qualidade</span>
          <Zap className="w-3 h-3 text-amber-400" />
        </div>

        <div className="grid grid-cols-3 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 text-[10px] font-bold">
          {(['auto', 'high', 'eco'] as GraphicsQuality[]).map((q) => (
            <button
              key={q}
              data-testid={`quality-${q}`}
              aria-pressed={graphicsQuality === q}
              onClick={() => setGraphicsQuality(q)}
              className={`py-1 rounded transition-all capitalize ${
                graphicsQuality === q ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              {q === 'auto' ? 'Auto' : q === 'high' ? 'Alta' : 'Eco'}
            </button>
          ))}
        </div>

        <button
          data-testid="reduced-motion-toggle"
          aria-pressed={reducedMotion}
          onClick={() => setReducedMotion(!reducedMotion)}
          className={`flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-all ${
            reducedMotion 
              ? 'bg-amber-950/60 border-amber-600/50 text-amber-300' 
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="text-[11px]">{reducedMotion ? 'Movimentos Reduzidos' : 'Reduzir Movimentos'}</span>
          <Activity className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  )
}
