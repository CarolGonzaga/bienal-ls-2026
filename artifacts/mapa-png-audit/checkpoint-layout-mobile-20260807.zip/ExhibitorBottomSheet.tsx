import React, { useState } from 'react'
import { 
  X, 
  MapPin, 
  Sparkles, 
  Heart, 
  CheckCircle2, 
  Bookmark, 
  BookOpen, 
  Calendar, 
  MessageSquarePlus, 
  ExternalLink,
  Share2,
  AlertCircle
} from 'lucide-react'
import { Exhibitor, StandGeometry } from '../../types'
import { useUserStore } from '../../stores/useUserStore'
import { useExhibitorStore } from '../../stores/useExhibitorStore'
import { INITIAL_BOOKS } from '../../data/initialBooks'
import { INITIAL_EVENTS } from '../../data/initialEvents'

interface ExhibitorBottomSheetProps {
  exhibitor: Exhibitor
  geometry?: StandGeometry
  onClose: () => void
}

export const ExhibitorBottomSheet: React.FC<ExhibitorBottomSheetProps> = ({ exhibitor, geometry, onClose }) => {
  const [activeTab, setActiveTab] = useState<'info' | 'books' | 'events'>('info')
  const [suggestionMessage, setSuggestionMessage] = useState('')
  const [showSuggestionForm, setShowSuggestionForm] = useState(false)

  const isFavorite = useUserStore(s => s.isFavorite(exhibitor.id))
  const toggleFavorite = useUserStore(s => s.toggleFavorite)
  
  const isVisited = useUserStore(s => s.isVisited(exhibitor.id))
  const toggleVisited = useUserStore(s => s.toggleVisited)
  
  const isInRoute = useUserStore(s => s.isInRoute(exhibitor.id))
  const addToRoute = useUserStore(s => s.addToRoute)
  const removeFromRoute = useUserStore(s => s.removeFromRoute)

  const relatedBooks = INITIAL_BOOKS.filter(b => b.exhibitorIds.includes(exhibitor.id))
  const relatedEvents = INITIAL_EVENTS.filter(e => e.exhibitorIds.includes(exhibitor.id))

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${exhibitor.name} - Bienal SP 2026`,
        text: `Confira o estande ${exhibitor.standCode} da ${exhibitor.name} no Mapa Sáfico da Bienal!`,
        url: window.location.href
      }).catch(() => {})
    } else {
      navigator.clipboard.writeText(window.location.href)
      alert('Link do estande copiado para a área de transferência!')
    }
  }

  return (
    <>
    <button type="button" aria-label="Fechar detalhes ao tocar fora" onClick={onClose} className="fixed inset-0 z-40 bg-slate-950/65 backdrop-blur-[2px] md:hidden"/>
    <div data-testid="exhibitor-bottom-sheet" className="exhibitor-sheet fixed inset-x-0 bottom-0 z-50 flex max-h-[84dvh] w-full flex-col overflow-hidden rounded-t-[2rem] border-t border-slate-700 bg-[#090d16]/98 shadow-2xl md:inset-y-0 md:left-auto md:right-0 md:max-h-none md:w-[450px] md:rounded-none md:border-l md:border-t-0">
      <div className="flex h-7 shrink-0 items-center justify-center md:hidden"><span className="h-1 w-12 rounded-full bg-slate-600"/></div>
      
      {/* Header */}
      <div className="px-5 pb-4 pt-2 border-b border-slate-800/80 flex items-start justify-between gap-4 md:p-6">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-700/80 flex items-center justify-center p-2 shadow-md">
            <span className="font-extrabold text-lg text-indigo-400">
              {exhibitor.name.substring(0, 2).toUpperCase()}
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-indigo-950/80 border border-indigo-700/60 text-indigo-300 text-xs font-bold">
                {exhibitor.standCode}
              </span>
              {exhibitor.relevanceLevel === 'curadoria_direta' && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-pink-950/80 border border-pink-700/60 text-pink-300 text-[10px] font-bold">
                  <Sparkles className="w-3 h-3 text-pink-400" /> Curadoria Direta
                </span>
              )}
            </div>

            <h2 className="text-xl font-bold text-white mt-1 leading-tight">
              {exhibitor.name}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={handleShare}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Compartilhar"
          >
            <Share2 className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            aria-label="Fechar detalhes do estande"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Mandatory Notice if Skeelo / Unverified Location per Section 1 & 26 */}
      {!geometry?.verified && (
        <div className="mx-6 mt-4 p-3 rounded-xl bg-amber-950/60 border border-amber-700/60 text-amber-300 text-xs font-semibold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>Localização exata aguardando confirmação.</span>
        </div>
      )}

      {/* Primary Action Buttons */}
      <div className="px-6 py-4 border-b border-slate-800/80 grid grid-cols-3 gap-2">
        <button
          onClick={() => toggleFavorite(exhibitor.id)}
          className={`py-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-1 transition-all ${
            isFavorite
              ? 'bg-rose-950/80 border-rose-600/60 text-rose-300 shadow-md'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-400 text-rose-400' : ''}`} />
          <span>{isFavorite ? 'Favoritada' : 'Favoritar'}</span>
        </button>

        <button
          onClick={() => toggleVisited(exhibitor.id)}
          className={`py-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-1 transition-all ${
            isVisited
              ? 'bg-emerald-950/80 border-emerald-600/60 text-emerald-300 shadow-md'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <CheckCircle2 className={`w-4 h-4 ${isVisited ? 'text-emerald-400' : ''}`} />
          <span>{isVisited ? 'Visitado' : 'Marcar Visita'}</span>
        </button>

        <button
          onClick={() => isInRoute ? removeFromRoute(exhibitor.id) : addToRoute(exhibitor.id, exhibitor.standCode)}
          className={`py-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-1 transition-all ${
            isInRoute
              ? 'bg-amber-950/80 border-amber-600/60 text-amber-300 shadow-md'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <Bookmark className={`w-4 h-4 ${isInRoute ? 'fill-amber-400 text-amber-400' : ''}`} />
          <span>{isInRoute ? 'Na Rota' : 'Add à Rota'}</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="px-6 border-b border-slate-800 flex items-center gap-6">
        <button
          onClick={() => setActiveTab('info')}
          className={`py-3 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'info'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Sobre a Editora
        </button>

        <button
          onClick={() => setActiveTab('books')}
          className={`py-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'books'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Livros ({relatedBooks.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('events')}
          className={`py-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'events'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Eventos ({relatedEvents.length})</span>
        </button>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
        {activeTab === 'info' && (
          <>
            {/* Description - Render only if populated per Section 7 */}
            {exhibitor.description && (
              <div className="flex flex-col gap-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Sobre</h3>
                <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-line">
                  {exhibitor.description}
                </p>
              </div>
            )}

            {/* Reason to visit - Render only if populated per Section 7 */}
            {exhibitor.reasonToVisit && (
              <div className="glass-card p-4 rounded-2xl border border-indigo-500/30 flex flex-col gap-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-pink-400" />
                  Por que visitar este estande?
                </h3>
                <p className="text-slate-200 text-sm leading-relaxed">
                  {exhibitor.reasonToVisit}
                </p>
              </div>
            )}

            {/* Categories */}
            <div className="flex flex-col gap-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Categorias</h3>
              <div className="flex flex-wrap gap-1.5">
                {exhibitor.categories.map((cat, idx) => (
                  <span key={idx} className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-xs font-medium">
                    {cat}
                  </span>
                ))}
              </div>
            </div>

            {/* Suggest Correction Button */}
            <div className="mt-auto pt-4 border-t border-slate-800/80">
              {!showSuggestionForm ? (
                <button
                  onClick={() => setShowSuggestionForm(true)}
                  className="text-xs font-medium text-slate-400 hover:text-indigo-400 flex items-center gap-1.5 transition-colors"
                >
                  <MessageSquarePlus className="w-3.5 h-3.5" />
                  <span>Sugerir uma correção de dados</span>
                </button>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    alert('Obrigado! Sua sugestão foi enviada para moderação.')
                    setShowSuggestionForm(false)
                    setSuggestionMessage('')
                  }}
                  className="flex flex-col gap-2 bg-slate-900/90 p-3 rounded-xl border border-slate-800"
                >
                  <span className="text-xs font-bold text-slate-300">Sugerir Correção</span>
                  <textarea
                    required
                    value={suggestionMessage}
                    onChange={(e) => setSuggestionMessage(e.target.value)}
                    placeholder="Descreva a correção necessária..."
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 h-20"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowSuggestionForm(false)}
                      className="px-3 py-1 rounded-lg bg-slate-800 text-slate-400 text-xs font-medium"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-medium"
                    >
                      Enviar
                    </button>
                  </div>
                </form>
              )}
            </div>
          </>
        )}

        {activeTab === 'books' && (
          <div className="flex flex-col gap-4">
            {relatedBooks.length === 0 ? (
              <p className="text-slate-400 text-sm italic">Nenhum livro cadastrado para esta editora ainda.</p>
            ) : (
              relatedBooks.map(book => (
                <div key={book.id} className="glass-card p-4 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-white">{book.title}</h4>
                    <span className="px-2 py-0.5 rounded bg-pink-950 text-pink-300 text-[10px] font-bold">
                      Sáfico
                    </span>
                  </div>
                  <p className="text-slate-400 text-xs leading-relaxed">{book.synopsis}</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {book.tropes.map((trope, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded bg-indigo-950/60 border border-indigo-800/40 text-indigo-300 text-[10px]">
                        #{trope}
                      </span>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'events' && (
          <div className="flex flex-col gap-4">
            {relatedEvents.length === 0 ? (
              <p className="text-slate-400 text-sm italic">Nenhum evento ou autógrafo cadastrado para esta editora ainda.</p>
            ) : (
              relatedEvents.map(evt => (
                <div key={evt.id} className="glass-card p-4 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <div className="flex items-center justify-between text-xs text-indigo-400 font-bold">
                    <span>{evt.startTime} - {evt.endTime}</span>
                    <span>{evt.date}</span>
                  </div>
                  <h4 className="text-sm font-bold text-white">{evt.title}</h4>
                  <p className="text-slate-400 text-xs leading-relaxed">{evt.description}</p>
                  <span className="text-[11px] text-slate-500">{evt.locationName}</span>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
    </>
  )
}
