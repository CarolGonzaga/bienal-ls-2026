import React, { useState } from 'react'
import { 
  BookOpen, 
  MapPin, 
  Calendar, 
  Sparkles, 
  User, 
  Compass, 
  Award, 
  Bookmark, 
  ShieldCheck,
  Eye,
  LogOut,
  List
} from 'lucide-react'
import { useExhibitorStore } from './stores/useExhibitorStore'
import { useMapStore } from './stores/useMapStore'
import { useAdminMapStore } from './stores/useAdminMapStore'
import { useUserStore } from './stores/useUserStore'

import { BienalMap } from './components/map/BienalMap'
import { MapControls } from './components/map/MapControls'
import { ExhibitorList } from './components/exhibitors/ExhibitorList'
import { ExhibitorBottomSheet } from './components/exhibitors/ExhibitorBottomSheet'
import { SearchBar } from './components/search/SearchBar'
import { SapphicPassport } from './components/passport/SapphicPassport'
import { RoutePlanner } from './components/route/RoutePlanner'
import { ScheduleView } from './components/schedule/ScheduleView'
import { AdminSuite } from './components/admin/AdminSuite'
import { AccessibilityPanel } from './components/accessibility/AccessibilityPanel'
import AuthModal from './components/AuthModal'

export default function App() {
  const activeTabMode = useExhibitorStore(s => s.activeTabMode)
  const setActiveTabMode = useExhibitorStore(s => s.setActiveTabMode)
  const selectedExhibitorId = useExhibitorStore(s => s.selectedExhibitorId)
  const setSelectedExhibitorId = useExhibitorStore(s => s.setSelectedExhibitorId)
  const exhibitors = useExhibitorStore(s => s.exhibitors)

  const selectedStandId = useMapStore(s => s.selectedStandId)
  const setSelectedStandId = useMapStore(s => s.setSelectedStandId)
  const reducedMotion = useMapStore(s => s.reducedMotion)

  const geometries = useAdminMapStore(s => s.geometries)

  const user = useUserStore(s => s.user)
  const setUser = useUserStore(s => s.setUser)

  const [isAuthOpen, setIsAuthOpen] = useState(false)
  const [isAccessibilityOpen, setIsAccessibilityOpen] = useState(false)

  const selectedExhibitor = exhibitors.find(e => e.id === selectedExhibitorId)
  const selectedGeometry = geometries.find(g => g.id === selectedStandId)

  const handleCloseDrawer = () => {
    setSelectedExhibitorId(null)
    setSelectedStandId(null)
  }

  return (
    <div className={`min-h-[100dvh] bg-[#090d16] text-slate-100 flex flex-col font-sans relative overflow-hidden ${reducedMotion ? 'reduce-motion' : ''}`}>
      
      {/* Header Navigation */}
      <header className="sticky top-0 z-40 glass-panel border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-600 via-purple-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-pink-500/20 flex-shrink-0">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-lg sm:text-xl font-extrabold bg-gradient-to-r from-white via-slate-200 to-pink-300 bg-clip-text text-transparent leading-tight block">
                Mapa Sáfico
              </span>
              <span className="text-[10px] font-bold text-slate-400">
                Bienal SP 2026
              </span>
            </div>
          </div>

          {/* Search Bar in Header for larger screens */}
          <div className="hidden lg:block flex-1 max-w-md">
            <SearchBar />
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-900/80 p-1.5 rounded-full border border-slate-800">
            {[
              { id: 'map', label: 'Mapa', icon: Compass },
              { id: 'list', label: 'Editoras', icon: List },
              { id: 'passport', label: 'Passaporte', icon: Award },
              { id: 'route', label: 'Minha Rota', icon: Bookmark },
              { id: 'schedule', label: 'Programação', icon: Calendar },
              { id: 'admin', label: 'Admin', icon: ShieldCheck }
            ].map(tab => {
              const Icon = tab.icon
              const isActive = activeTabMode === tab.id
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTabMode(tab.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    isActive 
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-600/30' 
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAccessibilityOpen(true)}
              className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors"
              title="Acessibilidade"
            >
              <Eye className="w-4 h-4" />
            </button>

            {user ? (
              <div className="flex items-center gap-2 bg-slate-900/80 border border-indigo-500/30 px-3 py-1.5 rounded-2xl">
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-pink-500 to-indigo-500 flex items-center justify-center text-xs font-bold text-white">
                  {(user.user_metadata?.name || user.email)[0].toUpperCase()}
                </div>
                <span className="hidden sm:inline text-xs font-semibold text-slate-200 max-w-[100px] truncate">
                  {user.user_metadata?.name || user.email}
                </span>
                <button
                  onClick={() => setUser(null)}
                  title="Sair"
                  className="p-1 rounded-lg text-slate-400 hover:text-rose-400 transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setIsAuthOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all"
              >
                <User className="w-3.5 h-3.5 text-white" />
                <span>Entrar</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center justify-around bg-slate-950 px-2 py-2 border-t border-slate-800/80 text-xs font-semibold">
          {[
            { id: 'map', label: 'Mapa', icon: Compass },
            { id: 'list', label: 'Editoras', icon: List },
            { id: 'passport', label: 'Passaporte', icon: Award },
            { id: 'route', label: 'Rota', icon: Bookmark },
            { id: 'schedule', label: 'Agenda', icon: Calendar },
            { id: 'admin', label: 'Admin', icon: ShieldCheck }
          ].map(tab => {
            const Icon = tab.icon
            const isActive = activeTabMode === tab.id
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTabMode(tab.id)}
                className={`flex flex-col items-center gap-1 py-1 px-2 rounded-xl transition-all ${
                  isActive ? 'text-indigo-400 font-bold' : 'text-slate-400'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-[10px]">{tab.label}</span>
              </button>
            )
          })}
        </div>
      </header>

      {/* Main Content Render */}
      <main className="flex-1 relative flex flex-col w-full h-[calc(100dvh-80px)] overflow-hidden">
        {activeTabMode === 'map' && (
          <div className="absolute inset-0">
            {/* Search Input overlay for mobile */}
            <div className="lg:hidden absolute top-4 left-4 right-20 z-30">
              <SearchBar />
            </div>

            {/* Render fixed 2D map */}
            <BienalMap />

            {/* Map Floating Controls */}
            <MapControls panelOpen={Boolean(selectedExhibitor)} />
          </div>
        )}

        {activeTabMode === 'list' && <ExhibitorList />}
        {activeTabMode === 'passport' && <SapphicPassport />}
        {activeTabMode === 'route' && <RoutePlanner />}
        {activeTabMode === 'schedule' && <ScheduleView />}
        {activeTabMode === 'admin' && <AdminSuite />}
      </main>

      {/* Floating Selected Exhibitor Bottom Sheet / Side Panel */}
      {selectedExhibitor && (
        <ExhibitorBottomSheet
          exhibitor={selectedExhibitor}
          geometry={selectedGeometry}
          onClose={handleCloseDrawer}
        />
      )}

      {/* Accessibility Panel Modal */}
      <AccessibilityPanel
        isOpen={isAccessibilityOpen}
        onClose={() => setIsAccessibilityOpen(false)}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={(userData) => setUser(userData)}
      />
    </div>
  )
}
